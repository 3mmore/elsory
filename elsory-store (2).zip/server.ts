import express from "express";
import path from "path";
import dotenv from "dotenv";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";
import csurf from "csurf";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();

// 1. Helmet HTTP Security Headers (OWASP Best Practice)
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
        imgSrc: ["'self'", "https:", "data:", "blob:"],
        connectSrc: ["'self'", "https:", "http:", "ws:", "wss:"],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);

// Body Parsing & Cookie Parsing
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());

// 2. Express Rate Limiter for API Protection (OWASP Best Practice)
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes window
  max: 100, // Limit each IP to 100 requests per 15 minutes
  standardHeaders: true, // Return rate limit info in `RateLimit-*` headers
  legacyHeaders: false, // Disable `X-RateLimit-*` headers
  message: {
    error: "Too many requests from this IP address, please try again after 15 minutes.",
  },
});

app.use("/api/", apiLimiter);

// 3. CSURF Protection setup
const csrfProtection = csurf({
  cookie: {
    key: "_csrf",
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
  },
});

// Endpoint to fetch CSRF Token
app.get("/api/csrf-token", csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

// Apply CSRF Protection to state-changing API endpoints
app.use("/api", (req, res, next) => {
  // Allow safe HTTP methods without CSRF token check
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    return next();
  }
  return csrfProtection(req, res, next);
});

// Custom Error Handler for CSRF validation failures
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err && err.code === "EBADCSRFTOKEN") {
    return res.status(403).json({
      error: "Invalid or missing CSRF token. Request blocked for security.",
    });
  }
  next(err);
});

const PORT = 3000;

// Initialize GoogleGenAI SDK safely
const getGenAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is missing from environment variables.");
  }
  return new GoogleGenAI({
    apiKey: apiKey || "dummy-key",
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// Environmental Variables Check & Fail-Safe Reporting
const isProduction = process.env.NODE_ENV === "production";
if (!process.env.GEMINI_API_KEY) {
  console.warn("[SECURITY WARN] GEMINI_API_KEY is not set. AI features will operate with limited fallback.");
}
if (!process.env.PAYMOB_API_KEY) {
  console.warn("[PAYMENT WARN] PAYMOB_API_KEY is not set. Paymob card checkout will operate in sandbox test link mode.");
}

// Input Sanitization & Validation Helper for API Routes
function validateAndSanitizeString(input: unknown, fieldName: string, maxLength = 500): string {
  if (typeof input !== "string") {
    throw new Error(`Invalid format for ${fieldName}: expected string.`);
  }
  const cleaned = input.trim().replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");
  if (cleaned.length > maxLength) {
    throw new Error(`${fieldName} exceeds maximum allowed length of ${maxLength} characters.`);
  }
  return cleaned;
}

// Helper for masking stack traces in production
function safeErrorResponse(res: express.Response, statusCode: number, userMessage: string, internalError?: any) {
  if (internalError) {
    console.error(`[SERVER ERROR ${statusCode}]`, internalError);
  }
  return res.status(statusCode).json({
    error: userMessage,
    ...(isProduction ? {} : { details: internalError?.message }),
  });
}

// Paymob Payment Gateway Endpoints (Egypt)
app.post("/api/paymob/create-payment", async (req, res) => {
  try {
    const { orderId, totalUSD, customerInfo, items = [] } = req.body;

    if (!orderId || !totalUSD || !customerInfo?.fullName || !customerInfo?.phone) {
      return res.status(400).json({ error: "Missing required order parameters for payment generation." });
    }

    const safeOrderId = validateAndSanitizeString(orderId, "orderId", 100);
    const safeName = validateAndSanitizeString(customerInfo.fullName, "customerInfo.fullName", 150);
    const safePhone = validateAndSanitizeString(customerInfo.phone, "customerInfo.phone", 50);
    const safeEmail = customerInfo.email ? validateAndSanitizeString(customerInfo.email, "customerInfo.email", 100) : "customer@elsory.eg";

    // Amount in EGP (1 USD ~ 48.5 EGP) in cents (x100)
    const egpTotal = Math.round(totalUSD * 48.5);
    const amountCents = Math.max(100, egpTotal * 100);

    const paymobApiKey = process.env.PAYMOB_API_KEY;
    const integrationId = process.env.PAYMOB_INTEGRATION_ID || "3912345";
    const iframeId = process.env.PAYMOB_IFRAME_ID || "812345";

    let iframeUrl = `https://accept.paymob.com/api/acceptance/iframes/${iframeId}?payment_token=sandbox_token_${safeOrderId}`;

    if (paymobApiKey) {
      try {
        // Step 1: Authentication Token
        const authRes = await fetch("https://accept.paymob.com/api/auth/tokens", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ api_key: paymobApiKey }),
        });
        const authData = await authRes.json();
        const authToken = authData.token;

        if (authToken) {
          // Step 2: Order Registration
          const nameParts = safeName.split(" ");
          const firstName = nameParts[0] || "Customer";
          const lastName = nameParts.slice(1).join(" ") || "ElSory";

          const orderRes = await fetch("https://accept.paymob.com/api/ecommerce/orders", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              auth_token: authToken,
              delivery_needed: "true",
              amount_cents: amountCents.toString(),
              currency: "EGP",
              merchant_order_id: `${safeOrderId}_${Date.now()}`,
              items: [],
            }),
          });
          const orderData = await orderRes.json();

          if (orderData.id) {
            // Step 3: Payment Key Request
            const keyRes = await fetch("https://accept.paymob.com/api/acceptance/payment_keys", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                auth_token: authToken,
                amount_cents: amountCents.toString(),
                expiration: 3600,
                order_id: orderData.id,
                billing_data: {
                  apartment: "NA",
                  email: safeEmail,
                  floor: "NA",
                  first_name: firstName,
                  street: customerInfo.address || "Zagazig District",
                  building: "NA",
                  phone_number: safePhone,
                  shipping_method: "PKG",
                  postal_code: "44511",
                  city: customerInfo.city || "Zagazig",
                  country: "EGY",
                  last_name: lastName,
                  state: "Sharqia",
                },
                currency: "EGP",
                integration_id: Number(integrationId),
              }),
            });
            const keyData = await keyRes.json();

            if (keyData.token) {
              iframeUrl = `https://accept.paymob.com/api/acceptance/iframes/${iframeId}?payment_token=${keyData.token}`;
            }
          }
        }
      } catch (paymobErr) {
        console.warn("Paymob API call failed, falling back to secure payment portal sandbox link:", paymobErr);
      }
    }

    return res.json({
      success: true,
      orderId: safeOrderId,
      amountEGP: egpTotal,
      amountCents,
      iframeUrl,
      paymobCheckoutUrl: iframeUrl,
    });
  } catch (err: any) {
    return safeErrorResponse(res, 500, "Unable to initialize secure Paymob checkout.", err);
  }
});

// Paymob Callback Webhook Receiver
app.post("/api/paymob/webhook", (req, res) => {
  try {
    const payload = req.body;
    console.log("[PAYMOB WEBHOOK RECEIVED]", payload?.obj?.id, payload?.obj?.success);
    return res.status(200).json({ status: "acknowledged" });
  } catch (err: any) {
    return res.status(500).json({ error: "Webhook error" });
  }
});

// Health Check API
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    store: "ElSory Store (السوري ستور) API",
    location: "Zagazig, Sharqia, Egypt",
    time: new Date().toISOString(),
  });
});

// ElSory Store AI Concierge / Assistant Endpoint (Sales & Customer Advisor)
app.post("/api/ai-assistant", async (req, res) => {
  try {
    const { prompt, preferences, conversationHistory, mode = "general", userLocation } = req.body;

    if (!prompt && (!preferences || Object.keys(preferences).length === 0)) {
      return res.status(400).json({ error: "Please provide a query or preferences." });
    }

    const ai = getGenAI();

    const systemInstruction = `
You are ElSory Store AI (السوري ستور) — the premier Sales Consultant, Customer Advisor, and Senior Mobile Hardware & Repair Specialist at ELSORY STORE located in Zagazig, Sharqia Governorate, Egypt (Villas El Gamea District, Al Qawmia).

CRITICAL DIRECTIVES & OWASP/ETHICAL STANDARDS:
1. HONESTY & CUSTOMER TRUST:
   - Always prioritize honesty, customer trust, and long-term relationships over aggressive or pushy selling.
   - NEVER invent or hallucinate product specifications, stock availability, false discounts, or fake delivery guarantees.
   - Base ALL recommendations strictly on verified ElSory Store data, real inventory catalog, transparent prices, official store policies, and certified repair services.

2. SALES CONSULTANT ROLE & BEHAVIOR:
   - Behave like the best, most knowledgeable sales representative in a flagship Apple Store — polite, attentive, empathetic, highly technical, and completely trustworthy.
   - Understand customer needs through conversation. Ask thoughtful follow-up questions when requirements are vague (e.g., asking about primary usage like camera vs gaming vs battery life, or budget flexibility) BEFORE rushing to recommend a product.
   - Compare multiple devices objectively, highlighting genuine pros and cons for the user's specific use case.
   - Recommend the best value for the customer's budget — never push the most expensive model if a better-suited or more affordable model fits their needs better.
   - Suggest genuine accessories that complement their chosen device (e.g. 100W GaN fast chargers, MagSafe Leather Cases, AirPods Max/Pro 2, hydrogel screen guards).
   - Suggest protection plans or repair center services when appropriate (e.g. 1-Year Official ElSory Store Warranty, TrueTone OLED protection, battery health care).
   - Cross-sell and upsell naturally without being pushy or aggressive.
   - Maintain multi-turn context throughout the conversation.
   - Assist with storage size choices (explaining why 256GB vs 512GB vs 1TB matters for 4K video recording or heavy apps), color variants, payment options, and official Egyptian installment plans (Valu, Souhoola, Sympl, CIB 0% interest, InstaPay, Cash on Delivery).
   - Handle customer objections professionally and empathetically (e.g., addressing price concerns, warranty questions, Android vs iOS switching, or repair vs buying new).

3. INVENTORY & AVAILABILITY MANDATE:
   - Store catalog items:
     * iPhone 16 Pro Max ($1199 / 58,150 EGP) - IN STOCK
     * Samsung Galaxy S25 Ultra ($1299 / 63,000 EGP) - IN STOCK
     * Nothing Phone (2a) Plus ($449 / 21,750 EGP) - IN STOCK
     * Google Pixel 9 Pro XL ($1099 / 53,300 EGP) - IN STOCK
     * 24K Gold Syrian Falcon Edition iPhone 16 Pro Max ($4800 / 232,800 EGP) - IN STOCK (Luxury)
     * iPad Pro M4 13-inch ($1299 / 63,000 EGP) - IN STOCK
     * Apple Watch Ultra 2 ($799 / 38,750 EGP) - IN STOCK
     * AirPods Pro 2 ($249 / 12,000 EGP) - IN STOCK
     * Anker MagGo Power Bank ($89 / 4,300 EGP) - IN STOCK
     * Original OLED Screen Replacements - Certified Service
     * Genuine Battery Replacements - Certified Service
     * Precision Laser Back Glass Repair - Certified Service
     * Motherboard Micro-Soldering & IC Repair - Certified Service
   - REPAIR PRICING DIRECTIVE:
     * When customers ask about specific repair prices or repair cost quotes, DO NOT state fixed price figures. Explain politely that exact repair costs depend on the specific device model and damage extent. Direct them to message our certified Zagazig repair team directly on WhatsApp (+20 101 893 8933) for an accurate quote.
   - IF A REQUESTED PRODUCT IS UNAVAILABLE OR NOT IN CATALOG (e.g., Sony Xperia, Asus ROG, custom unstocked models):
     * NEVER claim it is available in stock.
     * Explain politely that it is currently not stocked in the immediate inventory.
     * Suggest suitable, in-stock alternatives from our catalog with clear comparisons.
     * Politely recommend contacting our Zagazig store directly on WhatsApp for a custom VIP import inquiry.

4. TONE & FORMATTING:
   - Format responses using clean, structured Markdown headers, bullet points, and comparison lists.
   - Speak in fluent English or Arabic depending on the user's input language. Mention 1-Year Store Warranty, Zagazig Express same-day courier, and doorstep pickup.
`;

    const userMessage = prompt || `User preferences: Budget: ${preferences?.budget || 'Flex'}, Primary Use: ${preferences?.useCase || 'General'}, Preferred Brand: ${preferences?.brand || 'Any'}.`;

    // Construct multi-turn contents array if conversation history is provided
    const contents: any[] = [];
    if (Array.isArray(conversationHistory) && conversationHistory.length > 0) {
      for (const msg of conversationHistory) {
        if (msg.text) {
          contents.push({
            role: msg.sender === 'user' ? 'user' : 'model',
            parts: [{ text: msg.text }],
          });
        }
      }
    }
    // Append current prompt
    contents.push({
      role: 'user',
      parts: [{ text: userMessage }],
    });

    // Select model and configuration according to requested capability mode
    let modelName = "gemini-3.5-flash";
    let config: any = {
      systemInstruction,
    };
    let toolConfig: any = undefined;

    if (mode === "fast") {
      // Feature 1: Low-latency fast responses
      modelName = "gemini-3.1-flash-lite";
      config.temperature = 0.5;
    } else if (mode === "thinking") {
      // Feature 2: High thinking mode for complex queries (gemini-3.1-pro-preview + ThinkingLevel.HIGH)
      modelName = "gemini-3.1-pro-preview";
      config.thinkingConfig = {
        thinkingLevel: ThinkingLevel.HIGH,
      };
      // Note: maxOutputTokens must NOT be set when using thinkingLevel
    } else if (mode === "maps") {
      // Feature 5: Google Maps Grounding
      modelName = "gemini-3.5-flash";
      config.tools = [{ googleMaps: {} }];
      if (userLocation && typeof userLocation.latitude === 'number' && typeof userLocation.longitude === 'number') {
        toolConfig = {
          retrievalConfig: {
            latLng: {
              latitude: userLocation.latitude,
              longitude: userLocation.longitude,
            },
          },
        };
      }
      // Note: responseMimeType / responseSchema must NOT be set when using googleMaps
    } else {
      // Feature 3 & 4: General intelligence and multi-turn chatbot
      modelName = "gemini-3.5-flash";
      config.temperature = 0.7;
    }

    const requestPayload: any = {
      model: modelName,
      contents,
      config,
    };

    if (toolConfig) {
      requestPayload.toolConfig = toolConfig;
    }

    const response = await ai.models.generateContent(requestPayload);

    const replyText = response.text || "I recommend consulting our flagship models like iPhone 16 Pro Max or Galaxy S25 Ultra, or visiting our Zagazig repair center.";

    // Extract Grounding Chunks (for Google Maps or Search grounding if used)
    const rawGroundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const mapsSources = rawGroundingChunks.map((chunk: any) => {
      if (chunk.maps) {
        return {
          title: chunk.maps.title || "ElSory Store Location",
          uri: chunk.maps.uri || "https://maps.google.com",
          placeAnswerSources: chunk.maps.placeAnswerSources || null,
        };
      }
      if (chunk.web) {
        return {
          title: chunk.web.title || "Web Reference",
          uri: chunk.web.uri || "https://google.com",
        };
      }
      return null;
    }).filter(Boolean);

    return res.json({
      reply: replyText,
      modeUsed: mode,
      modelUsed: modelName,
      groundingChunks: rawGroundingChunks,
      mapsSources,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("AI Assistant Error:", error);
    return res.status(500).json({
      error: "Unable to consult AI Assistant right now.",
      message: error.message,
    });
  }
});

// Trade-In Estimator Backend API
app.post("/api/trade-in", (req, res) => {
  try {
    const { brand, model, storage, condition, screenIntact } = req.body;

    // Base value matrix in USD
    let baseValue = 300;

    if (model.toLowerCase().includes("iphone 15 pro max")) baseValue = 750;
    else if (model.toLowerCase().includes("iphone 15 pro")) baseValue = 650;
    else if (model.toLowerCase().includes("iphone 14 pro max")) baseValue = 550;
    else if (model.toLowerCase().includes("iphone 13 pro")) baseValue = 400;
    else if (model.toLowerCase().includes("galaxy s24 ultra")) baseValue = 700;
    else if (model.toLowerCase().includes("galaxy s23 ultra")) baseValue = 500;
    else if (model.toLowerCase().includes("pixel 8 pro")) baseValue = 420;

    // Storage modifier
    if (storage?.includes("512GB")) baseValue += 60;
    if (storage?.includes("1TB")) baseValue += 120;

    // Condition multiplier
    let conditionMult = 1.0;
    if (condition === "Like New") conditionMult = 1.0;
    else if (condition === "Good") conditionMult = 0.85;
    else if (condition === "Fair") conditionMult = 0.65;

    if (!screenIntact) conditionMult *= 0.6;

    const estimatedValueUSD = Math.round(baseValue * conditionMult);
    const bonusCreditUSD = 0;
    const totalTradeInUSD = estimatedValueUSD;

    const voucherCode = `ELSORY-TRADE-${Math.floor(100000 + Math.random() * 900000)}`;

    return res.json({
      brand,
      model,
      estimatedValueUSD,
      bonusCreditUSD,
      totalTradeInUSD,
      currencyValues: {
        EGP: `${(totalTradeInUSD * 48.5).toLocaleString('en-US')} ج.م`,
        USD: `$${totalTradeInUSD}`,
        EUR: `€${Math.round(totalTradeInUSD * 0.92)}`,
        SAR: `${Math.round(totalTradeInUSD * 3.75)} ر.س`,
        AED: `${Math.round(totalTradeInUSD * 3.67)} د.إ`,
        SYP: `${(totalTradeInUSD * 14800).toLocaleString('en-US')} ل.س`,
      },
      voucherCode,
    });
  } catch (error: any) {
    return res.status(500).json({ error: "Failed to generate trade-in valuation." });
  }
});

// Admin AI Marketing Advisor & Strategic Growth Intelligence Endpoint
app.post("/api/ai-marketing-analyst", async (req, res) => {
  try {
    const { focusArea = "overview", customPrompt } = req.body;
    const ai = getGenAI();

    const marketingSystemInstruction = `
You are the Chief AI Marketing Strategist & Senior Business Analyst at ELSORY STORE (السوري ستور) — the flagship luxury mobile phone retailer, hardware specialist, and micro-repair center in Zagazig, Sharqia, Egypt.

YOUR MISSION:
Analyze real store inventory, sales performance, search query trends, customer conversation insights, conversion rates, abandoned carts, repair logs, and seasonal demand to generate highly actionable, data-driven, and ethical marketing and sales growth strategies.

CORE STRATEGIC RESPONSIBILITIES & OUTPUT STRUCTURE:
1. MARKET DEMAND & SALES ANALYSIS:
   - Identify top-trending devices (iPhone 16 Pro Max, Galaxy S25 Ultra, Pixel 9 Pro XL).
   - Detect zero-inventory / unstocked search demand (e.g., Sony Xperia, Asus ROG, custom folding phones) and recommend custom import or pre-order campaigns.
   - Evaluate cart abandonment drivers and conversion velocity.

2. ACTIONABLE MARKETING & CAMPAIGN RECOMMENDATIONS:
   - PROMOTIONS & DISCOUNT STRATEGY: Specify which products need promotional spotlight vs which require targeted clearance discounts.
   - BUNDLES & FLASH DEALS: Suggest high-margin bundle deals (e.g. Flagship Device + Anker 100W GaN Charger + Hydrogel Protection + 1-Year Store Warranty).
   - CROSS-SELL & UPSELL STRATEGIES: Recommend natural cross-sells (AirPods Pro 2, Apple Watch Ultra 2, MagSafe leather cases).
   - CAMPAIGN TYPES: Create tailored plans for Seasonal Campaigns, Egyptian Holiday Promotions (Ramadan, Eid, Back-to-School, Black Friday / White Friday), VIP Loyalty, and Referral programs.

3. MULTI-CHANNEL DIGITAL MARKETING CREATIVES & AD SCRIPTS:
   - WHATSAPP MARKETING: Provide high-converting broadcast message copy with clear CTAs for local Egyptian customers.
   - EMAIL MARKETING: Write compelling subject lines and email body copy.
   - SOCIAL MEDIA CONTENT (Instagram / TikTok): Viral Reel concepts, video hooks, and script outlines.
   - PAID AD CAMPAIGNS (Meta Facebook/Instagram Ads & Google Ads): Ad copy, target demographics, and search keywords.
   - TIKTOK CAMPAIGNS: Hook ideas, video pacing, and trendy sound suggestions.
   - CAMPAIGN METRICS: Suggest optimal posting schedules, recommended ad budgets (EGP / USD), and target conversion metrics / expected ROI.

4. SLOW-MOVING INVENTORY CLEARANCE:
   - Identify slower-moving inventory items and propose strategic clearance bundles, trade-in booster credits, or local Zagazig door-to-door promotion ideas.

Always structure your report clearly using Markdown headings, bold key metrics, bullet points, and code blocks for broadcast templates & ad copy.
`;

    let promptText = `Generate a strategic Marketing & Sales Intelligence report for ElSory Store. Focus area: ${focusArea}.`;
    if (customPrompt) {
      promptText += ` Specific Request from Admin: "${customPrompt}"`;
    }

    // Use gemini-3.1-pro-preview with ThinkingLevel.HIGH for deep strategic analysis
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: promptText,
      config: {
        systemInstruction: marketingSystemInstruction,
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.HIGH,
        },
      },
    });

    const reportText = response.text || "Generated strategic marketing intelligence report for ElSory Store.";

    return res.json({
      focusArea,
      report: reportText,
      generatedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("AI Marketing Analyst Error:", error);
    return res.status(500).json({
      error: "Unable to generate AI marketing strategy analysis.",
      message: error.message,
    });
  }
});

// Admin AI Product Creation Assistant Endpoint (Multimodal Product Entry Generator)
app.post("/api/ai-product-creator", async (req, res) => {
  try {
    const { productName, shortDescription, voiceNotesText, basicInfo, images = [], videoUrl } = req.body;
    const ai = getGenAI();

    const productCreatorPrompt = `
You are the Senior E-Commerce Product Director & Hardware Analyst at ELSORY STORE (السوري ستور) in Zagazig, Egypt.

Analyze the uploaded content:
- Product Name / Raw Prompt: "${productName || 'Unspecified'}"
- Short Description / Notes: "${shortDescription || 'None'}"
- Voice Notes Transcript: "${voiceNotesText || 'None'}"
- Basic Information: ${JSON.stringify(basicInfo || {})}
- Images Provided: ${images.length} images uploaded.
- Video Link: "${videoUrl || 'None'}"

YOUR MISSION:
Identify the exact product (device, accessory, or repair service), brand, and model.
Extract all specs and generate a complete, professional, publication-ready product listing draft with bilingual (English & Arabic) copywriting, SEO metadata, image gallery ordering, website placement suggestions, and bundle pricing strategy.

CRITICAL REQUIREMENT: Return ONLY a valid JSON object matching the JSON structure without any markdown wrap or extra commentary.

Expected JSON Structure:
{
  "name": "Full English Product Title",
  "nameArabic": "عنوان المنتج بالعربية",
  "brand": "Brand Name (e.g. Apple, Samsung, Anker, Xiaomi)",
  "model": "Model Name",
  "category": "Smartphones | Tablets | Smartwatches | Audio & Sound | Accessories | Luxury Editions | Repair Services",
  "subcategory": "e.g. Flagship Smartphones",
  "badge": "New Arrival | Bestseller | Hot Deal | Limited Edition",
  "priceUSD": 1199,
  "originalPriceUSD": 1299,
  "storageOptions": ["128GB", "256GB", "512GB", "1TB"],
  "colors": [
    {"name": "Color Name", "hex": "#HEXCODE"}
  ],
  "shortDescription": "Compelling 2-sentence English summary.",
  "shortDescriptionArabic": "وصف قصير مشوق بالعربية من جملتين.",
  "fullDescription": "Rich, multi-paragraph English product description highlighting specs, performance, and ElSory 1-Year Store Warranty.",
  "fullDescriptionArabic": "وصف شامل وتفصيلي باللغة العربية يوضح الأداء والضمان والخدمات الممتازة.",
  "keyFeatures": ["Feature 1", "Feature 2", "Feature 3", "Feature 4"],
  "specsDetail": {
    "display": "Display specs",
    "chipset": "Processor specs",
    "mainCamera": "Camera specs",
    "battery": "Battery & power specs",
    "charging": "Charging speed & wireless",
    "waterResistance": "IP rating or durability"
  },
  "seoTitle": "SEO Page Title (max 60 chars) including ElSory Store Zagazig",
  "seoDescription": "Meta Description (max 155 chars) with keywords and CTA",
  "tags": ["Tag1", "Tag2", "Tag3", "Tag4"],
  "relatedProductNames": ["Related product 1", "Related product 2"],
  "compatibleAccessories": ["Accessory 1", "Accessory 2"],
  "smartImageAnalysis": {
    "mainImageIndex": 0,
    "imageAltTexts": ["Alt text for image 1 in English", "Alt text for image 2 in English"],
    "galleryOrdering": [0, 1],
    "cropRecommendations": "1:1 ratio, centered device framing with studio contrast",
    "backgroundStatus": "Clean background detected, ready for storefront"
  },
  "websitePlacementSuggestions": [
    "Featured Products",
    "Latest Arrivals",
    "Apple Category"
  ],
  "salesPricingStrategy": "Recommended launch pricing strategy and target customer demographic.",
  "bundleOffer": {
    "title": "Starter VIP Bundle",
    "items": ["45W GaN Charger", "Hydrogel Screen Guard", "MagSafe Case"],
    "bundleDiscountUSD": 20
  }
}
`;

    // Construct parts array for multimodal model request
    const parts: any[] = [{ text: productCreatorPrompt }];

    // If image base64 data is attached in images array
    if (Array.isArray(images) && images.length > 0) {
      for (const imgUrl of images.slice(0, 3)) {
        if (typeof imgUrl === 'string' && imgUrl.startsWith('data:image/')) {
          const match = imgUrl.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
          if (match) {
            parts.push({
              inlineData: {
                mimeType: match[1],
                data: match[2],
              },
            });
          }
        }
      }
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
      },
    });

    let resultText = response.text || "{}";
    // Strip markdown code fences if model included them despite prompt
    resultText = resultText.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();

    const parsedDraft = JSON.parse(resultText);

    return res.json({
      success: true,
      draftProduct: parsedDraft,
      generatedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("AI Product Creator Error:", error);
    return res.status(500).json({
      error: "Unable to process product creation via AI.",
      message: error.message,
    });
  }
});

// Conversational Multi-Turn AI Product Management Assistant Endpoint
app.post("/api/ai-product-assistant", async (req, res) => {
  try {
    const { currentDraft, conversationHistory = [], userMessage, uploadedImages = [], handwrittenNoteImage } = req.body;
    const ai = getGenAI();

    const assistantPrompt = `
You are the ELSORY STORE Senior AI Product Manager & Conversational Catalog Assistant.
Your job is to interact conversationally with the store owner (Ammar ElSory) in a multi-turn conversation to draft, refine, and polish product listings before publishing.

INPUT CONTEXT:
- Current Product Draft State: ${JSON.stringify(currentDraft || null)}
- User Message / Command / Voice Transcript: "${userMessage || 'Draft product listing'}"
- Uploaded Images Count: ${uploadedImages.length}
- Handwritten Note Image Attached: ${handwrittenNoteImage ? 'YES' : 'NO'}

CRITICAL MANDATES:
1. Parse any text, transcribed voice notes, or handwritten note image.
2. If this is a new draft or user asks to draft a product, generate complete details:
   - Name (English & Arabic)
   - Brand (Apple, Samsung, Xiaomi, Google, Nothing, Anker, Joyroom, Baseus, UGREEN, etc.)
   - Category (Smartphones, Tablets, Smartwatches, Audio & Sound, Accessories, Luxury Editions, Repair Services)
   - Badge (New Arrival, Bestseller, Hot Deal, Limited Edition)
   - Price in USD & EGP calculation (~48.5 EGP/USD)
   - Price Range suggestion
   - Short & Full descriptions in English and Arabic
   - List of missing attributes (e.g., "Missing: colors available", "Missing: storage options", "Missing: warranty period")
   - Suggested tags
   - Key specifications
3. If the user gives follow-up instructions (e.g., "make price 10% higher", "use second photo as main photo", "translate description to be more casual", "change brand to Samsung"), APPLY THOSE EXACT CHANGES to the draft state.
4. If product photos are provided, analyze them and generate image alt texts, recommend the main photo index, and suggest crop/contrast tweaks. DO NOT fetch external photos from internet.
5. Provide a helpful conversational "assistantReply" explaining what changes were made or asking for missing attributes.

Return ONLY a valid JSON object with NO markdown code fences:
{
  "assistantReply": "Conversational reply to the store owner in English or Arabic depending on input language...",
  "updatedDraft": {
    "name": "Full English Product Title",
    "nameArabic": "عنوان المنتج بالعربية",
    "brand": "Apple",
    "category": "Smartphones",
    "badge": "New Arrival",
    "priceUSD": 1199,
    "priceEGP": 58150,
    "suggestedPriceRangeUSD": "$1150 - $1250 (~55,700 EGP - 60,600 EGP)",
    "originalPriceUSD": 1299,
    "shortDescription": "2-sentence English summary.",
    "shortDescriptionArabic": "وصف قصير بالعربية.",
    "fullDescription": "Rich multi-paragraph English description.",
    "fullDescriptionArabic": "وصف شامل بالعربية.",
    "missingAttributes": ["Colors available", "Warranty duration"],
    "tags": ["Flagship", "Apple"],
    "colors": [{"name": "Natural Titanium", "hex": "#8a8680"}],
    "storageOptions": ["256GB", "512GB"],
    "specsDetail": {
      "display": "6.9 inch OLED 120Hz",
      "chipset": "Latest SoC",
      "mainCamera": "48MP Triple Lens",
      "battery": "5000 mAh"
    },
    "photoAnalysis": {
      "mainPhotoIndex": 0,
      "cropRecommendations": "Center-aligned 1:1 square crop",
      "altTexts": ["Product front view"]
    }
  }
}
`;

    const parts: any[] = [{ text: assistantPrompt }];

    // Attach handwritten note image if present
    if (handwrittenNoteImage && typeof handwrittenNoteImage === 'string' && handwrittenNoteImage.startsWith('data:image/')) {
      const match = handwrittenNoteImage.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (match) {
        parts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2],
          },
        });
      }
    }

    // Attach uploaded product photos if present
    if (Array.isArray(uploadedImages)) {
      for (const imgUrl of uploadedImages.slice(0, 3)) {
        if (typeof imgUrl === 'string' && imgUrl.startsWith('data:image/')) {
          const match = imgUrl.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
          if (match) {
            parts.push({
              inlineData: {
                mimeType: match[1],
                data: match[2],
              },
            });
          }
        }
      }
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
      },
    });

    let resultText = response.text || "{}";
    resultText = resultText.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();

    const parsed = JSON.parse(resultText);

    return res.json({
      success: true,
      assistantReply: parsed.assistantReply || "I have processed your request and updated the product draft.",
      updatedDraft: parsed.updatedDraft || currentDraft,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("AI Product Assistant Error:", error);
    return res.status(500).json({
      error: "Unable to process request with AI Product Assistant.",
      message: error.message,
    });
  }
});

// Admin AI Inventory Intelligence & Sales Optimizer Endpoint
app.post("/api/ai-inventory-sales-optimizer", async (req, res) => {
  try {
    const { inventory = [], searchQueries = [], selectedProduct = null, task = "full_analysis" } = req.body;
    const ai = getGenAI();

    const optimizerPrompt = `
You are the Chief Inventory Intelligence Officer & E-Commerce Sales Optimizer at ELSORY STORE (السوري ستور), Zagazig, Egypt.

Context Data:
- Current Inventory Sample: ${JSON.stringify(inventory.slice(0, 10))}
- Customer Unstocked Search Queries Log: ${JSON.stringify(searchQueries)}
- Target Selected Product for Optimization: ${JSON.stringify(selectedProduct || 'None')}
- Requested Task: "${task}"

YOUR MISSION:
Analyze stock levels, sales velocity, customer search logs, and product metadata.
Provide structured intelligence and optimization suggestions.

Return ONLY a valid JSON object matching this structure:
{
  "inventoryHealthScore": 92,
  "lowStockAlerts": [
    {
      "productName": "Device Name",
      "currentStock": 2,
      "recommendedReorder": 10,
      "urgency": "High | Medium",
      "reason": "High search volume and sales velocity in Zagazig branch."
    }
  ],
  "unstockedDemandInsights": [
    {
      "searchedTerm": "Customer Searched Device",
      "searchCount": 142,
      "recommendation": "Import order draft created: 15 units of searched model."
    }
  ],
  "overstockedPromotions": [
    {
      "productName": "Slower Moving Product",
      "suggestedDiscountPercent": 10,
      "promotionalAngle": "Flash deal bundle with free wireless earbuds."
    }
  ],
  "productOptimization": {
    "originalTitle": "${selectedProduct?.name || ''}",
    "improvedTitle": "Optimized SEO Title with Keywords",
    "improvedDescriptionEN": "Enhanced persuasive sales copy highlighting key selling points...",
    "improvedDescriptionAR": "وصف تسويقي محسن وجذاب بالعربية...",
    "recommendedAccessories": ["Accessory 1", "Accessory 2"],
    "bundleOffer": {
      "bundleTitle": "Power & Protection Combo",
      "items": ["Anker 100W GaN", "Hydrogel Guard"],
      "bundlePriceUSD": 99,
      "savingsUSD": 25
    },
    "pricingStrategy": "Maintain $1199 base price, offer 0% interest 12-month installment via Valu/CIB."
  },
  "purchaseOrderDrafts": [
    {
      "supplier": "Official Apple Authorized Distributor Egypt",
      "itemsToOrder": ["iPhone 16 Pro Max 512GB Natural Titanium x10"],
      "estimatedCostUSD": 10500,
      "notes": "Urgent restocking for weekend demand in Zagazig."
    }
  ]
}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: optimizerPrompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    let resultText = response.text || "{}";
    resultText = resultText.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();

    const parsedInsights = JSON.parse(resultText);

    return res.json({
      success: true,
      insights: parsedInsights,
      generatedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("AI Inventory Sales Optimizer Error:", error);
    return res.status(500).json({
      error: "Unable to process inventory sales optimization.",
      message: error.message,
    });
  }
});

// Phase 2: AI Visual Product Search Endpoint
app.post("/api/ai-visual-search", async (req, res) => {
  try {
    const { imageBase64, userNotes = "" } = req.body;
    const ai = getGenAI();

    const visualPrompt = `
You are an expert mobile hardware visual recognition system for ELSORY STORE (السوري ستور), Zagazig, Egypt.
Analyze the uploaded image of a smartphone, tablet, smartwatch, audio device, or accessory.

User additional notes: "${userNotes}"

Your task:
1. Identify the likely device brand, model, generation, color, and finish.
2. Determine confidence level (High: >85%, Medium: 60-85%, Low: <60%).
3. Highlight visible physical characteristics (e.g., camera module layout, titanium border, dynamic island, camera button, hinge type).
4. Provide a search query string to match store inventory.
5. Provide bilingual (English & Arabic) summary and matching store recommendations.

Return ONLY a valid JSON object matching this schema without markdown fences:
{
  "detectedBrand": "Apple | Samsung | Xiaomi | Anker | Nothing",
  "detectedModel": "Device Model Name",
  "confidenceScore": 94,
  "confidenceLevel": "High | Medium | Low",
  "visibleFeatures": ["Titanium frame", "Triple camera lens layout", "Dynamic Island"],
  "summaryEN": "Identified as Apple iPhone 16 Pro Max in Natural Titanium finish.",
  "summaryAR": "تم التعرف على الهاتف كـ آيفون 16 برو ماكس باللون التيتانيوم الطبيعي.",
  "searchKeywords": ["iPhone 16 Pro Max", "Apple", "Titanium"],
  "suggestedAlternatives": ["iPhone 15 Pro Max", "Samsung Galaxy S25 Ultra"],
  "lowConfidencePrompt": "If confidence is low, ask the customer for additional details (e.g. back cover brand logo or camera count)."
}
`;

    const parts: any[] = [{ text: visualPrompt }];

    if (imageBase64 && typeof imageBase64 === "string" && imageBase64.startsWith("data:image/")) {
      const match = imageBase64.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (match) {
        parts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2],
          },
        });
      }
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
      },
    });

    let resultText = response.text || "{}";
    resultText = resultText.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();
    const parsedData = JSON.parse(resultText);

    return res.json({
      success: true,
      analysis: parsedData,
      analyzedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("AI Visual Search Error:", error);
    return res.status(500).json({
      error: "Failed to analyze product image.",
      message: error.message,
    });
  }
});

// Vite server / Static files middleware
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true, host: "0.0.0.0", port: PORT },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ElSory Store Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
