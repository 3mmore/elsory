import React, { useState } from 'react';
import { X, Sparkles, Send, Loader2, Bot, User, ArrowRight, ShoppingBag } from 'lucide-react';
import { Product, Currency } from '../types';
import { PRODUCTS } from '../data/products';
import { formatPrice } from '../data/currencies';
import { safeFetch } from '../lib/apiClient';
import { adminStore } from '../lib/adminStore';

interface MapSource {
  title: string;
  uri: string;
}

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  recommendedProducts?: Product[];
  modeUsed?: string;
  modelUsed?: string;
  mapsSources?: MapSource[];
}

interface AIAssistantModalProps {
  currentCurrency: Currency;
  onClose: () => void;
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product) => void;
}

interface TypewriterTextProps {
  text: string;
  speed?: number;
  animate?: boolean;
  onTypingStep?: () => void;
  onComplete?: () => void;
}

const TypewriterText: React.FC<TypewriterTextProps> = ({
  text,
  speed = 12,
  animate = true,
  onTypingStep,
  onComplete,
}) => {
  const [displayedText, setDisplayedText] = useState(animate ? '' : text);
  const [isTyping, setIsTyping] = useState(animate);

  React.useEffect(() => {
    if (!animate) {
      setDisplayedText(text);
      setIsTyping(false);
      return;
    }

    setDisplayedText('');
    setIsTyping(true);
    let index = 0;
    const totalLength = text.length;

    const timer = setInterval(() => {
      index += Math.floor(Math.random() * 2) + 2;
      if (index >= totalLength) {
        setDisplayedText(text);
        setIsTyping(false);
        clearInterval(timer);
        onComplete?.();
      } else {
        setDisplayedText(text.slice(0, index));
        onTypingStep?.();
      }
    }, speed);

    return () => clearInterval(timer);
  }, [text, animate]);

  return (
    <span className="whitespace-pre-line relative">
      {displayedText}
      {isTyping && (
        <span className="inline-block w-1.5 h-4 bg-emerald-400 dark:bg-emerald-300 ml-1 translate-y-0.5 animate-pulse rounded-full" />
      )}
    </span>
  );
};

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  currentCurrency,
  onClose,
  onSelectProduct,
  onAddToCart,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: "Hello! I am ElSory Store AI (السوري ستور) — your personal luxury mobile hardware & repair concierge. Ask me for device recommendations, budget flagships, complex repair diagnostics, or store location lookup!",
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [typedMsgIds, setTypedMsgIds] = useState<Set<string>>(new Set(['welcome']));
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  React.useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // AI Intelligence Mode Selector
  const [aiMode, setAiMode] = useState<'general' | 'fast' | 'thinking' | 'maps'>('general');
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  // Auto-detect geolocation for Maps Grounding
  React.useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserLocation({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          });
        },
        () => {
          // Default to Zagazig, Egypt coordinates if geolocation denied
          setUserLocation({ latitude: 30.5877, longitude: 31.5020 });
        }
      );
    }
  }, []);

  // Quick preset filters
  const [selectedBudget, setSelectedBudget] = useState<string>('Flex');
  const [selectedUseCase, setSelectedUseCase] = useState<string>('Camera & Speed');
  const [selectedBrand, setSelectedBrand] = useState<string>('Any');

  const handleSendMessage = async (customPrompt?: string, overrideMode?: 'general' | 'fast' | 'thinking' | 'maps') => {
    const promptToSubmit = customPrompt || inputQuery;
    if (!promptToSubmit.trim() && !customPrompt) return;

    const activeMode = overrideMode || aiMode;

    const userMsgId = Date.now().toString();
    const newMsg: Message = { id: userMsgId, sender: 'user', text: promptToSubmit };

    // Auto-detect Egyptian phone numbers or lead contact details
    const phoneMatch = promptToSubmit.match(/(\+20|01)[0-9]{8,9}/g) || promptToSubmit.match(/[0-9]{11}/g);
    if (phoneMatch && phoneMatch.length > 0) {
      const extractedPhone = phoneMatch[0];
      adminStore.addLead({
        name: 'Inquiring Customer',
        phone: extractedPhone,
        messageSummary: promptToSubmit,
        source: 'AI Assistant',
      });
    }

    // Format previous conversation history for multi-turn context
    const currentHistory = messages.map(m => ({ sender: m.sender, text: m.text }));

    setMessages((prev) => [...prev, newMsg]);
    if (!customPrompt) setInputQuery('');
    setLoading(true);

    try {
      const response = await safeFetch('/api/ai-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToSubmit,
          mode: activeMode,
          userLocation: activeMode === 'maps' ? userLocation : undefined,
          conversationHistory: currentHistory,
          preferences: {
            budget: selectedBudget,
            useCase: selectedUseCase,
            brand: selectedBrand,
          },
        }),
      });

      const data = await response.json();

      const replyText = data.reply || "I recommend exploring our flagship smartphones or visiting our Zagazig store.";
      const matchedProducts = PRODUCTS.filter((p) => {
        const queryLower = (promptToSubmit + " " + replyText).toLowerCase();
        return (
          queryLower.includes(p.brand.toLowerCase()) ||
          queryLower.includes(p.name.toLowerCase()) ||
          (queryLower.includes('camera') && p.priceUSD > 1000) ||
          (queryLower.includes('gold') && p.badge === 'Luxury Edition')
        );
      }).slice(0, 3);

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: replyText,
        modeUsed: data.modeUsed,
        modelUsed: data.modelUsed,
        mapsSources: data.mapsSources || [],
        recommendedProducts: matchedProducts.length > 0 ? matchedProducts : PRODUCTS.slice(0, 2),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: "I recommend taking a look at the iPhone 16 Pro Max or Galaxy S25 Ultra for top tier performance, or Nothing Phone (2a) Plus for budget flagship excellence.",
          recommendedProducts: PRODUCTS.slice(0, 2),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-3xl w-full h-[85vh] flex flex-col text-white shadow-2xl relative my-auto overflow-hidden">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-zinc-900/90 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white text-black rounded-xl font-bold">
              <Sparkles className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white flex items-center gap-2">
                ElSory Store AI Specialist
              </h2>
              <p className="text-xs text-zinc-400">
                Multi-turn concierge powered by Gemini Models & Google Maps
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Intelligence Mode Selector Bar */}
        <div className="px-4 py-2 bg-zinc-900/90 border-b border-zinc-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-zinc-400 font-bold text-[11px] uppercase tracking-wider">AI Intelligence Mode:</span>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setAiMode('general')}
              className={`px-3 py-1.5 rounded-xl border font-bold text-[11px] transition-all cursor-pointer ${
                aiMode === 'general'
                  ? 'bg-white text-black border-white shadow-sm'
                  : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
              }`}
            >
              ✨ Standard (3.5 Flash)
            </button>

            <button
              onClick={() => setAiMode('fast')}
              className={`px-3 py-1.5 rounded-xl border font-bold text-[11px] transition-all cursor-pointer ${
                aiMode === 'fast'
                  ? 'bg-amber-400 text-black border-amber-400 shadow-sm'
                  : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
              }`}
            >
              ⚡ Fast Low-Latency (3.1 Lite)
            </button>

            <button
              onClick={() => setAiMode('thinking')}
              className={`px-3 py-1.5 rounded-xl border font-bold text-[11px] transition-all cursor-pointer ${
                aiMode === 'thinking'
                  ? 'bg-purple-500 text-white border-purple-500 shadow-sm'
                  : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
              }`}
            >
              🧠 High Thinking (3.1 Pro)
            </button>

            <button
              onClick={() => setAiMode('maps')}
              className={`px-3 py-1.5 rounded-xl border font-bold text-[11px] transition-all cursor-pointer ${
                aiMode === 'maps'
                  ? 'bg-emerald-500 text-black border-emerald-500 shadow-sm'
                  : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
              }`}
            >
              📍 Maps Grounding (Google Maps)
            </button>
          </div>
        </div>

        {/* Preset Requirement Chips */}
        <div className="p-3 bg-zinc-900/50 border-b border-zinc-800/80 text-xs flex flex-wrap items-center gap-2">
          <span className="text-zinc-500 font-bold uppercase tracking-wider text-[10px]">Sales Concierge Prompts:</span>
          <button
            onClick={() => handleSendMessage("Compare iPhone 16 Pro Max vs Samsung Galaxy S25 Ultra objectively. Which is better for 4K video recording and long battery life?", "general")}
            className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-full border border-zinc-700 cursor-pointer transition-colors"
          >
            ⚖️ iPhone 16 Pro Max vs S25 Ultra
          </button>
          <button
            onClick={() => handleSendMessage("What local Egyptian installment plans (Valu, Souhoola, Sympl, CIB 0%) and official store warranties are available at ElSory Store?", "general")}
            className="px-2.5 py-1 bg-blue-950/60 hover:bg-blue-900/80 text-blue-200 rounded-full border border-blue-800/80 cursor-pointer transition-colors"
          >
            💳 Installment Plans & Warranty
          </button>
          <button
            onClick={() => handleSendMessage("I am buying an iPhone 16 Pro Max. What genuine accessories (GaN chargers, MagSafe cases, AirPods) and protection plans do you recommend?", "general")}
            className="px-2.5 py-1 bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-200 rounded-full border border-emerald-800/80 cursor-pointer transition-colors"
          >
            🔌 Accessory & Protection Pairing
          </button>
          <button
            onClick={() => handleSendMessage("Deep technical analysis: Compare micro-soldering motherboard repair vs full board replacement for liquid damaged iPhone 15 Pro.", "thinking")}
            className="px-2.5 py-1 bg-purple-950/60 hover:bg-purple-900/80 text-purple-200 rounded-full border border-purple-800/80 cursor-pointer transition-colors"
          >
            🧠 Deep Hardware Diagnosis
          </button>
          <button
            onClick={() => handleSendMessage("Where is the official ElSory Store repair headquarters located in Zagazig, Egypt? Give me Google Maps directions.", "maps")}
            className="px-2.5 py-1 bg-amber-950/60 hover:bg-amber-900/80 text-amber-200 rounded-full border border-amber-800/80 cursor-pointer transition-colors"
          >
            📍 Find Store on Google Maps
          </button>
        </div>

        {/* Chat History */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'ai' && (
                <div className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center shrink-0 font-bold text-xs mt-1">
                  AI
                </div>
              )}

              <div className={`max-w-[85%] space-y-3 ${
                msg.sender === 'user' 
                  ? 'bg-white text-black p-4 rounded-2xl rounded-tr-none font-medium text-sm'
                  : 'bg-zinc-900 border border-zinc-800 p-4 rounded-2xl rounded-tl-none text-zinc-200 text-sm leading-relaxed'
              }`}>
                {msg.sender === 'ai' && msg.modeUsed && (
                  <div className="flex items-center gap-2 mb-1 text-[10px] font-mono text-zinc-400 border-b border-zinc-800 pb-1.5">
                    <span className="px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 font-bold uppercase">
                      Mode: {msg.modeUsed}
                    </span>
                    {msg.modelUsed && <span className="text-zinc-500">({msg.modelUsed})</span>}
                  </div>
                )}

                {msg.sender === 'ai' ? (
                  <TypewriterText
                    text={msg.text}
                    animate={!typedMsgIds.has(msg.id)}
                    onTypingStep={scrollToBottom}
                    onComplete={() => {
                      setTypedMsgIds((prev) => new Set(prev).add(msg.id));
                      scrollToBottom();
                    }}
                  />
                ) : (
                  <div className="whitespace-pre-line">{msg.text}</div>
                )}

                {/* Google Maps Grounding Sources Links */}
                {msg.mapsSources && msg.mapsSources.length > 0 && (
                  <div className="pt-2 border-t border-zinc-800/80 space-y-2">
                    <div className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                      📍 Verified Google Maps Locations & Sources:
                    </div>
                    <div className="flex flex-col gap-1.5">
                      {msg.mapsSources.map((src, idx) => (
                        <a
                          key={idx}
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2 bg-emerald-950/40 border border-emerald-800/60 hover:border-emerald-500 rounded-xl flex items-center justify-between text-xs text-emerald-200 transition-colors group"
                        >
                          <span className="font-semibold truncate">{src.title}</span>
                          <span className="text-[10px] bg-emerald-800/80 text-white px-2 py-0.5 rounded-lg group-hover:bg-emerald-600 font-bold transition-colors shrink-0">
                            Open in Maps ↗
                          </span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Recommended Product Cards inside AI message */}
                {msg.recommendedProducts && msg.recommendedProducts.length > 0 && (
                  <div className="pt-2 border-t border-zinc-800/80 space-y-2">
                    <div className="text-[11px] font-extrabold uppercase tracking-wider text-zinc-400">
                      Recommended Matches in ElSory Store:
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {msg.recommendedProducts.map((prod) => (
                        <div
                          key={prod.id}
                          className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between gap-3 group hover:border-zinc-500 transition-colors"
                        >
                          <div className="flex items-center gap-2.5 truncate">
                            <img src={prod.image} alt={prod.name} className="w-10 h-10 object-contain shrink-0" />
                            <div className="truncate">
                              <div className="font-bold text-white text-xs truncate">{prod.name}</div>
                              <div className="text-[11px] font-extrabold text-zinc-300">
                                {formatPrice(prod.priceUSD, currentCurrency)}
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={() => {
                              onSelectProduct(prod);
                              onClose();
                            }}
                            className="px-2.5 py-1 bg-white text-black rounded-lg text-[10px] font-bold hover:bg-zinc-200 transition-colors cursor-pointer shrink-0"
                          >
                            View
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-full bg-zinc-800 text-zinc-300 flex items-center justify-center shrink-0 font-bold text-xs mt-1">
                  You
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-3 text-zinc-400 text-sm">
              <div className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center font-bold text-xs">
                AI
              </div>
              <div className="bg-zinc-900 border border-zinc-800 p-3.5 rounded-2xl flex items-center gap-2 text-zinc-300">
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                <span>
                  {aiMode === 'thinking' && 'Processing high-level hardware reasoning (Gemini 3.1 Pro)...'}
                  {aiMode === 'fast' && 'Fetching low-latency response (Gemini 3.1 Flash Lite)...'}
                  {aiMode === 'maps' && 'Querying Google Maps location grounding...'}
                  {aiMode === 'general' && 'Consulting hardware specs & catalog...'}
                </span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-zinc-900 border-t border-zinc-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask anything e.g. 'Compare S25 Ultra vs iPhone 16 Pro Max battery'..."
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-zinc-500 placeholder-zinc-500"
            />
            <button
              type="submit"
              disabled={loading || !inputQuery.trim()}
              className="px-5 py-3 bg-white text-black hover:bg-zinc-200 disabled:opacity-50 font-bold rounded-xl text-sm transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
