import React, { useState } from 'react';
import { 
  X, 
  BarChart2, 
  TrendingUp, 
  Search, 
  Wrench, 
  MessageSquare, 
  AlertCircle, 
  DollarSign, 
  Sparkles, 
  ShoppingBag, 
  Users, 
  Download, 
  RefreshCw,
  PlusCircle,
  PackageCheck,
  Megaphone,
  Share2,
  Copy,
  Check,
  Zap,
  Target,
  Brain,
  MessageCircle,
  ShoppingCart,
  Send,
  Loader2,
  HelpCircle,
  AlertTriangle
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import Markdown from 'react-markdown';
import { Currency, Language, Product, Brand, Category } from '../types';
import { translations } from '../lib/i18n';
import { PRODUCTS } from '../data/products';
import { safeFetch } from '../lib/apiClient';

interface AdminAIDashboardModalProps {
  currentCurrency: Currency;
  lang: Language;
  onClose: () => void;
  onAddNewProduct?: (p: Partial<Product>) => void;
}

export const AdminAIDashboardModal: React.FC<AdminAIDashboardModalProps> = ({
  currentCurrency,
  lang,
  onClose,
  onAddNewProduct,
}) => {
  const [activeTab, setActiveTab] = useState<'marketing' | 'overview' | 'demand' | 'objections' | 'repairs' | 'inventory'>('marketing');
  
  // Marketing AI Advisor State
  const [marketingFocus, setMarketingFocus] = useState<string>('promotions');
  const [customMarketingPrompt, setCustomMarketingPrompt] = useState<string>('');
  const [marketingReport, setMarketingReport] = useState<string | null>(null);
  const [loadingReport, setLoadingReport] = useState<boolean>(false);
  const [copiedReport, setCopiedReport] = useState<boolean>(false);

  // Add Product Modal State
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [newProductName, setNewProductName] = useState('');
  const [newProductBrand, setNewProductBrand] = useState<Brand>('Apple');
  const [newProductPrice, setNewProductPrice] = useState<number>(999);
  const [newProductCategory, setNewProductCategory] = useState<Category>('Smartphones');
  const [newProductImage, setNewProductImage] = useState('https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80');

  const t = translations[lang];

  // Run AI Marketing Advisor Analysis
  const handleGenerateMarketingStrategy = async (focusArea: string, promptOverride?: string) => {
    setLoadingReport(true);
    setMarketingFocus(focusArea);

    try {
      const response = await safeFetch('/api/ai-marketing-analyst', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          focusArea,
          customPrompt: promptOverride || customMarketingPrompt,
        }),
      });

      const data = await response.json();
      if (data.report) {
        setMarketingReport(data.report);
      } else {
        setMarketingReport("Strategy report generated successfully.");
      }
    } catch (err) {
      console.error("Failed to generate marketing report:", err);
      setMarketingReport("⚠️ Error connecting to AI Marketing Strategist. Please check server logs.");
    } finally {
      setLoadingReport(false);
    }
  };

  const handleCopyReport = () => {
    if (!marketingReport) return;
    navigator.clipboard.writeText(marketingReport);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2000);
  };

  const handleCreateProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductName.trim()) return;

    if (onAddNewProduct) {
      onAddNewProduct({
        id: `custom-${Date.now()}`,
        name: newProductName,
        brand: newProductBrand,
        category: newProductCategory,
        priceUSD: Number(newProductPrice),
        rating: 5.0,
        reviewsCount: 1,
        description: `${newProductName} - Official ElSory Store Verified Import.`,
        features: ['1-Year Store Warranty', 'Fast Charging', 'High Resolution OLED'],
        image: newProductImage,
        gallery: [newProductImage],
        colors: [{ name: 'Default', hex: '#18181b' }],
        specsDetail: {
          display: '6.7-inch OLED 120Hz',
          chipset: 'High Performance Flagship SoC',
          mainCamera: '50MP Ultra-Clarity Camera System',
          selfieCamera: '32MP HDR Camera',
          battery: '5000 mAh All-Day Power',
          charging: '65W Fast Charging',
          weight: '198g',
          network: '5G Dual SIM',
          os: 'Latest OS',
          waterResistance: 'IP68 Certified',
        },
        inStock: true,
        warrantyYears: 1,
      });
    }

    setShowAddModal(false);
    setNewProductName('');
    setActiveTab('inventory');
  };

  // Sample analytics data reflecting real customer interactions & search metrics
  const searchTrendsData = [
    { day: 'Mon', iPhone: 120, Galaxy: 95, Xiaomi: 65, Repair: 88 },
    { day: 'Tue', iPhone: 145, Galaxy: 110, Xiaomi: 80, Repair: 102 },
    { day: 'Wed', iPhone: 160, Galaxy: 130, Xiaomi: 92, Repair: 115 },
    { day: 'Thu', iPhone: 180, Galaxy: 140, Xiaomi: 110, Repair: 130 },
    { day: 'Fri', iPhone: 240, Galaxy: 195, Xiaomi: 145, Repair: 175 },
    { day: 'Sat', iPhone: 310, Galaxy: 250, Xiaomi: 190, Repair: 210 },
    { day: 'Sun', iPhone: 280, Galaxy: 220, Xiaomi: 160, Repair: 190 },
  ];

  const topSearchedProducts = [
    { name: 'iPhone 16 Pro Max', queries: 1420, percent: '34%' },
    { name: 'Samsung Galaxy S25 Ultra', queries: 1180, percent: '28%' },
    { name: 'iPhone Screen & OLED Replacement', queries: 850, percent: '20%' },
    { name: 'Xiaomi 15 Ultra', queries: 490, percent: '12%' },
    { name: 'Nothing Phone (2a) Plus', queries: 310, percent: '6%' },
  ];

  const requestedBrandsData = [
    { name: 'Apple', value: 45, color: '#e2e8f0' },
    { name: 'Samsung', value: 25, color: '#3b82f6' },
    { name: 'Xiaomi', value: 12, color: '#f97316' },
    { name: 'Honor/Huawei', value: 10, color: '#10b981' },
    { name: 'Others', value: 8, color: '#a855f7' },
  ];

  const topRepairInquiries = [
    { service: 'iPhone OLED Screen & TrueTone', count: 480, revenueEGP: '1,968,000 ج.م' },
    { service: 'Original Battery Health Restoration', count: 320, revenueEGP: '544,000 ج.م' },
    { service: 'Precision Laser Back Glass Removal', count: 210, revenueEGP: '462,000 ج.م' },
    { service: 'Motherboard Micro-Soldering (Power IC)', count: 140, revenueEGP: '511,000 ج.م' },
  ];

  const unavailableDemandList = [
    { name: 'Sony Xperia 1 VI', requests: 84, action: 'Import Order Suggested' },
    { name: 'Asus ROG Phone 8 Pro', requests: 62, action: 'Gaming Niche Demand' },
    { name: 'Google Pixel Fold 2', requests: 45, action: 'VIP Customer Request' },
    { name: 'Vivo X200 Pro Mini', requests: 38, action: 'Compact Flagship Demand' },
  ];

  const slowMovingInventory = [
    { name: 'Apple Watch Ultra 2', velocity: 'Slow (12 days/unit)', stock: 8, recommendation: 'Bundle with iPhone 16 Pro Max at 10% off accessories' },
    { name: 'Anker MagGo Power Bank', velocity: 'Moderate (5 days/unit)', stock: 15, recommendation: 'Offer as free gift on 24K Gold Syria Edition' },
    { name: 'iPad Pro M4 13-inch', velocity: 'Slow (14 days/unit)', stock: 6, recommendation: 'Target Zagazig design studios with 0% interest CIB plan' },
  ];

  const customerObjectionsData = [
    { objection: 'Price higher than unofficial grey market', frequency: '38%', aiResolution: 'Emphasize 1-Year Store Warranty & Genuine TrueTone Certified Hardware' },
    { objection: 'Unsure whether 256GB vs 512GB is needed', frequency: '29%', aiResolution: 'Explain ProRes 4K 60fps video recording storage calculations' },
    { objection: 'Concerned about repair duration', frequency: '22%', aiResolution: 'Highlight 45-minute Zagazig Express same-day repair turnaround' },
    { objection: 'Prefers local Egyptian installment plan', frequency: '11%', aiResolution: 'Promote Valu, Souhoola, Sympl & CIB 0% interest options' },
  ];

  const cartAbandonmentInsights = [
    { stage: 'Added to Cart', count: 850, rate: '100%' },
    { stage: 'Started Checkout', count: 520, rate: '61%' },
    { stage: 'Payment Method Selected', count: 340, rate: '40%' },
    { stage: 'Order Completed', count: 280, rate: '33%' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-6xl w-full max-h-[92vh] flex flex-col text-white shadow-2xl relative my-auto overflow-hidden">
        
        {/* Top Header */}
        <div className="p-5 bg-zinc-900 border-b border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white text-black rounded-2xl font-bold">
              <Brain className="w-6 h-6 text-black" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-white">
                  ElSory AI Sales & Marketing Intelligence
                </h2>
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Admin Suite
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Strategic Marketing Advisor, Customer Sales Insights & Real Inventory Analytics
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-1.5 bg-white text-black hover:bg-zinc-200 transition-colors px-3.5 py-2 rounded-xl text-xs font-bold shadow cursor-pointer"
            >
              <PlusCircle className="w-4 h-4 text-black" />
              <span>Add New Product</span>
            </button>

            <button
              onClick={onClose}
              className="p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Bar */}
        <div className="flex items-center gap-2 px-5 py-3 bg-zinc-900/60 border-b border-zinc-800 text-xs font-semibold overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveTab('marketing')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'marketing' ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-extrabold shadow-md' : 'text-zinc-400 hover:text-white bg-zinc-900/40'
            }`}
          >
            <Megaphone className="w-4 h-4" />
            <span>🤖 AI Marketing Strategist</span>
          </button>

          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'overview' ? 'bg-white text-black font-extrabold' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Sales & Search Trends</span>
          </button>

          <button
            onClick={() => setActiveTab('demand')}
            className={`px-4 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'demand' ? 'bg-white text-black font-extrabold' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>Demand Loss & Slow Inventory</span>
          </button>

          <button
            onClick={() => setActiveTab('objections')}
            className={`px-4 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'objections' ? 'bg-white text-black font-extrabold' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Customer Behavior & Objections</span>
          </button>

          <button
            onClick={() => setActiveTab('repairs')}
            className={`px-4 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'repairs' ? 'bg-white text-black font-extrabold' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Wrench className="w-4 h-4" />
            <span>Repair Center Analytics</span>
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-4 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'inventory' ? 'bg-white text-black font-extrabold' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <PackageCheck className="w-4 h-4" />
            <span>Store Catalog & AI Verification</span>
          </button>
        </div>

        {/* Modal Main Body */}
        <div className="flex-1 p-5 overflow-y-auto space-y-6">
          
          {/* Key KPI Summary Banner */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl">
              <div className="flex items-center justify-between text-zinc-400 text-xs">
                <span>AI Sales Interactions</span>
                <MessageSquare className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-white mt-1">1,842</div>
              <div className="text-[10px] text-emerald-400 font-bold mt-1">100% Zero-Hallucination Stock Verified</div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl">
              <div className="flex items-center justify-between text-zinc-400 text-xs">
                <span>Sales Conversion Rate</span>
                <TrendingUp className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-white mt-1">14.2%</div>
              <div className="text-[10px] text-emerald-400 font-bold mt-1">High conversion in Zagazig district</div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl">
              <div className="flex items-center justify-between text-zinc-400 text-xs">
                <span>Most Demanded Brand</span>
                <ShoppingBag className="w-4 h-4 text-blue-400" />
              </div>
              <div className="text-2xl font-black text-white mt-1">Apple (45%)</div>
              <div className="text-[10px] text-zinc-400 font-bold mt-1">Followed by Samsung (25%) & Xiaomi (12%)</div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl">
              <div className="flex items-center justify-between text-zinc-400 text-xs">
                <span>Unstocked Demand Gaps</span>
                <AlertCircle className="w-4 h-4 text-rose-400" />
              </div>
              <div className="text-2xl font-black text-white mt-1">229</div>
              <div className="text-[10px] text-rose-400 font-bold mt-1">Auto-invited to WhatsApp for Custom Import</div>
            </div>
          </div>

          {/* TAB 1: AI MARKETING STRATEGIST (ADMIN MARKETING ADVISOR) */}
          {activeTab === 'marketing' && (
            <div className="space-y-6">
              
              {/* Preset Campaign Generator Controls */}
              <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-400" />
                    <h3 className="font-extrabold text-white text-base">Generate Strategic Growth & Campaign Blueprint</h3>
                  </div>
                  <span className="text-[10px] font-mono text-purple-300 bg-purple-950/80 border border-purple-800/80 px-2.5 py-1 rounded-lg">
                    Gemini 3.1 Pro (Thinking Mode)
                  </span>
                </div>

                <p className="text-xs text-zinc-400 leading-relaxed">
                  Select a marketing focus area below or enter a custom prompt. The AI Marketing Advisor will analyze store metrics, inventory velocity, repair inquiries, and local customer behavior in Zagazig to generate actionable campaign scripts, ad copy, and sales strategies.
                </p>

                {/* Focus Buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    onClick={() => handleGenerateMarketingStrategy('promotions')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      marketingFocus === 'promotions'
                        ? 'bg-purple-500 text-white shadow-md'
                        : 'bg-zinc-950 text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>⚡ Flash Deals & High-Margin Bundles</span>
                  </button>

                  <button
                    onClick={() => handleGenerateMarketingStrategy('slow_inventory')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      marketingFocus === 'slow_inventory'
                        ? 'bg-purple-500 text-white shadow-md'
                        : 'bg-zinc-950 text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                    }`}
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    <span>🚨 Slow-Moving Stock Clearance Plan</span>
                  </button>

                  <button
                    onClick={() => handleGenerateMarketingStrategy('social_ads')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      marketingFocus === 'social_ads'
                        ? 'bg-purple-500 text-white shadow-md'
                        : 'bg-zinc-950 text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                    }`}
                  >
                    <Share2 className="w-3.5 h-3.5 text-blue-400" />
                    <span>📲 WhatsApp, Meta & TikTok Ad Creatives</span>
                  </button>

                  <button
                    onClick={() => handleGenerateMarketingStrategy('cross_sell')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      marketingFocus === 'cross_sell'
                        ? 'bg-purple-500 text-white shadow-md'
                        : 'bg-zinc-950 text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                    }`}
                  >
                    <Target className="w-3.5 h-3.5 text-emerald-400" />
                    <span>💡 Cross-Sell & Accessory Pairing</span>
                  </button>

                  <button
                    onClick={() => handleGenerateMarketingStrategy('seasonal')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      marketingFocus === 'seasonal'
                        ? 'bg-purple-500 text-white shadow-md'
                        : 'bg-zinc-950 text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                    }`}
                  >
                    <Megaphone className="w-3.5 h-3.5 text-indigo-400" />
                    <span>🎁 Holiday & Loyalty Campaigns</span>
                  </button>
                </div>

                {/* Custom Marketing Query Input */}
                <div className="pt-2 flex items-center gap-2">
                  <input
                    type="text"
                    value={customMarketingPrompt}
                    onChange={(e) => setCustomMarketingPrompt(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleGenerateMarketingStrategy('custom');
                      }
                    }}
                    placeholder="e.g. Write a WhatsApp campaign for 24K Gold Syria Edition iPhone 16 Pro Max targeting luxury buyers in Zagazig..."
                    className="flex-1 bg-zinc-950 border border-zinc-800 focus:border-purple-500 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-500 outline-none"
                  />
                  <button
                    onClick={() => handleGenerateMarketingStrategy('custom')}
                    disabled={loadingReport}
                    className="px-4 py-2.5 bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold text-xs rounded-xl hover:opacity-90 transition-opacity flex items-center gap-1.5 shrink-0 cursor-pointer disabled:opacity-50"
                  >
                    {loadingReport ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    <span>Generate Analysis</span>
                  </button>
                </div>
              </div>

              {/* Generated Strategy Output Area */}
              {loadingReport && (
                <div className="p-8 bg-zinc-900/90 border border-zinc-800 rounded-2xl flex flex-col items-center justify-center text-center space-y-3">
                  <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
                  <div className="space-y-1">
                    <h4 className="font-extrabold text-white text-sm">Processing Strategic Analysis...</h4>
                    <p className="text-xs text-zinc-400 max-w-md">
                      Gemini 3.1 Pro is evaluating sales velocity, search logs, repair revenue, and campaign return-on-ad-spend (ROAS)...
                    </p>
                  </div>
                </div>
              )}

              {!loadingReport && marketingReport && (
                <div className="bg-zinc-900/90 border border-zinc-800 p-6 rounded-2xl space-y-4 relative">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                    <div className="flex items-center gap-2">
                      <Brain className="w-5 h-5 text-purple-400" />
                      <h4 className="font-extrabold text-white text-sm uppercase tracking-wider">
                        Strategic Marketing Intelligence & Action Plan
                      </h4>
                    </div>

                    <button
                      onClick={handleCopyReport}
                      className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      {copiedReport ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied to Clipboard!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-zinc-400" />
                          <span>Copy Strategy / Ad Copy</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Formatted Markdown Analysis Body */}
                  <div className="prose prose-invert prose-xs max-w-none text-zinc-300 leading-relaxed space-y-3">
                    <Markdown>{marketingReport}</Markdown>
                  </div>
                </div>
              )}

              {!loadingReport && !marketingReport && (
                <div className="p-8 bg-zinc-900/50 border border-dashed border-zinc-800 rounded-2xl text-center text-zinc-500 text-xs">
                  Click any strategy focus button above or submit a custom query to generate a complete marketing & campaign blueprint.
                </div>
              )}

            </div>
          )}

          {/* TAB 2: OVERVIEW & SEARCH TRENDS */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-extrabold text-white text-base">Weekly Search Traffic & Interest Curves</h3>
                    <p className="text-xs text-zinc-400">Comparing customer queries for iPhone, Samsung, Xiaomi & Repairs in Zagazig</p>
                  </div>
                </div>

                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={searchTrendsData}>
                      <XAxis dataKey="day" stroke="#71717a" fontSize={12} />
                      <YAxis stroke="#71717a" fontSize={12} />
                      <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', color: '#fff', borderRadius: '12px' }} />
                      <Area type="monotone" dataKey="iPhone" stroke="#e2e8f0" fill="#e2e8f0" fillOpacity={0.15} />
                      <Area type="monotone" dataKey="Galaxy" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.15} />
                      <Area type="monotone" dataKey="Repair" stroke="#10b981" fill="#10b981" fillOpacity={0.15} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Brand Distribution Pie */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl flex flex-col justify-between">
                  <h3 className="font-extrabold text-white text-base mb-2">Customer Brand Preference Distribution</h3>
                  <div className="h-52 w-full flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={requestedBrandsData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={50}
                          outerRadius={80}
                          paddingAngle={5}
                        >
                          {requestedBrandsData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', borderRadius: '12px' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-zinc-300">
                    {requestedBrandsData.map((b) => (
                      <span key={b.name} className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: b.color }} />
                        {b.name} ({b.value}%)
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
                  <h3 className="font-extrabold text-white text-base">Cart Conversion Funnel</h3>
                  <div className="space-y-3">
                    {cartAbandonmentInsights.map((stage, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-white">{stage.stage}</span>
                          <span className="text-zinc-400 font-mono">{stage.count} sessions ({stage.rate})</span>
                        </div>
                        <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-emerald-400 rounded-full transition-all duration-500" 
                            style={{ width: stage.rate }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: DEMAND LOSS & SLOW INVENTORY */}
          {activeTab === 'demand' && (
            <div className="space-y-6">
              <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
                <div>
                  <h3 className="font-extrabold text-white text-base">Top Searched Devices (Catalog Demand)</h3>
                  <p className="text-xs text-zinc-400">Devices searched directly by customers in ElSory Store</p>
                </div>

                <div className="space-y-3">
                  {topSearchedProducts.map((item, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-white">{item.name}</span>
                        <span className="text-zinc-400 font-mono">{item.queries} searches ({item.percent})</span>
                      </div>
                      <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-white rounded-full transition-all duration-500" 
                          style={{ width: item.percent }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Unavailable Demand List & Slow Moving Stock */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-extrabold text-white text-base">Requested Unstocked Devices</h3>
                      <p className="text-xs text-zinc-400">AI Assistant automatically invited these customers to WhatsApp for custom order</p>
                    </div>
                    <span className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 font-bold px-2 py-0.5 rounded">
                      Zero Hallucination
                    </span>
                  </div>

                  <div className="space-y-2">
                    {unavailableDemandList.map((item, idx) => (
                      <div key={idx} className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between">
                        <div>
                          <div className="font-extrabold text-white text-xs">{item.name}</div>
                          <div className="text-[10px] text-zinc-400 mt-0.5">{item.requests} customer queries</div>
                        </div>
                        <span className="text-[10px] bg-zinc-800 text-zinc-300 font-semibold px-2 py-1 rounded">
                          {item.action}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
                  <h3 className="font-extrabold text-white text-base">Slow-Moving Stock Detection</h3>
                  <div className="space-y-3">
                    {slowMovingInventory.map((inv, idx) => (
                      <div key={idx} className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-white">{inv.name}</span>
                          <span className="text-rose-400 font-mono text-[10px]">{inv.velocity}</span>
                        </div>
                        <p className="text-[11px] text-purple-300 font-medium">💡 AI Action: {inv.recommendation}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CUSTOMER BEHAVIOR & OBJECTIONS */}
          {activeTab === 'objections' && (
            <div className="space-y-6">
              <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
                <div>
                  <h3 className="font-extrabold text-white text-base">Customer Objection Analytics</h3>
                  <p className="text-xs text-zinc-400">
                    The AI Sales Consultant resolves these objections transparently to build customer trust
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {customerObjectionsData.map((obj, idx) => (
                    <div key={idx} className="p-4 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-400">Objection #{idx + 1} ({obj.frequency})</span>
                        <span className="text-[10px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded font-bold">
                          Handled by AI
                        </span>
                      </div>
                      <div className="font-extrabold text-white text-sm">"{obj.objection}"</div>
                      <div className="text-xs text-emerald-400 pt-2 border-t border-zinc-800 flex items-start gap-1.5">
                        <Check className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{obj.aiResolution}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: REPAIR CENTER ANALYTICS */}
          {activeTab === 'repairs' && (
            <div className="space-y-6">
              <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
                <div>
                  <h3 className="font-extrabold text-white text-base">Zagazig Mobile Repair Center Insights</h3>
                  <p className="text-xs text-zinc-400">Most requested micro-repairs and hardware services</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {topRepairInquiries.map((repair, idx) => (
                    <div key={idx} className="p-4 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-400">Rank #{idx + 1}</span>
                        <span className="text-xs font-bold text-white bg-zinc-800 px-2 py-0.5 rounded">
                          {repair.count} Bookings
                        </span>
                      </div>
                      <div className="font-extrabold text-white text-sm">{repair.service}</div>
                      <div className="text-xs text-zinc-400 flex items-center justify-between pt-2 border-t border-zinc-800">
                        <span>Est. Total Value:</span>
                        <span className="font-extrabold text-white">{repair.revenueEGP}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: STORE CATALOG & AI VERIFICATION */}
          {activeTab === 'inventory' && (
            <div className="space-y-6">
              <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-white text-base">Real Inventory Verification Log</h3>
                    <p className="text-xs text-zinc-400">The AI Assistant verifies stock against this live inventory array before responding</p>
                  </div>
                  <button
                    onClick={() => setShowAddModal(true)}
                    className="flex items-center gap-1.5 bg-white text-black font-bold px-3 py-1.5 rounded-lg text-xs hover:bg-zinc-200 cursor-pointer"
                  >
                    <PlusCircle className="w-3.5 h-3.5 text-black" />
                    <span>Add Item</span>
                  </button>
                </div>

                <div className="divide-y divide-zinc-800 max-h-72 overflow-y-auto">
                  {PRODUCTS.map((prod) => (
                    <div key={prod.id} className="py-2.5 flex items-center justify-between gap-4 text-xs">
                      <div className="flex items-center gap-3">
                        <img src={prod.image} alt={prod.name} className="w-8 h-8 object-contain shrink-0" />
                        <div>
                          <div className="font-bold text-white">{prod.name}</div>
                          <div className="text-[10px] text-zinc-400">{prod.brand} &bull; {prod.category}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <span className="font-extrabold text-white">${prod.priceUSD}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          prod.inStock ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/10 text-rose-400'
                        }`}>
                          {prod.inStock ? 'In Stock' : 'Out of Stock'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal for Adding New Product */}
        {showAddModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-zinc-900 border border-zinc-700 rounded-2xl p-6 max-w-md w-full space-y-4 text-white shadow-2xl">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <h3 className="font-extrabold text-base">Add Product to ElSory Catalog</h3>
                <button onClick={() => setShowAddModal(false)} className="text-zinc-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateProductSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block text-zinc-400 mb-1 font-bold">Product Name</label>
                  <input
                    type="text"
                    required
                    value={newProductName}
                    onChange={(e) => setNewProductName(e.target.value)}
                    placeholder="e.g. Xiaomi 15 Ultra 5G"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white outline-none focus:border-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-zinc-400 mb-1 font-bold">Brand</label>
                    <select
                      value={newProductBrand}
                      onChange={(e) => setNewProductBrand(e.target.value as Brand)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                    >
                      <option value="Apple">Apple</option>
                      <option value="Samsung">Samsung</option>
                      <option value="Xiaomi">Xiaomi</option>
                      <option value="Google">Google</option>
                      <option value="Nothing">Nothing</option>
                      <option value="Honor">Honor</option>
                      <option value="Huawei">Huawei</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-zinc-400 mb-1 font-bold">Price (USD)</label>
                    <input
                      type="number"
                      required
                      value={newProductPrice}
                      onChange={(e) => setNewProductPrice(Number(e.target.value))}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-zinc-400 mb-1 font-bold">Image URL</label>
                  <input
                    type="text"
                    value={newProductImage}
                    onChange={(e) => setNewProductImage(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                  />
                </div>

                <div className="pt-3 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 bg-zinc-800 text-zinc-300 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-white text-black rounded-xl font-bold hover:bg-zinc-200"
                  >
                    Add Product
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
