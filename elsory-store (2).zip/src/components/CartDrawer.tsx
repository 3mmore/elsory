import React, { useState } from 'react';
import { X, ShoppingBag, Trash2, Tag, ArrowRight, ShieldCheck, Check } from 'lucide-react';
import { CartItem, Currency } from '../types';
import { formatPrice } from '../data/currencies';
import { ProgressiveImage } from './ProgressiveImage';

const WhatsAppIcon = ({ className = "w-4 h-4" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.029 6.987 2.894a9.825 9.825 0 012.882 6.985c-.001 5.45-4.436 9.884-9.871 9.884M12.05 2c-5.833 0-10.58 4.747-10.58 10.58 0 1.865.488 3.687 1.416 5.297L1 23l5.292-1.388a10.53 10.53 0 005.752 1.688h.005c5.831 0 10.578-4.747 10.578-10.58A10.518 10.518 0 0012.05 2z" />
  </svg>
);

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  currentCurrency: Currency;
  discountUSD: number;
  onApplyDiscount: (code: string, amountUSD: number) => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  currentCurrency,
  discountUSD,
  onApplyDiscount,
  onProceedToCheckout,
}) => {
  if (!isOpen) return null;

  const [promoInput, setPromoInput] = useState('');
  const [promoSuccessMsg, setPromoSuccessMsg] = useState('');

  const subtotalUSD = cartItems.reduce((acc, item) => acc + item.priceUSD * item.quantity, 0);
  const shippingUSD = subtotalUSD > 0 ? (subtotalUSD > 1000 ? 0 : 25) : 0;
  const grandTotalUSD = Math.max(0, subtotalUSD - discountUSD + shippingUSD);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoInput.trim().toUpperCase() === 'SYRIAN2026') {
      const discount = subtotalUSD * 0.10; // 10% discount
      onApplyDiscount('SYRIAN2026', discount);
      setPromoSuccessMsg('10% VIP Coupon Applied!');
    } else if (promoInput.toUpperCase().startsWith('SYR-TRADE-')) {
      onApplyDiscount(promoInput, 550);
      setPromoSuccessMsg('Trade-In Credit Applied!');
    } else {
      setPromoSuccessMsg('Invalid Coupon Code. Try SYRIAN2026');
    }
  };

  const handleWhatsAppCartOrder = () => {
    if (cartItems.length === 0) return;

    const itemsSummary = cartItems
      .map((item, index) => {
        const colorStr = item.selectedColor ? ` (Color: ${item.selectedColor.name})` : '';
        const storageStr = item.selectedStorage ? ` [${item.selectedStorage}]` : '';
        const itemPrice = formatPrice(item.priceUSD * item.quantity, currentCurrency);
        return `${index + 1}. *${item.product.name}*${colorStr}${storageStr} x${item.quantity} — ${itemPrice}`;
      })
      .join('\n');

    const subtotalFormatted = formatPrice(subtotalUSD, currentCurrency);
    const discountFormatted = discountUSD > 0 ? `\n🏷️ *Discount:* -${formatPrice(discountUSD, currentCurrency)}` : '';
    const shippingFormatted = shippingUSD === 0 ? 'FREE' : formatPrice(shippingUSD, currentCurrency);
    const grandTotalFormatted = formatPrice(grandTotalUSD, currentCurrency);

    const message = `Hello ElSory Store (السوري ستور)! 👋\n\nI would like to place a quick order for my shopping bag items:\n\n🛒 *Order Items:*\n${itemsSummary}\n\n--------------------------------\n💵 *Subtotal:* ${subtotalFormatted}${discountFormatted}\n🚚 *Shipping:* ${shippingFormatted}\n💰 *Grand Total:* ${grandTotalFormatted}\n\n📍 Please confirm stock availability at Zagazig store and arrange express courier delivery. Thank you!`;

    const url = `https://wa.me/201012345678?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div onClick={onClose} className="absolute inset-0 bg-black/75 backdrop-blur-sm transition-opacity" />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-zinc-950 border-l border-zinc-800 text-white shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-white" />
              <h2 className="text-lg font-bold uppercase tracking-wider text-white">Your Shopping Bag</h2>
              <span className="bg-zinc-800 text-zinc-300 text-xs font-bold px-2 py-0.5 rounded-full">
                {cartItems.length}
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-600 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cartItems.length === 0 ? (
              <div className="text-center my-auto py-20 space-y-4 text-zinc-500">
                <ShoppingBag className="w-12 h-12 mx-auto stroke-1" />
                <p className="text-sm font-medium">Your shopping bag is empty.</p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-white text-black font-bold rounded-xl text-xs hover:bg-zinc-200 transition-colors"
                >
                  Browse Flagship Store
                </button>
              </div>
            ) : (
              cartItems.map((item) => (
                <div
                  key={item.id}
                  className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-between gap-4"
                >
                  <ProgressiveImage
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-contain shrink-0"
                  />

                  <div className="flex-1 min-w-0 space-y-1">
                    <h3 className="text-sm font-bold text-white truncate">{item.product.name}</h3>
                    <div className="text-xs text-zinc-400 flex items-center gap-2">
                      <span>{item.selectedColor.name}</span>
                      {item.selectedStorage && (
                        <>
                          <span>&bull;</span>
                          <span>{item.selectedStorage}</span>
                        </>
                      )}
                    </div>
                    <div className="text-xs font-bold text-white">
                      {formatPrice(item.priceUSD, currentCurrency)}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-zinc-500 hover:text-red-400 transition-colors p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <div className="flex items-center bg-zinc-950 border border-zinc-800 rounded-lg p-0.5 text-xs">
                      <button
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="w-6 h-6 text-zinc-400 hover:text-white flex items-center justify-center font-bold"
                      >
                        -
                      </button>
                      <span className="w-6 text-center font-bold text-white">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="w-6 h-6 text-zinc-400 hover:text-white flex items-center justify-center font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Summary & Checkout Footer */}
          {cartItems.length > 0 && (
            <div className="p-6 bg-zinc-900 border-t border-zinc-800 space-y-4">
              {/* Promo Code Form */}
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Promo Code (SYRIAN2026)"
                  value={promoInput}
                  onChange={(e) => setPromoInput(e.target.value)}
                  className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-zinc-500 uppercase font-mono"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0"
                >
                  Apply
                </button>
              </form>

              {promoSuccessMsg && (
                <div className="text-[11px] font-semibold text-emerald-400">
                  {promoSuccessMsg}
                </div>
              )}

              {/* Cost Calculations */}
              <div className="space-y-1.5 text-xs text-zinc-400">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="text-white font-medium">{formatPrice(subtotalUSD, currentCurrency)}</span>
                </div>

                {discountUSD > 0 && (
                  <div className="flex justify-between text-emerald-400 font-semibold">
                    <span>Discount</span>
                    <span>-{formatPrice(discountUSD, currentCurrency)}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Express Shipping</span>
                  <span className="text-white font-medium">
                    {shippingUSD === 0 ? 'FREE (Over $1000)' : formatPrice(shippingUSD, currentCurrency)}
                  </span>
                </div>

                <div className="flex justify-between pt-2 border-t border-zinc-800 text-sm font-extrabold text-white">
                  <span>Grand Total</span>
                  <span className="text-lg">{formatPrice(grandTotalUSD, currentCurrency)}</span>
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <button
                  onClick={onProceedToCheckout}
                  className="w-full py-3.5 bg-zinc-900 dark:bg-white text-white dark:text-black hover:bg-zinc-800 dark:hover:bg-zinc-200 font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={handleWhatsAppCartOrder}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-[0.98]"
                >
                  <WhatsAppIcon className="w-4 h-4 text-white shrink-0" />
                  <span>Quick Order Bag via WhatsApp</span>
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
