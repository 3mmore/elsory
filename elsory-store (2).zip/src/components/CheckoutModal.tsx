import React, { useState } from 'react';
import { X, CheckCircle, Truck, CreditCard, ShieldCheck, ArrowRight, Loader2, Lock, Smartphone } from 'lucide-react';
import { CartItem, Currency, Order } from '../types';
import { formatPrice } from '../data/currencies';
import { sanitizeInput, generateTransactionNonce } from '../lib/security';

interface CheckoutModalProps {
  cartItems: CartItem[];
  currentCurrency: Currency;
  discountUSD: number;
  onClose: () => void;
  onOrderCompleted: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  cartItems,
  currentCurrency,
  discountUSD,
  onClose,
  onOrderCompleted,
}) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('Zagazig (الزقازيق - مصر)');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  const [shippingMethod, setShippingMethod] = useState<'Zagazig Express' | 'Egypt Nationwide' | 'Store Pickup'>('Zagazig Express');
  const [paymentMethod, setPaymentMethod] = useState<'Cash on Delivery' | 'InstaPay / Vodafone Cash' | 'Credit Card' | 'Crypto (USDT)'>('Cash on Delivery');

  const [isSubmitting, setIsSubmitting] = useState(false);

  const subtotalUSD = cartItems.reduce((acc, item) => acc + item.priceUSD * item.quantity, 0);
  const shippingUSD = shippingMethod === 'Store Pickup' ? 0 : (subtotalUSD > 1000 ? 0 : 25);
  const totalUSD = Math.max(0, subtotalUSD - discountUSD + shippingUSD);

  const [paymobIframeUrl, setPaymobIframeUrl] = useState<string | null>(null);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !phone || !address) {
      alert('Please fill in your name, phone number, and delivery address.');
      return;
    }

    setIsSubmitting(true);

    const safeName = sanitizeInput(fullName);
    const safePhone = sanitizeInput(phone);
    const safeEmail = sanitizeInput(email);
    const safeAddress = sanitizeInput(address);
    const safeNotes = sanitizeInput(notes);
    const orderId = `ELSORY-${Math.floor(100000 + Math.random() * 900000)}`;

    const newOrder: Order = {
      orderId,
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      items: cartItems,
      subtotalUSD,
      discountUSD,
      shippingUSD,
      totalUSD,
      currency: currentCurrency,
      totalConvertedFormatted: formatPrice(totalUSD, currentCurrency),
      status: paymentMethod === 'Credit Card' ? 'Pending Payment' : 'Confirmed',
      customerInfo: { 
        fullName: safeName, 
        email: safeEmail || 'customer@elsory.eg', 
        phone: safePhone, 
        city, 
        address: safeAddress, 
        notes: safeNotes 
      },
      shippingMethod: shippingMethod as any,
      paymentMethod: paymentMethod as any,
      trackingEvents: [
        {
          title: 'Order Verified & Secured',
          timestamp: 'Just Now',
          location: 'ElSory Store HQ - Zagazig (Villas El Gamea)',
          completed: true,
          current: true,
        },
        {
          title: paymentMethod === 'Credit Card' ? 'Awaiting Paymob Card Settlement' : 'Hardware Authenticity & Seal Check',
          timestamp: 'In Progress',
          location: 'Paymob Egypt / Zagazig Dispatch',
          completed: false,
        },
        {
          title: 'Out for Express Courier Dispatch',
          timestamp: 'Estimated Today / Tomorrow',
          location: `${city} Courier Express`,
          completed: false,
        },
        {
          title: 'Delivered',
          timestamp: 'Pending',
          location: safeAddress,
          completed: false,
        },
      ],
    };

    if (paymentMethod === 'Credit Card') {
      try {
        const response = await fetch('/api/paymob/create-payment', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderId,
            totalUSD,
            customerInfo: newOrder.customerInfo,
            items: cartItems,
          }),
        });

        const data = await response.json();
        setIsSubmitting(false);

        if (data.iframeUrl) {
          setPaymobIframeUrl(data.iframeUrl);
          // Store order as pending, will confirm on iframe close/callback
          onOrderCompleted(newOrder);
        } else {
          onOrderCompleted(newOrder);
        }
      } catch (err) {
        console.warn('Paymob initialization fallback:', err);
        setIsSubmitting(false);
        onOrderCompleted(newOrder);
      }
    } else {
      setTimeout(() => {
        setIsSubmitting(false);
        onOrderCompleted(newOrder);
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto text-white shadow-2xl relative p-6 sm:p-8 my-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-zinc-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                Checkout & Secure Order
              </h2>
              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                <Lock className="w-3 h-3" /> SSL 256-Bit Encrypted
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-1">
              Provide delivery details for 100% genuine ElSory Store (السوري ستور) express shipping in Zagazig & Egypt.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmitOrder} className="space-y-6 my-6">
          
          {/* Customer Info */}
          <div className="space-y-4">
            <h3 className="text-xs font-extrabold uppercase tracking-widest text-zinc-400">
              1. Delivery Information
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ahmed El-Sayed"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-zinc-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Phone Number / WhatsApp *</label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. +20 10 1234 5678"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-zinc-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">City / Governorate</label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-zinc-500"
                >
                  <option value="Zagazig (الزقازيق - مصر)">Zagazig (الزقازيق - الشرقية)</option>
                  <option value="Cairo (القاهرة)">Cairo (القاهرة)</option>
                  <option value="Alexandria (الإسكندرية)">Alexandria (الإسكندرية)</option>
                  <option value="Giza (الجيزة)">Giza (الجيزة)</option>
                  <option value="Mansoura (المنصورة)">Mansoura (المنصورة)</option>
                  <option value="Tanta (طنطا)">Tanta (طنطا)</option>
                  <option value="Damascus (دمشق)">Damascus Regional (دمشق)</option>
                </select>
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="text-xs font-bold text-zinc-300">Detailed Address *</label>
                <input
                  type="text"
                  required
                  placeholder="District (e.g. Villas El Gamea / Al Qawmia), Street, Building"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-zinc-500"
                />
              </div>
            </div>
          </div>

          {/* Shipping Options */}
          <div className="space-y-3 pt-2">
            <h3 className="text-xs font-extrabold uppercase tracking-widest text-zinc-400">
              2. Delivery Method
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { id: 'Zagazig Express', title: 'Zagazig Doorstep Express', desc: 'Same-day local delivery' },
                { id: 'Egypt Nationwide', title: 'Egypt Express Courier', desc: '24-48 hrs across Egypt' },
                { id: 'Store Pickup', title: 'Zagazig Store Pickup', desc: 'Villas El Gamea HQ' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setShippingMethod(opt.id as any)}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                    shippingMethod === opt.id
                      ? 'bg-white text-black border-white font-bold'
                      : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  <div className="text-xs font-extrabold">{opt.title}</div>
                  <div className="text-[10px] opacity-75 mt-0.5">{opt.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-3 pt-2">
            <h3 className="text-xs font-extrabold uppercase tracking-widest text-zinc-400">
              3. Payment Method
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { id: 'Cash on Delivery', title: 'Cash on Delivery', desc: 'Pay on arrival' },
                { id: 'InstaPay / Vodafone Cash', title: 'InstaPay / VF Cash', desc: 'Direct wallet transfer' },
                { id: 'Credit Card', title: 'Visa / Mastercard', desc: 'Online card payment' },
                { id: 'Crypto (USDT)', title: 'USDT Crypto', desc: 'Tether TRC20' },
              ].map((pm) => (
                <button
                  key={pm.id}
                  type="button"
                  onClick={() => setPaymentMethod(pm.id as any)}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                    paymentMethod === pm.id
                      ? 'bg-white text-black border-white font-bold'
                      : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  <div className="text-xs font-extrabold">{pm.title}</div>
                  <div className="text-[10px] opacity-75 mt-0.5">{pm.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Order Summary Box */}
          <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-2 text-xs">
            <div className="flex justify-between text-zinc-400">
              <span>Items Total ({cartItems.length})</span>
              <span>{formatPrice(subtotalUSD, currentCurrency)}</span>
            </div>
            {discountUSD > 0 && (
              <div className="flex justify-between text-emerald-400 font-semibold">
                <span>Voucher Discount</span>
                <span>-{formatPrice(discountUSD, currentCurrency)}</span>
              </div>
            )}
            <div className="flex justify-between text-zinc-400">
              <span>Delivery Charge</span>
              <span>{shippingUSD === 0 ? 'FREE' : formatPrice(shippingUSD, currentCurrency)}</span>
            </div>
            <div className="flex justify-between text-sm font-extrabold text-white pt-2 border-t border-zinc-800">
              <span>Final Amount to Pay</span>
              <span className="text-lg">{formatPrice(totalUSD, currentCurrency)}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-zinc-400 bg-zinc-900/50 p-3 rounded-xl border border-zinc-800/80">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>100% Guaranteed Original Product, Factory Sealed with Official 1-Year ElSory Store Warranty.</span>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 bg-white text-black hover:bg-zinc-200 font-extrabold rounded-xl text-sm transition-all cursor-pointer shadow-xl flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" /> Verifying Security & Placing Order...
              </>
            ) : (
              <>
                <span>Place Order ({formatPrice(totalUSD, currentCurrency)})</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Paymob Hosted Card Checkout Modal Overlay */}
        {paymobIframeUrl && (
          <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-4 sm:p-6 animate-fadeIn">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col h-[85vh]">
              <div className="p-4 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-emerald-400" />
                  <div>
                    <h3 className="text-sm font-extrabold text-white">Paymob Secure Card Gateway (Egypt)</h3>
                    <p className="text-[10px] text-zinc-400">PCI-DSS Level 1 Compliant 256-Bit Encrypted Payment</p>
                  </div>
                </div>
                <button
                  onClick={() => setPaymobIframeUrl(null)}
                  className="p-1.5 text-zinc-400 hover:text-white bg-zinc-800 rounded-full text-xs"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <iframe
                src={paymobIframeUrl}
                title="Paymob Payment Gateway"
                className="w-full flex-1 border-0 bg-white"
              />

              <div className="p-3 bg-zinc-950 border-t border-zinc-800 text-center text-xs text-zinc-400">
                <span>Payment processed securely via Paymob Egypt. Order status updates automatically upon completion.</span>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
