import React, { useState } from 'react';
import { X, Plus, Scale, Check, ShoppingBag, Trash2 } from 'lucide-react';
import { Product, Currency } from '../types';
import { PRODUCTS } from '../data/products';
import { formatPrice } from '../data/currencies';
import { ProgressiveImage } from './ProgressiveImage';

interface DeviceComparerProps {
  comparedProducts: Product[];
  currentCurrency: Currency;
  onClose: () => void;
  onRemoveFromCompare: (productId: string) => void;
  onAddProductToCompare: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const DeviceComparer: React.FC<DeviceComparerProps> = ({
  comparedProducts,
  currentCurrency,
  onClose,
  onRemoveFromCompare,
  onAddProductToCompare,
  onAddToCart,
}) => {
  const [highlightDifferences, setHighlightDifferences] = useState(false);
  const [pickerOpenIndex, setPickerOpenIndex] = useState<number | null>(null);

  // Fill up to 3 slots
  const slots: (Product | null)[] = [
    comparedProducts[0] || null,
    comparedProducts[1] || null,
    comparedProducts[2] || null,
  ];

  const specRows = [
    { key: 'priceUSD', label: 'Price', format: (p: Product) => formatPrice(p.priceUSD, currentCurrency) },
    { key: 'display', label: 'Display & Refresh Rate', format: (p: Product) => p.specsDetail.display },
    { key: 'chipset', label: 'Chipset / Processor', format: (p: Product) => p.specsDetail.chipset },
    { key: 'mainCamera', label: 'Main Rear Cameras', format: (p: Product) => p.specsDetail.mainCamera },
    { key: 'selfieCamera', label: 'Selfie Front Camera', format: (p: Product) => p.specsDetail.selfieCamera },
    { key: 'battery', label: 'Battery Capacity', format: (p: Product) => p.specsDetail.battery },
    { key: 'charging', label: 'Charging Power', format: (p: Product) => p.specsDetail.charging },
    { key: 'weight', label: 'Weight', format: (p: Product) => p.specsDetail.weight },
    { key: 'os', label: 'Operating System', format: (p: Product) => p.specsDetail.os },
    { key: 'waterResistance', label: 'Water & Dust Resistance', format: (p: Product) => p.specsDetail.waterResistance },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-6xl w-full max-h-[92vh] overflow-y-auto text-white shadow-2xl relative p-6 sm:p-8 my-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-xl">
              <Scale className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                Flagship Device Comparison
              </h2>
              <p className="text-xs text-zinc-400">
                Compare side-by-side specs, performance, cameras, and pricing.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <label className="hidden sm:flex items-center gap-2 text-xs font-semibold text-zinc-400 cursor-pointer">
              <input
                type="checkbox"
                checked={highlightDifferences}
                onChange={(e) => setHighlightDifferences(e.target.checked)}
                className="rounded border-zinc-700 bg-zinc-900 text-white focus:ring-0"
              />
              Highlight Differences
            </label>

            <button
              onClick={onClose}
              className="p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Device Cards Header Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
          {slots.map((prod, slotIdx) => (
            <div key={slotIdx} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 relative flex flex-col justify-between min-h-[200px]">
              {prod ? (
                <>
                  <button
                    onClick={() => onRemoveFromCompare(prod.id)}
                    className="absolute top-3 right-3 p-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
                    title="Remove from comparison"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <div className="flex items-center gap-4">
                    <ProgressiveImage
                      src={prod.image}
                      alt={prod.name}
                      className="w-16 h-20 object-contain shrink-0 drop-shadow"
                    />
                    <div>
                      <span className="text-[10px] font-extrabold uppercase tracking-widest text-zinc-500">{prod.brand}</span>
                      <h3 className="text-sm font-bold text-white line-clamp-2">{prod.name}</h3>
                      <div className="text-base font-extrabold text-white mt-1">
                        {formatPrice(prod.priceUSD, currentCurrency)}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onAddToCart(prod)}
                    className="mt-4 w-full py-2 bg-white text-black hover:bg-zinc-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" /> Add to Bag
                  </button>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full my-auto text-center space-y-3 py-6">
                  <div className="w-12 h-12 rounded-full border-2 border-dashed border-zinc-700 flex items-center justify-center text-zinc-500">
                    <Plus className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-zinc-300">Slot {slotIdx + 1} Empty</div>
                    <div className="text-[11px] text-zinc-500">Select a device to compare</div>
                  </div>

                  <button
                    onClick={() => setPickerOpenIndex(pickerOpenIndex === slotIdx ? null : slotIdx)}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-xl text-xs font-bold text-white transition-colors cursor-pointer"
                  >
                    + Select Device
                  </button>

                  {/* Device Picker Dropdown */}
                  {pickerOpenIndex === slotIdx && (
                    <div className="absolute top-full left-0 right-0 mt-2 bg-zinc-950 border border-zinc-700 rounded-xl shadow-2xl z-50 p-2 max-h-60 overflow-y-auto space-y-1">
                      {PRODUCTS.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => {
                            onAddProductToCompare(p);
                            setPickerOpenIndex(null);
                          }}
                          className="w-full text-left p-2 hover:bg-zinc-800 rounded-lg flex items-center gap-3 transition-colors text-xs"
                        >
                          <img src={p.image} alt={p.name} className="w-8 h-8 object-contain" />
                          <div className="truncate">
                            <div className="font-bold text-white truncate">{p.name}</div>
                            <div className="text-[10px] text-zinc-400">{formatPrice(p.priceUSD, currentCurrency)}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Detailed Specs Table */}
        <div className="space-y-4 pt-4 border-t border-zinc-800">
          <h3 className="text-xs font-extrabold uppercase tracking-widest text-zinc-400">
            Hardware & Features Breakdown
          </h3>

          <div className="space-y-2">
            {specRows.map((row) => {
              // Check if values differ across selected slots
              const activeVals = slots.filter(Boolean).map((s) => row.format(s!));
              const isDiff = activeVals.length > 1 && new Set(activeVals).size > 1;

              return (
                <div
                  key={row.key}
                  className={`rounded-xl p-3 border transition-colors ${
                    highlightDifferences && isDiff
                      ? 'bg-amber-950/20 border-amber-800/60'
                      : 'bg-zinc-900/60 border-zinc-800/80'
                  }`}
                >
                  <div className="text-[10px] font-extrabold uppercase tracking-widest text-zinc-500 mb-2">
                    {row.label}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    {slots.map((prod, idx) => (
                      <div key={idx} className="text-zinc-200 font-medium">
                        {prod ? row.format(prod) : <span className="text-zinc-600">-</span>}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};
