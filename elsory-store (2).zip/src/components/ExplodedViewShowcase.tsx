import React from 'react';
import { Product, Currency, Language } from '../types';
import { Product3DAssembler } from './Product3DAssembler';

interface ExplodedViewShowcaseProps {
  product: Product;
  currentCurrency: Currency;
  lang: Language;
  onSelectProduct: (p: Product) => void;
}

export const ExplodedViewShowcase: React.FC<ExplodedViewShowcaseProps> = ({
  product,
  currentCurrency,
  lang,
  onSelectProduct,
}) => {
  return (
    <section className="py-12 sm:py-20 bg-black text-white relative overflow-hidden border-b border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <Product3DAssembler
          product={product}
          currentCurrency={currentCurrency}
          onSelectProduct={onSelectProduct}
          autoAssembleOnScroll={true}
          interactiveToggle={true}
          showDetailsOverlay={true}
        />
      </div>
    </section>
  );
};
