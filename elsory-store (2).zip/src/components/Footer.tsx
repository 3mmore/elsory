import React from 'react';
import { ShieldCheck, Truck, PhoneCall, MapPin, Globe, Sparkles, RefreshCw, BarChart2 } from 'lucide-react';
import { Currency } from '../types';
import { CURRENCIES } from '../data/currencies';

interface FooterProps {
  currentCurrency: Currency;
  onCurrencyChange: (c: Currency) => void;
  onOpenAI: () => void;
  onOpenTradeIn: () => void;
  onOpenLocations: () => void;
  onOpenTracking: () => void;
  onOpenRepair?: () => void;
  onSelectCategory: (cat: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  currentCurrency,
  onCurrencyChange,
  onOpenAI,
  onOpenTradeIn,
  onOpenLocations,
  onOpenTracking,
  onOpenRepair,
  onSelectCategory,
}) => {
  return (
    <footer className="bg-black text-white border-t border-zinc-800 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-12">
        
        {/* Top Badges Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-6 bg-zinc-900 border border-zinc-800 rounded-2xl text-xs">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-white shrink-0" />
            <div>
              <div className="font-extrabold text-white uppercase tracking-wider">100% Authentic</div>
              <div className="text-zinc-400">1-Year Official Warranty</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Truck className="w-6 h-6 text-white shrink-0" />
            <div>
              <div className="font-extrabold text-white uppercase tracking-wider">Zagazig & Egypt Delivery</div>
              <div className="text-zinc-400">Same-Day Express Courier</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <RefreshCw className="w-6 h-6 text-white shrink-0" />
            <div>
              <div className="font-extrabold text-white uppercase tracking-wider">Mobile Repair Center</div>
              <div className="text-zinc-400">Screen, Battery & Board Soldering</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-white shrink-0" />
            <div>
              <div className="font-extrabold text-white uppercase tracking-wider">AI Store Assistant</div>
              <div className="text-zinc-400">24/7 Phone & Repair Advice</div>
            </div>
          </div>
        </div>

        {/* Main Footer Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 text-sm">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white text-black font-black text-xl flex items-center justify-center rounded-sm">
                S
              </div>
              <span className="font-extrabold tracking-[0.22em] text-lg uppercase text-white font-sans">
                ELSORY STORE <span className="text-xs text-zinc-400 font-arabic font-normal tracking-normal">(السوري ستور)</span>
              </span>
            </div>

            <p className="text-zinc-400 text-xs leading-relaxed max-w-sm">
              Premier smartphone retailer and professional mobile repair center in Zagazig, Sharqia Governorate, Egypt. Featuring official iPhones, Samsung Ultra series, Nothing, custom 24K gold phones, and instant certified repairs.
            </p>

            <div className="pt-2 flex items-center gap-3 text-xs text-zinc-400">
              <Globe className="w-4 h-4 text-zinc-300" />
              <span>Currency:</span>
              <div className="flex flex-wrap gap-1.5">
                {(Object.keys(CURRENCIES) as Currency[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => onCurrencyChange(c)}
                    className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      currentCurrency === c ? 'bg-white text-black' : 'bg-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Categories Col */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-widest text-zinc-400">
              Categories
            </h4>
            <ul className="space-y-2 text-xs text-zinc-400">
              {['Smartphones', 'Tablets', 'Smartwatches', 'Audio & Sound', 'Accessories', 'Luxury Editions', 'Repair Services'].map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => onSelectCategory(cat)}
                    className="hover:text-white transition-colors cursor-pointer"
                  >
                    {cat}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Services */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-widest text-zinc-400">
              Services & Tools
            </h4>
            <ul className="space-y-2 text-xs text-zinc-400">
              {onOpenRepair && (
                <li>
                  <button onClick={onOpenRepair} className="text-emerald-400 font-bold hover:text-emerald-300 transition-colors cursor-pointer flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Book Mobile Repair
                  </button>
                </li>
              )}
              <li>
                <button onClick={onOpenAI} className="hover:text-white transition-colors cursor-pointer flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-zinc-300" /> AI Device Specialist
                </button>
              </li>
              <li>
                <button onClick={onOpenTradeIn} className="hover:text-white transition-colors cursor-pointer">
                  Trade-In & Upgrade
                </button>
              </li>
              <li>
                <button onClick={onOpenTracking} className="hover:text-white transition-colors cursor-pointer">
                  Track Order Status
                </button>
              </li>
              <li>
                <button onClick={onOpenLocations} className="hover:text-white transition-colors cursor-pointer">
                  Zagazig & Egypt Showrooms
                </button>
              </li>
            </ul>
          </div>

          {/* Showroom Contact */}
          <div className="space-y-3 text-xs">
            <h4 className="text-xs font-extrabold uppercase tracking-widest text-zinc-400">
              Main Flagship & Service
            </h4>
            <div className="text-zinc-400 space-y-1">
              <div className="text-white font-bold">Zagazig Headquarters</div>
              <div>Villas El Gamea District, Al Qawmia</div>
              <div>Zagazig, Sharqia, Egypt</div>
              <div className="pt-1 text-white font-mono">Mobile: +20 10 1234 5678</div>
              <div className="text-zinc-400">Daily: 10:00 AM - 11:00 PM</div>
            </div>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-8 border-t border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <div>
            &copy; {new Date().getFullYear()} ELSORY STORE (السوري ستور). All rights reserved.
          </div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-zinc-300">Privacy Policy</a>
            <a href="#" className="hover:text-zinc-300">Terms of Warranty</a>
            <a href="#" className="hover:text-zinc-300">Authenticity Guarantee</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
