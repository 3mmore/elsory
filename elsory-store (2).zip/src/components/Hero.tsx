import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';
import { ArrowRight, Sparkles, ShieldCheck, Zap, Award, Smartphone, Wrench, CheckCircle } from 'lucide-react';
import { Currency } from '../types';
import { formatPrice } from '../data/currencies';
import { ProgressiveImage } from './ProgressiveImage';

interface HeroProps {
  currentCurrency: Currency;
  onExploreClick: () => void;
  onOpenAI: () => void;
  onSelectFeaturedProduct: (productId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({
  currentCurrency,
  onExploreClick,
  onOpenAI,
  onSelectFeaturedProduct,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });

  const smoothScroll = useSpring(scrollYProgress, { stiffness: 100, damping: 20 });

  // 3D Parallax & Rotation transforms on scroll
  const yImage1 = useTransform(smoothScroll, [0, 1], [0, -40]);
  const yImage2 = useTransform(smoothScroll, [0, 1], [0, 50]);
  const rotateXCard = useTransform(smoothScroll, [0, 1], [0, 8]);
  const rotateYCard = useTransform(smoothScroll, [0, 1], [0, -12]);
  const floatBadgeY = useTransform(smoothScroll, [0, 1], [0, -70]);

  return (
    <section ref={containerRef} className="relative bg-black text-white overflow-hidden border-b border-zinc-800">
      {/* Background Gradient Mesh & Lines */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.18),rgba(255,255,255,0))]" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f1f23_1px,transparent_1px),linear-gradient(to_bottom,#1f1f23_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-30" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-16 pb-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Text & CTA */}
          <motion.div 
            className="lg:col-span-7 space-y-8"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1.0] }}
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-zinc-700 bg-zinc-900/80 backdrop-blur-md text-xs font-medium text-zinc-300 shadow-xl">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="tracking-wider uppercase font-semibold text-[11px] text-white">
                Egypt • Zagazig • Villas El Gamea District
              </span>
            </div>

            <div className="space-y-4">
              <h1 className="text-4xl sm:text-6xl xl:text-7xl font-extrabold tracking-tight text-white font-sans leading-[1.05]">
                PRECISION.<br />
                LUXURY.<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-300 to-zinc-500">
                  ELSORY STORE.
                </span>
              </h1>
              <p className="text-zinc-400 text-base sm:text-lg max-w-xl font-normal leading-relaxed">
                Discover flagship smartphones, custom luxury 24K editions, and <strong className="text-white">Professional Mobile Repair Center Services</strong> at <strong className="text-white">ELSORY STORE (السوري ستور)</strong> in Zagazig, Sharqia. Certified technicians, express screen & battery replacements, and 100% original parts guaranteed.
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onExploreClick}
                className="bg-white text-black hover:bg-zinc-200 px-7 py-3.5 rounded-xl font-bold text-sm tracking-wide transition-all cursor-pointer shadow-lg hover:shadow-white/10 flex items-center gap-2 group"
              >
                <span>Explore Catalog</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onOpenAI}
                className="bg-zinc-900 border border-zinc-700 hover:border-zinc-500 text-white px-6 py-3.5 rounded-xl font-medium text-sm transition-all cursor-pointer flex items-center gap-2.5 shadow-md hover:bg-zinc-800"
              >
                <Sparkles className="w-4 h-4 text-zinc-300" />
                <span>Consult AI Assistant</span>
              </button>
            </div>

            {/* Trust Highlights */}
            <div className="pt-8 grid grid-cols-3 gap-4 border-t border-zinc-800/80 text-zinc-400 text-xs">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-white shrink-0" />
                <div>
                  <div className="text-white font-bold">100% Genuine</div>
                  <div>Official Warranty</div>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Zap className="w-5 h-5 text-white shrink-0" />
                <div>
                  <div className="text-white font-bold">Express Delivery</div>
                  <div>Zagazig & Egypt</div>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Wrench className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <div className="text-white font-bold">Repair Center</div>
                  <div>Zagazig HQ Branch</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Featured 3D Depth & Parallax Showcase Cards */}
          <motion.div 
            className="lg:col-span-5 relative [perspective:1200px]"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2, ease: [0.25, 0.1, 0.25, 1.0] }}
          >
            {/* Floating Live Badge Overlay */}
            <motion.div 
              style={{ y: floatBadgeY }}
              className="absolute -top-6 -left-4 z-20 bg-zinc-900/90 border border-zinc-700/80 backdrop-blur-xl p-3 rounded-2xl shadow-2xl flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">Certified Technicians</div>
                <div className="text-[10px] text-zinc-400">Zagazig Al Qawmia Branch</div>
              </div>
            </motion.div>

            <motion.div 
              style={{ rotateX: rotateXCard, rotateY: rotateYCard, transformStyle: 'preserve-3d' }}
              className="relative mx-auto max-w-md lg:max-w-none space-y-4"
            >
              
              {/* Highlight Card 1 - iPhone 17 Pro Max */}
              <motion.div 
                style={{ y: yImage1 }}
                whileHover={{ scale: 1.03, rotateZ: -1 }}
                onClick={() => onSelectFeaturedProduct('syr-iphone17promax')}
                className="group relative bg-zinc-900/90 backdrop-blur-md border border-zinc-800 hover:border-zinc-500 rounded-2xl p-6 transition-all duration-300 cursor-pointer shadow-2xl hover:shadow-white/10"
              >
                <div className="absolute top-4 right-4 bg-white text-black text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider shadow">
                  Flagship Hero
                </div>

                <div className="flex items-center gap-6">
                  <div className="w-32 h-32 rounded-xl bg-zinc-950 overflow-hidden shrink-0 flex items-center justify-center p-2 border border-zinc-800 group-hover:scale-110 transition-transform duration-500">
                    <ProgressiveImage 
                      src="https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=600&auto=format&fit=crop" 
                      alt="iPhone 17 Pro Max"
                      className="w-full h-full object-contain" 
                    />
                  </div>

                  <div className="space-y-1">
                    <span className="text-xs uppercase tracking-widest text-zinc-500 font-bold">Apple</span>
                    <h3 className="text-xl font-bold text-white group-hover:text-zinc-200 transition-colors">
                      iPhone 17 Pro Max
                    </h3>
                    <p className="text-xs text-zinc-400 line-clamp-2">
                      Grade 5 Titanium, A19 Pro Neural Chip, Tandem OLED & 10x Periscope Zoom.
                    </p>
                    <div className="pt-2 flex items-center justify-between">
                      <span className="text-lg font-extrabold text-white">
                        {formatPrice(1299, currentCurrency)}
                      </span>
                      <span className="text-xs text-zinc-400 group-hover:text-white flex items-center gap-1 font-semibold">
                        View Details <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Highlight Card 2 - Galaxy S26 Ultra */}
              <motion.div 
                style={{ y: yImage2 }}
                whileHover={{ scale: 1.03, rotateZ: 1 }}
                onClick={() => onSelectFeaturedProduct('syr-s26ultra')}
                className="group relative bg-zinc-900/80 backdrop-blur-md border border-zinc-800 hover:border-zinc-500 rounded-2xl p-5 transition-all duration-300 cursor-pointer shadow-xl hover:shadow-white/10"
              >
                <div className="flex items-center gap-5">
                  <div className="w-24 h-24 rounded-xl bg-zinc-950 overflow-hidden shrink-0 flex items-center justify-center p-2 border border-zinc-800 group-hover:scale-110 transition-transform duration-500">
                    <ProgressiveImage 
                      src="https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=600&auto=format&fit=crop" 
                      alt="Galaxy S26 Ultra"
                      className="w-full h-full object-contain" 
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs uppercase tracking-widest text-zinc-500 font-bold">Samsung</span>
                      <span className="bg-zinc-800 text-zinc-300 text-[9px] px-1.5 py-0.2 rounded font-bold">Galaxy AI 3.0</span>
                    </div>
                    <h3 className="text-lg font-bold text-white">
                      Galaxy S26 Ultra
                    </h3>
                    <div className="flex items-center gap-3">
                      <span className="text-base font-extrabold text-white">
                        {formatPrice(1399, currentCurrency)}
                      </span>
                      <span className="text-xs text-zinc-400 group-hover:text-white font-semibold">
                        In Stock &bull; Zagazig Delivery
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>

            </motion.div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

