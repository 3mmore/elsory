import React from 'react';
import { motion } from 'motion/react';
import { Home, Search, ShoppingBag, Wrench, Sparkles } from 'lucide-react';

interface MobileBottomNavProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenRepair: () => void;
  onOpenAI: () => void;
  onFocusSearch: () => void;
  onGoHome: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  cartCount,
  onOpenCart,
  onOpenRepair,
  onOpenAI,
  onFocusSearch,
  onGoHome,
}) => {
  return (
    <motion.nav 
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-zinc-950/90 backdrop-blur-xl border-t border-zinc-800/80 px-4 py-2 safe-pb shadow-2xl"
    >
      <div className="flex items-center justify-around max-w-md mx-auto">
        
        {/* Catalog Home */}
        <button
          onClick={onGoHome}
          className="flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-colors cursor-pointer group"
        >
          <Home className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-[10px] font-medium tracking-tight">Catalog</span>
        </button>

        {/* Search */}
        <button
          onClick={onFocusSearch}
          className="flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-colors cursor-pointer group"
        >
          <Search className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-[10px] font-medium tracking-tight">Search</span>
        </button>

        {/* Mobile Repair Center */}
        <button
          onClick={onOpenRepair}
          className="flex flex-col items-center gap-1 text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer group relative"
        >
          <div className="p-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 group-hover:scale-110 transition-transform">
            <Wrench className="w-4 h-4 text-emerald-400" />
          </div>
          <span className="text-[10px] font-bold text-emerald-400 tracking-tight">Repair</span>
        </button>

        {/* AI Specialist */}
        <button
          onClick={onOpenAI}
          className="flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-colors cursor-pointer group"
        >
          <Sparkles className="w-5 h-5 group-hover:scale-110 transition-transform text-zinc-300" />
          <span className="text-[10px] font-medium tracking-tight">AI Guide</span>
        </button>

        {/* Cart */}
        <button
          onClick={onOpenCart}
          className="flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-colors cursor-pointer group relative"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-white text-black text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center border border-black shadow-md animate-pulse">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium tracking-tight">Cart</span>
        </button>

      </div>
    </motion.nav>
  );
};
