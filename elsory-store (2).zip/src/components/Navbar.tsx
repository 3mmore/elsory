import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Sparkles, 
  Scale, 
  MapPin, 
  Truck, 
  Heart, 
  Globe, 
  Menu, 
  X,
  PhoneCall,
  ShieldCheck,
  BarChart2,
  Languages,
  Sun,
  Moon,
  Camera
} from 'lucide-react';
import { Currency, Language, Category } from '../types';
import { CURRENCIES } from '../data/currencies';
import { translations, getCategoryTranslation } from '../lib/i18n';

interface NavbarProps {
  currentCurrency: Currency;
  onCurrencyChange: (c: Currency) => void;
  lang: Language;
  onLangToggle: () => void;
  theme: 'dark' | 'light';
  onThemeToggle: () => void;
  cartCount: number;
  wishlistCount: number;
  compareCount: number;
  onOpenCart: () => void;
  onOpenAI: () => void;
  onOpenAdminDashboard?: () => void;
  onOpenCompare: () => void;
  onOpenTradeIn: () => void;
  onOpenLocations: () => void;
  onOpenTracking: () => void;
  onOpenRepair?: () => void;
  onOpenVisualSearch?: () => void;
  onSearchChange: (query: string) => void;
  activeCategory: string;
  onSelectCategory: (cat: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentCurrency,
  onCurrencyChange,
  lang,
  onLangToggle,
  theme,
  onThemeToggle,
  cartCount,
  wishlistCount,
  compareCount,
  onOpenCart,
  onOpenAI,
  onOpenAdminDashboard,
  onOpenCompare,
  onOpenTradeIn,
  onOpenLocations,
  onOpenTracking,
  onOpenRepair,
  onOpenVisualSearch,
  onSearchChange,
  activeCategory,
  onSelectCategory,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  const t = translations[lang];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchChange(searchValue);
  };

  const navCategories: Category[] = [
    'All', 
    'Smartphones', 
    'Tablets', 
    'Smartwatches', 
    'Audio & Sound', 
    'Accessories', 
    'Luxury Editions', 
    'Repair Services'
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/90 dark:bg-black/90 backdrop-blur-md text-zinc-900 dark:text-white border-b border-zinc-200 dark:border-zinc-800 transition-colors duration-300">
      {/* Top Banner */}
      <div className="bg-zinc-100 dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 px-4 py-1.5 text-xs text-zinc-600 dark:text-zinc-300 transition-colors">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-4 text-zinc-500 dark:text-zinc-400">
            <span className="flex items-center gap-1.5 text-zinc-800 dark:text-zinc-200 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-zinc-900 dark:text-white" /> {t.topWarrantyNotice}
            </span>
            <span className="hidden md:inline-flex items-center gap-1.5 text-zinc-600 dark:text-zinc-400">
              <Truck className="w-3.5 h-3.5 text-zinc-700 dark:text-zinc-300" /> {t.topShippingNotice}
            </span>
          </div>

          <div className="flex items-center gap-3.5">
            {/* Language Switcher */}
            <button
              onClick={onLangToggle}
              className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-zinc-900 dark:text-white font-bold text-xs cursor-pointer border border-zinc-300 dark:border-zinc-700 transition-colors"
              title="Switch Language / تغيير اللغة"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{t.langSwitchName}</span>
            </button>

            {/* Theme Toggle Button */}
            <button
              onClick={onThemeToggle}
              className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-zinc-200/80 dark:bg-zinc-800/90 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-zinc-900 dark:text-white font-bold text-xs cursor-pointer border border-zinc-300 dark:border-zinc-700 transition-all"
              title={theme === 'dark' ? t.lightMode : t.darkMode}
              aria-label={theme === 'dark' ? t.lightMode : t.darkMode}
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400 animate-spin-slow" />
                  <span className="hidden sm:inline">{t.lightMode}</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-indigo-600" />
                  <span className="hidden sm:inline">{t.darkMode}</span>
                </>
              )}
            </button>

            <span className="text-zinc-300 dark:text-zinc-700">|</span>

            {onOpenRepair && (
              <button 
                onClick={onOpenRepair}
                className="hover:text-zinc-900 dark:hover:text-white transition-colors cursor-pointer flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold"
              >
                <span>{t.repairCenter}</span>
                <span className="bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/30 dark:border-emerald-500/40 text-emerald-700 dark:text-emerald-300 text-[10px] px-1.5 py-0.2 rounded font-bold uppercase tracking-wider">Express</span>
              </button>
            )}
            <span className="text-zinc-300 dark:text-zinc-700">|</span>
            <button 
              onClick={onOpenTradeIn}
              className="hover:text-zinc-900 dark:hover:text-white transition-colors cursor-pointer flex items-center gap-1"
            >
              <span>{t.tradeIn}</span>
              <span className="bg-zinc-900 dark:bg-white text-white dark:text-black text-[10px] px-1.5 py-0.2 rounded font-bold uppercase tracking-wider">Bonus</span>
            </button>
            <span className="text-zinc-300 dark:text-zinc-700">|</span>
            <button 
              onClick={onOpenTracking}
              className="hover:text-zinc-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              {t.trackOrder}
            </button>
            <span className="text-zinc-300 dark:text-zinc-700">|</span>

            {/* Currency Picker */}
            <div className="relative">
              <button 
                onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
                className="flex items-center gap-1 font-semibold text-zinc-800 dark:text-white hover:text-zinc-600 dark:hover:text-zinc-300 cursor-pointer text-xs"
              >
                <Globe className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />
                <span>{currentCurrency} ({CURRENCIES[currentCurrency].symbol})</span>
              </button>

              {currencyDropdownOpen && (
                <div className="absolute right-0 mt-2 w-36 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg shadow-xl z-50 py-1 text-xs">
                  {(Object.keys(CURRENCIES) as Currency[]).map((curr) => (
                    <button
                      key={curr}
                      onClick={() => {
                        onCurrencyChange(curr);
                        setCurrencyDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 flex items-center justify-between hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors ${
                        currentCurrency === curr ? 'font-bold text-zinc-900 dark:text-white bg-zinc-100 dark:bg-zinc-800/80' : 'text-zinc-600 dark:text-zinc-400'
                      }`}
                    >
                      <span>{curr}</span>
                      <span className="text-zinc-400 dark:text-zinc-500 font-mono">{CURRENCIES[curr].symbol}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-8">
          <a 
            href="#" 
            onClick={(e) => { e.preventDefault(); onSelectCategory('All'); }}
            className="flex items-center gap-3 group"
          >
            {/* Minimalist Logo Icon */}
            <div className="w-9 h-9 bg-zinc-900 dark:bg-white text-white dark:text-black font-black text-xl flex items-center justify-center rounded-sm tracking-tighter group-hover:scale-105 transition-transform shadow-md">
              S
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold tracking-[0.22em] text-lg leading-none uppercase text-zinc-900 dark:text-white font-sans flex items-center gap-1.5">
                {t.storeName} <span className="text-xs text-zinc-500 dark:text-zinc-400 font-arabic font-normal tracking-normal">{t.storeNameArabic}</span>
              </span>
              <span className="text-[9px] tracking-[0.25em] text-zinc-500 dark:text-zinc-400 uppercase font-medium mt-0.5">
                {t.tagline}
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-zinc-600 dark:text-zinc-300">
            {navCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`transition-colors hover:text-zinc-900 dark:hover:text-white cursor-pointer py-1 border-b-2 ${
                  activeCategory === cat ? 'border-zinc-900 dark:border-white text-zinc-900 dark:text-white font-semibold' : 'border-transparent text-zinc-600 dark:text-zinc-400'
                }`}
              >
                {getCategoryTranslation(cat, lang)}
              </button>
            ))}
          </nav>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Admin AI Dashboard Trigger */}
          <button
            onClick={onOpenAdminDashboard}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-zinc-700 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white transition-all cursor-pointer rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 hover:border-emerald-500/50 text-xs font-bold shadow-xs"
            title="AI Marketing Advisor & Business Intelligence Dashboard"
          >
            <BarChart2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span className="hidden sm:inline-block">AI Marketing Suite</span>
          </button>

          {/* AI Assistant Button */}
          <button
            onClick={onOpenAI}
            className="flex items-center gap-2 bg-gradient-to-r from-zinc-100 to-zinc-200 dark:from-zinc-800 dark:to-zinc-900 border border-zinc-300 dark:border-zinc-700 hover:border-zinc-400 dark:hover:border-zinc-500 text-zinc-900 dark:text-white px-3 py-1.5 rounded-full text-xs font-medium transition-all shadow-xs group cursor-pointer"
            title="Ask ElSory Store AI Assistant"
          >
            <Sparkles className="w-3.5 h-3.5 text-zinc-600 dark:text-zinc-300 group-hover:rotate-12 transition-transform" />
            <span className="hidden sm:inline">{t.aiAssistant}</span>
          </button>

          {/* Compare Drawer Trigger */}
          <button
            onClick={onOpenCompare}
            className="relative p-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors cursor-pointer rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
            title={t.compare}
          >
            <Scale className="w-5 h-5" />
            {compareCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-zinc-900 dark:bg-white text-white dark:text-black text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {compareCount}
              </span>
            )}
          </button>

          {/* Store Locations Trigger */}
          <button
            onClick={onOpenLocations}
            className="p-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors cursor-pointer rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800/60 hidden sm:flex"
            title="Zagazig & Egypt Store Locations"
          >
            <MapPin className="w-5 h-5" />
          </button>

          {/* AI Visual Search Button */}
          {onOpenVisualSearch && (
            <button
              onClick={onOpenVisualSearch}
              className="p-2 text-purple-600 dark:text-purple-400 hover:text-purple-900 dark:hover:text-purple-200 transition-colors cursor-pointer rounded-lg hover:bg-purple-50 dark:hover:bg-purple-950/40 relative group"
              title="AI Visual Product Search (Snap or Upload Phone Image)"
            >
              <Camera className="w-5 h-5" />
              <span className="absolute -bottom-1 -right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-purple-500"></span>
              </span>
            </button>
          )}

          {/* Search Button */}
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="p-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors cursor-pointer rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
            title="Search Products"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Cart Trigger */}
          <button
            onClick={onOpenCart}
            className="relative p-2 bg-zinc-900 dark:bg-white text-white dark:text-black hover:bg-zinc-800 dark:hover:bg-zinc-200 transition-all cursor-pointer rounded-lg font-medium flex items-center gap-2 px-3.5 py-1.5 shadow-md ml-1"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="text-xs font-bold hidden sm:inline">{t.bag}</span>
            {cartCount > 0 && (
              <span className="bg-white dark:bg-black text-black dark:text-white text-[11px] font-extrabold px-1.5 py-0.2 rounded-full min-w-[18px] text-center">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white lg:hidden cursor-pointer ml-1"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Expanded Search Bar */}
      {searchOpen && (
        <div className="bg-zinc-50 dark:bg-zinc-950 border-b border-zinc-200 dark:border-zinc-800 px-4 py-3 animate-fadeIn">
          <form onSubmit={handleSearchSubmit} className="max-w-3xl mx-auto flex items-center gap-3">
            <Search className="w-5 h-5 text-zinc-400" />
            <input
              type="text"
              placeholder={t.searchPlaceholder}
              value={searchValue}
              onChange={(e) => {
                setSearchValue(e.target.value);
                onSearchChange(e.target.value);
              }}
              className="w-full bg-transparent border-none text-zinc-900 dark:text-white text-sm focus:outline-none placeholder-zinc-500"
              autoFocus
            />
            {searchValue && (
              <button
                type="button"
                onClick={() => {
                  setSearchValue('');
                  onSearchChange('');
                }}
                className="text-zinc-500 hover:text-zinc-900 dark:hover:text-white text-xs font-semibold"
              >
                Clear
              </button>
            )}
          </form>
        </div>
      )}

      {/* Mobile Category Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-zinc-950 border-b border-zinc-200 dark:border-zinc-800 px-4 py-4 flex flex-col gap-3">
          <div className="text-xs uppercase tracking-widest text-zinc-400 dark:text-zinc-500 font-bold mb-1">{t.categoriesTitle}</div>
          {navCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                onSelectCategory(cat);
                setMobileMenuOpen(false);
              }}
              className={`text-left text-sm py-1.5 transition-colors ${
                activeCategory === cat ? 'text-zinc-900 dark:text-white font-bold border-l-2 border-zinc-900 dark:border-white pl-2' : 'text-zinc-600 dark:text-zinc-400'
              }`}
            >
              {getCategoryTranslation(cat, lang)}
            </button>
          ))}
          <hr className="border-zinc-200 dark:border-zinc-800 my-2" />
          <div className="flex flex-col gap-2">
            {/* Mobile Theme Toggle Button */}
            <button
              onClick={() => {
                onThemeToggle();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 text-sm text-zinc-800 dark:text-zinc-200 py-1 font-semibold"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span>{t.lightMode}</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-indigo-600" />
                  <span>{t.darkMode}</span>
                </>
              )}
            </button>
            <button
              onClick={() => { onOpenAdminDashboard(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 text-sm text-amber-600 dark:text-amber-400 py-1 font-semibold"
            >
              <BarChart2 className="w-4 h-4" /> Admin AI Dashboard
            </button>
            {onOpenRepair && (
              <button
                onClick={() => { onOpenRepair(); setMobileMenuOpen(false); }}
                className="flex items-center gap-2 text-sm text-emerald-600 dark:text-emerald-400 py-1 font-semibold"
              >
                <ShieldCheck className="w-4 h-4" /> {t.repairCenter}
              </button>
            )}
            <button
              onClick={() => { onOpenLocations(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 text-sm text-zinc-700 dark:text-zinc-300 py-1"
            >
              <MapPin className="w-4 h-4" /> Zagazig - Villas El Gamea Store
            </button>
            <button
              onClick={() => { onOpenTradeIn(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 text-sm text-zinc-700 dark:text-zinc-300 py-1"
            >
              <Truck className="w-4 h-4" /> {t.tradeIn}
            </button>
            <button
              onClick={() => { onOpenTracking(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 text-sm text-zinc-700 dark:text-zinc-300 py-1"
            >
              <PhoneCall className="w-4 h-4" /> {t.trackOrder}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};


