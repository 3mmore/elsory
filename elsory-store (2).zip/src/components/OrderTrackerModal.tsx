import React, { useState } from 'react';
import { X, Search, CheckCircle2, Clock, Truck, MapPin, Package, PhoneCall } from 'lucide-react';
import { Order, Currency } from '../types';

interface OrderTrackerModalProps {
  recentOrder: Order | null;
  currentCurrency: Currency;
  onClose: () => void;
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({
  recentOrder,
  currentCurrency,
  onClose,
}) => {
  const [searchId, setSearchId] = useState(recentOrder?.orderId || '');
  const [activeOrder, setActiveOrder] = useState<Order | null>(recentOrder);
  const [searched, setSearched] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    if (recentOrder && searchId.trim().toUpperCase() === recentOrder.orderId.toUpperCase()) {
      setActiveOrder(recentOrder);
    } else if (searchId.trim()) {
      // Mock lookup order
      setActiveOrder({
        orderId: searchId.trim().toUpperCase(),
        date: 'July 25, 2026',
        items: [],
        subtotalUSD: 1199,
        discountUSD: 0,
        shippingUSD: 0,
        totalUSD: 1199,
        currency: currentCurrency,
        totalConvertedFormatted: '$1,199',
        status: 'In Transit',
        customerInfo: {
          fullName: 'Valued Customer',
          email: 'customer@elsory.eg',
          phone: '+20 10 1234 5678',
          city: 'Zagazig',
          address: 'Villas El Gamea District',
        },
        shippingMethod: 'Zagazig Express',
        paymentMethod: 'InstaPay / Vodafone Cash',
        trackingEvents: [
          {
            title: 'Order Verified & Authenticity Checked',
            timestamp: '09:30 AM',
            location: 'ElSory Store Zagazig Depot',
            completed: true,
          },
          {
            title: 'Sealed in Anti-Tamper ElSory Store Packaging',
            timestamp: '11:15 AM',
            location: 'Zagazig Flagship Headquarters',
            completed: true,
          },
          {
            title: 'Dispatched with Express Courier',
            timestamp: '01:40 PM',
            location: 'Sharqia Delivery Hub',
            completed: true,
            current: true,
          },
          {
            title: 'Out for Final Hand Delivery',
            timestamp: 'Estimated 04:30 PM Today',
            location: 'Customer Address',
            completed: false,
          },
        ],
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-2xl w-full text-white shadow-2xl relative p-6 sm:p-8 my-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white text-black rounded-xl">
              <Package className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-white">
                Live Order Tracker
              </h2>
              <p className="text-xs text-zinc-400">
                Monitor your device dispatch status across Zagazig & Egypt.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Order Search Form */}
        <form onSubmit={handleSearch} className="flex gap-2 my-6">
          <input
            type="text"
            placeholder="Enter Order ID e.g. SYR-884912"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-zinc-500 uppercase font-mono"
          />
          <button
            type="submit"
            className="px-5 py-3 bg-white text-black hover:bg-zinc-200 font-extrabold rounded-xl text-sm transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Search className="w-4 h-4" /> Track
          </button>
        </form>

        {/* Tracking Timeline Output */}
        {activeOrder ? (
          <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <div>
                <span className="text-xs text-zinc-500 uppercase font-semibold block">Order Reference</span>
                <span className="font-mono font-extrabold text-white text-lg">{activeOrder.orderId}</span>
              </div>

              <div className="text-right">
                <span className="bg-white text-black text-xs font-bold px-3 py-1 rounded-full uppercase">
                  {activeOrder.status}
                </span>
                <div className="text-[10px] text-zinc-400 mt-1">{activeOrder.date}</div>
              </div>
            </div>

            {/* Timeline Steps */}
            <div className="space-y-6 relative before:absolute before:inset-0 before:left-3.5 before:w-0.5 before:bg-zinc-800">
              {activeOrder.trackingEvents.map((evt, idx) => (
                <div key={idx} className="relative flex items-start gap-4">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 z-10 ${
                    evt.completed 
                      ? 'bg-white text-black' 
                      : evt.current 
                      ? 'bg-amber-400 text-black animate-pulse' 
                      : 'bg-zinc-800 text-zinc-500'
                  }`}>
                    {evt.completed ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                  </div>

                  <div className="space-y-0.5">
                    <h4 className="text-sm font-bold text-white">{evt.title}</h4>
                    <div className="text-xs text-zinc-400 flex items-center gap-3">
                      <span>{evt.timestamp}</span>
                      <span>&bull;</span>
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {evt.location}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
              <span>Customer: {activeOrder.customerInfo.fullName} ({activeOrder.customerInfo.city})</span>
              <a
                href={`https://wa.me/963900000000?text=Inquiry regarding order ${activeOrder.orderId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:underline flex items-center gap-1 font-semibold"
              >
                <PhoneCall className="w-3.5 h-3.5 text-emerald-400" /> WhatsApp Support
              </a>
            </div>
          </div>
        ) : searched ? (
          <div className="text-center py-10 text-zinc-500 text-sm">
            No order found with ID "{searchId}". Please check your order confirmation code.
          </div>
        ) : null}

      </div>
    </div>
  );
};
