import React, { useRef, useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Layers, Smartphone, Cpu, Camera, ShieldCheck, Battery, Sparkles, Eye } from 'lucide-react';
import { Product, Currency } from '../types';
import { formatPrice } from '../data/currencies';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

interface Product3DAssemblerProps {
  product: Product;
  currentCurrency?: Currency;
  onSelectProduct?: (product: Product) => void;
  autoAssembleOnScroll?: boolean;
  interactiveToggle?: boolean;
  showDetailsOverlay?: boolean;
  className?: string;
}

export const Product3DAssembler: React.FC<Product3DAssemblerProps> = ({
  product,
  currentCurrency = 'USD',
  onSelectProduct,
  autoAssembleOnScroll = true,
  interactiveToggle = true,
  showDetailsOverlay = true,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const layerRefs = useRef<(HTMLDivElement | null)[]>([]);

  const [manualState, setManualState] = useState<'exploded' | 'assembled' | 'auto'>('auto');
  const [activeHoverLayer, setActiveHoverLayer] = useState<number | null>(null);

  // Component layers for the iPhone 17 Pro Max assembly
  const layers = [
    {
      id: 'glass',
      name: 'Ceramic Shield OLED Display Panel',
      detail: product.specsDetail?.display || 'Tandem OLED • 120Hz ProMotion • 3000 nits',
      icon: Smartphone,
      accentColor: 'border-cyan-500/40 text-cyan-400 bg-cyan-500/10',
      explodedY: -110,
      explodedZ: 130,
      explodedRotateX: 25,
      explodedRotateY: -15,
      badge: '01. Display Panel',
    },
    {
      id: 'chipset',
      name: product.specsDetail?.chipset || 'A19 Pro 3nm Silicon Engine',
      detail: '16-Core Neural Engine • Ray Tracing GPU',
      icon: Cpu,
      accentColor: 'border-purple-500/40 text-purple-400 bg-purple-500/10',
      explodedY: -50,
      explodedZ: 75,
      explodedRotateX: 20,
      explodedRotateY: -10,
      badge: '02. Neural Logic Engine',
    },
    {
      id: 'camera',
      name: product.specsDetail?.mainCamera || '48MP Quad-Fusion Optical Array',
      detail: '10x Optical Periscope Zoom & Sensor-Shift OIS',
      icon: Camera,
      accentColor: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10',
      explodedY: 0,
      explodedZ: 20,
      explodedRotateX: 15,
      explodedRotateY: -5,
      badge: '03. Optics & Sensors',
    },
    {
      id: 'chassis',
      name: product.specsDetail?.waterResistance ? `IP68 Grade 5 Titanium Chassis` : 'Grade 5 Titanium Frame',
      detail: 'Micro-milled Thermal Vapor Chamber & Glass Rear',
      icon: ShieldCheck,
      accentColor: 'border-amber-500/40 text-amber-400 bg-amber-500/10',
      explodedY: 55,
      explodedZ: -50,
      explodedRotateX: 10,
      explodedRotateY: 0,
      badge: '04. Aerospace Frame',
    },
    {
      id: 'battery',
      name: product.specsDetail?.battery || '4,850 mAh Silicon-Carbon Cell',
      detail: 'MagSafe 2 Wireless Charging & Copper Induction Coil',
      icon: Battery,
      accentColor: 'border-rose-500/40 text-rose-400 bg-rose-500/10',
      explodedY: 110,
      explodedZ: -110,
      explodedRotateX: 5,
      explodedRotateY: 5,
      badge: '05. Power Unit',
    },
  ];

  // GSAP ScrollTrigger Integration
  useEffect(() => {
    if (!autoAssembleOnScroll || manualState !== 'auto' || !containerRef.current) return;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top bottom-=50',
          end: 'center center',
          scrub: 1,
        },
      });

      layerRefs.current.forEach((el, index) => {
        if (!el) return;
        const layerData = layers[index];
        tl.fromTo(
          el,
          {
            y: layerData.explodedY,
            rotateX: layerData.explodedRotateX,
            rotateY: layerData.explodedRotateY,
            opacity: 0.95,
            scale: 0.95,
          },
          {
            y: 0,
            rotateX: 0,
            rotateY: 0,
            opacity: 1,
            scale: 1,
            ease: 'power2.out',
            duration: 1,
          },
          0
        );
      });
    }, containerRef);

    return () => ctx.revert();
  }, [autoAssembleOnScroll, manualState]);

  const isExploded = manualState === 'exploded';

  return (
    <div
      ref={containerRef}
      className={`relative w-full rounded-3xl bg-zinc-950 border border-zinc-800/90 p-6 sm:p-10 overflow-hidden shadow-2xl select-none ${className}`}
    >
      {/* Ambient Lighting Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_70%_at_50%_30%,rgba(255,255,255,0.06),transparent)] pointer-events-none" />
      <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Control Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 relative z-20">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-[11px] text-zinc-300 mb-2 font-semibold tracking-wider uppercase">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Interactive 3D Hardware Deconstruction</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <span>{product.name}</span>
            <span className="text-xs font-mono font-normal text-zinc-500 bg-zinc-900 px-2.5 py-0.5 rounded-md border border-zinc-800">
              {product.brand}
            </span>
          </h3>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Separable vector hardware illustration (Display, A19 Chip, Triple Lens Optics, Titanium Body, Battery).
          </p>
        </div>

        {/* Interactive Controls */}
        {interactiveToggle && (
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                if (manualState === 'exploded') {
                  setManualState('assembled');
                } else if (manualState === 'assembled') {
                  setManualState('auto');
                } else {
                  setManualState('exploded');
                }
              }}
              className="px-4 py-2.5 bg-white text-black hover:bg-zinc-200 text-xs font-extrabold rounded-xl transition-all cursor-pointer shadow-lg flex items-center gap-2 active:scale-95"
            >
              <Layers className="w-4 h-4 text-black" />
              <span>
                {manualState === 'exploded'
                  ? 'Assemble Device'
                  : manualState === 'assembled'
                  ? 'Reset to Scroll 3D'
                  : 'Explode Hardware Layers'}
              </span>
            </button>

            {onSelectProduct && (
              <button
                onClick={() => onSelectProduct(product)}
                className="p-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
                title="View Full Product Details"
              >
                <Eye className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Main 3D Stage Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center min-h-[480px] relative z-10">
        
        {/* Left Column: 3D Stage with Vector Hardware Layers */}
        <div className="lg:col-span-7 flex items-center justify-center min-h-[400px] sm:min-h-[460px] relative [perspective:1200px]">
          
          <div className="relative w-full max-w-sm h-[420px] flex items-center justify-center [transform-style:preserve-3d]">

            {/* LAYER 1: CERAMIC SHIELD DISPLAY GLASS PANEL */}
            <motion.div
              ref={(el) => { layerRefs.current[0] = el; }}
              onMouseEnter={() => setActiveHoverLayer(0)}
              onMouseLeave={() => setActiveHoverLayer(null)}
              animate={isExploded ? {
                y: -120,
                z: 140,
                rotateX: 25,
                rotateY: -15,
                scale: 0.92,
              } : {
                y: 0,
                z: 40,
                rotateX: 0,
                rotateY: 0,
                scale: 1,
              }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className={`absolute w-48 sm:w-56 h-88 sm:h-96 rounded-[2.5rem] border backdrop-blur-xl p-2 flex flex-col justify-between transition-shadow cursor-pointer ${
                activeHoverLayer === 0 ? 'ring-2 ring-cyan-400 border-cyan-400 z-30 shadow-cyan-500/20 shadow-2xl' : 'border-cyan-500/30 bg-black/80 shadow-2xl z-20'
              }`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Display Screen Vector Graphics */}
              <div className="w-full h-full rounded-[2.2rem] bg-gradient-to-b from-zinc-950 via-zinc-900 to-black border border-cyan-500/20 relative overflow-hidden flex flex-col justify-between p-4">
                {/* Dynamic Island Cutout */}
                <div className="w-16 h-4 bg-black rounded-full mx-auto border border-zinc-800 flex items-center justify-end px-1.5 gap-1 shadow-inner">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500/80" />
                  <div className="w-1 h-1 rounded-full bg-emerald-500/80" />
                </div>

                {/* Clock & Status */}
                <div className="text-center my-auto space-y-1">
                  <div className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase">Tandem OLED • 120Hz</div>
                  <div className="text-3xl sm:text-4xl font-black tracking-tight text-white font-sans">17:00</div>
                  <div className="text-[11px] font-semibold text-zinc-400">iOS 19 Apple Intelligence Pro</div>
                </div>

                {/* Glass Reflection Highlight */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-cyan-400/5 to-white/10 pointer-events-none rounded-[2.2rem]" />
              </div>

              {/* Tag Badge */}
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-cyan-950 border border-cyan-500/50 text-cyan-300 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full shadow-lg whitespace-nowrap">
                01. Ceramic Shield Display
              </div>
            </motion.div>

            {/* LAYER 2: A19 PRO NEURAL LOGIC BOARD */}
            <motion.div
              ref={(el) => { layerRefs.current[1] = el; }}
              onMouseEnter={() => setActiveHoverLayer(1)}
              onMouseLeave={() => setActiveHoverLayer(null)}
              animate={isExploded ? {
                y: -60,
                z: 80,
                rotateX: 20,
                rotateY: -10,
                scale: 0.88,
              } : {
                y: 0,
                z: 20,
                rotateX: 0,
                rotateY: 0,
                scale: 1,
              }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className={`absolute w-44 sm:w-52 h-80 sm:h-88 rounded-[2rem] border backdrop-blur-xl p-3 flex flex-col items-center justify-center transition-shadow cursor-pointer ${
                activeHoverLayer === 1 ? 'ring-2 ring-purple-400 border-purple-400 z-30 shadow-purple-500/20 shadow-2xl' : 'border-purple-500/30 bg-zinc-950/90 shadow-2xl z-15'
              }`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Circuit Board Circuit Lines Vector */}
              <div className="w-full h-full rounded-[1.8rem] bg-zinc-900 border border-purple-500/20 relative p-3 flex flex-col items-center justify-center overflow-hidden">
                <svg className="absolute inset-0 w-full h-full opacity-20 text-purple-400 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M 20,20 L 60,20 L 80,40 L 80,120 M 120,30 L 120,80 L 150,110 M 40,200 L 90,200 L 110,180" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" />
                </svg>

                {/* Central A19 Pro Silicon Chip */}
                <div className="w-24 h-24 bg-gradient-to-br from-zinc-800 via-zinc-900 to-black rounded-2xl border-2 border-purple-400/60 shadow-xl flex flex-col items-center justify-center p-2 text-center relative group">
                  <div className="w-2 h-2 bg-purple-400 rounded-full absolute top-2 right-2 animate-ping" />
                  <Cpu className="w-7 h-7 text-purple-400 mb-1" />
                  <div className="text-xs font-black text-white tracking-wider">A19 PRO</div>
                  <div className="text-[8px] font-mono text-purple-300 font-extrabold mt-0.5">3nm SILICON</div>
                </div>

                <div className="text-[10px] text-zinc-400 font-mono mt-4 font-bold text-center">16-Core Neural Engine • 8GB Unified</div>
              </div>

              {/* Tag Badge */}
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-purple-950 border border-purple-500/50 text-purple-300 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full shadow-lg whitespace-nowrap">
                02. A19 Pro Logic Board
              </div>
            </motion.div>

            {/* LAYER 3: 48MP TRIPLE LENS OPTICS & LIDAR */}
            <motion.div
              ref={(el) => { layerRefs.current[2] = el; }}
              onMouseEnter={() => setActiveHoverLayer(2)}
              onMouseLeave={() => setActiveHoverLayer(null)}
              animate={isExploded ? {
                y: 0,
                z: 20,
                rotateX: 15,
                rotateY: -5,
                scale: 0.85,
              } : {
                y: 0,
                z: 0,
                rotateX: 0,
                rotateY: 0,
                scale: 1,
              }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className={`absolute w-44 sm:w-52 h-80 sm:h-88 rounded-[2rem] border backdrop-blur-xl p-3 flex flex-col items-start justify-start transition-shadow cursor-pointer ${
                activeHoverLayer === 2 ? 'ring-2 ring-emerald-400 border-emerald-400 z-30 shadow-emerald-500/20 shadow-2xl' : 'border-emerald-500/30 bg-zinc-950/80 shadow-2xl z-10'
              }`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Camera Plate Vector */}
              <div className="w-28 h-28 bg-gradient-to-br from-zinc-800 to-zinc-900 rounded-3xl border-2 border-emerald-500/40 p-2 grid grid-cols-2 gap-1.5 shadow-2xl relative">
                {/* Lenses */}
                <div className="w-9 h-9 rounded-full bg-black border-2 border-zinc-700 flex items-center justify-center shadow-inner">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/30 border border-emerald-400 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-cyan-400" />
                  </div>
                </div>
                <div className="w-9 h-9 rounded-full bg-black border-2 border-zinc-700 flex items-center justify-center shadow-inner">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/30 border border-emerald-400 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-cyan-400" />
                  </div>
                </div>
                <div className="w-9 h-9 rounded-full bg-black border-2 border-zinc-700 flex items-center justify-center shadow-inner">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/30 border border-emerald-400 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-cyan-400" />
                  </div>
                </div>

                {/* Flash & LiDAR */}
                <div className="w-9 h-9 flex flex-col items-center justify-center gap-1">
                  <div className="w-3.5 h-3.5 rounded-full bg-amber-200 border border-amber-400 shadow" />
                  <div className="w-2.5 h-2.5 rounded-full bg-black border border-zinc-600" />
                </div>
              </div>

              <div className="mt-6 p-2 bg-zinc-900/90 rounded-xl border border-emerald-500/20 text-[10px] text-zinc-300 font-mono w-full">
                <div className="font-bold text-emerald-400">48MP Quad-Fusion</div>
                <div>10x Optical Periscope Zoom</div>
              </div>

              {/* Tag Badge */}
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-emerald-950 border border-emerald-500/50 text-emerald-300 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full shadow-lg whitespace-nowrap">
                03. Triple Lens Optics & LiDAR
              </div>
            </motion.div>

            {/* LAYER 4: GRADE 5 TITANIUM CHASSIS FRAME */}
            <motion.div
              ref={(el) => { layerRefs.current[3] = el; }}
              onMouseEnter={() => setActiveHoverLayer(3)}
              onMouseLeave={() => setActiveHoverLayer(null)}
              animate={isExploded ? {
                y: 60,
                z: -50,
                rotateX: 10,
                rotateY: 0,
                scale: 0.82,
              } : {
                y: 0,
                z: -20,
                rotateX: 0,
                rotateY: 0,
                scale: 1,
              }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className={`absolute w-48 sm:w-56 h-88 sm:h-96 rounded-[2.5rem] border backdrop-blur-xl p-2 flex flex-col justify-between transition-shadow cursor-pointer ${
                activeHoverLayer === 3 ? 'ring-2 ring-amber-400 border-amber-400 z-30 shadow-amber-500/20 shadow-2xl' : 'border-amber-500/30 bg-zinc-900/90 shadow-2xl z-5'
              }`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Titanium Body Vector */}
              <div className="w-full h-full rounded-[2.2rem] bg-gradient-to-b from-zinc-800 via-zinc-900 to-black border-2 border-amber-500/30 p-4 relative flex flex-col justify-between items-center">
                {/* Camera Cutout Contour */}
                <div className="w-24 h-24 rounded-2xl border border-zinc-700 bg-black/60 self-start" />

                {/* Laser Engraved Apple Logo */}
                <div className="w-10 h-10 my-auto text-amber-200/80 flex items-center justify-center font-black text-2xl">
                  
                </div>

                <div className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-widest text-center">
                  Grade 5 Titanium Frame
                </div>
              </div>

              {/* Tag Badge */}
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-amber-950 border border-amber-500/50 text-amber-300 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full shadow-lg whitespace-nowrap">
                04. Grade 5 Titanium Chassis
              </div>
            </motion.div>

            {/* LAYER 5: SILICON-CARBON BATTERY & MAGSAFE COIL */}
            <motion.div
              ref={(el) => { layerRefs.current[4] = el; }}
              onMouseEnter={() => setActiveHoverLayer(4)}
              onMouseLeave={() => setActiveHoverLayer(null)}
              animate={isExploded ? {
                y: 120,
                z: -110,
                rotateX: 5,
                rotateY: 5,
                scale: 0.78,
              } : {
                y: 0,
                z: -40,
                rotateX: 0,
                rotateY: 0,
                scale: 1,
              }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className={`absolute w-44 sm:w-52 h-80 sm:h-88 rounded-[2rem] border backdrop-blur-xl p-3 flex flex-col items-center justify-center transition-shadow cursor-pointer ${
                activeHoverLayer === 4 ? 'ring-2 ring-rose-400 border-rose-400 z-30 shadow-rose-500/20 shadow-2xl' : 'border-rose-500/30 bg-zinc-950/90 shadow-2xl z-0'
              }`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Battery Block & MagSafe Ring Vector */}
              <div className="w-full h-full rounded-[1.8rem] bg-zinc-900 border border-rose-500/20 p-3 flex flex-col items-center justify-between relative overflow-hidden">
                <div className="w-full p-2 bg-black/80 rounded-xl border border-zinc-800 text-[9px] font-mono text-rose-300 font-bold flex items-center justify-between">
                  <span>4,850 mAh</span>
                  <span>45W / 25W MagSafe</span>
                </div>

                {/* MagSafe Coil Vector */}
                <div className="w-24 h-24 rounded-full border-4 border-dashed border-rose-400/60 flex items-center justify-center relative my-auto">
                  <div className="w-16 h-16 rounded-full border-2 border-rose-500/40 flex items-center justify-center">
                    <Battery className="w-6 h-6 text-rose-400" />
                  </div>
                </div>

                <div className="text-[9px] font-mono text-zinc-400 text-center">Silicon-Carbon High Density</div>
              </div>

              {/* Tag Badge */}
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-rose-950 border border-rose-500/50 text-rose-300 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full shadow-lg whitespace-nowrap">
                05. Battery & MagSafe Unit
              </div>
            </motion.div>

          </div>

        </div>

        {/* Right Column: Hardware Architecture Interactive Breakdown */}
        {showDetailsOverlay && (
          <div className="lg:col-span-5 space-y-4">
            <div className="p-5 bg-zinc-900/80 border border-zinc-800 rounded-2xl space-y-3">
              <div className="text-xs font-extrabold uppercase tracking-widest text-emerald-400 flex items-center justify-between">
                <span>Hardware Architecture</span>
                <span className="font-mono text-[10px] text-zinc-500">100% Genuine Certified</span>
              </div>

              <div className="space-y-2.5">
                {layers.map((l, i) => {
                  const Icon = l.icon;
                  return (
                    <div
                      key={l.id}
                      onMouseEnter={() => setActiveHoverLayer(i)}
                      onMouseLeave={() => setActiveHoverLayer(null)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        activeHoverLayer === i
                          ? 'bg-zinc-800 border-zinc-600 text-white shadow-lg'
                          : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg border ${l.accentColor}`}>
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="text-xs font-bold">{l.name}</div>
                          <div className="text-[10px] text-zinc-400 font-mono">{l.detail}</div>
                        </div>
                      </div>
                      <span className="text-[9px] font-mono uppercase text-zinc-500 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800 shrink-0">
                        {l.badge}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Price & CTA Footer */}
            <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-2xl flex items-center justify-between gap-4">
              <div>
                <div className="text-[10px] uppercase font-bold text-zinc-400">Flagship Pricing</div>
                <div className="text-xl font-black text-white">
                  {formatPrice(product.priceUSD, currentCurrency)}
                </div>
              </div>

              {onSelectProduct && (
                <button
                  onClick={() => onSelectProduct(product)}
                  className="px-5 py-2.5 bg-white text-black hover:bg-zinc-200 font-extrabold text-xs rounded-xl transition-all cursor-pointer shadow-md"
                >
                  Configure & Buy
                </button>
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
