import React, { useState, useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { ShoppingBag, Scale, Heart, Star, Check } from 'lucide-react';
import { Product, Currency } from '../types';
import { formatPrice } from '../data/currencies';
import { ProgressiveImage } from './ProgressiveImage';

const WhatsAppIcon = ({ className = "w-4 h-4" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.029 6.987 2.894a9.825 9.825 0 012.882 6.985c-.001 5.45-4.436 9.884-9.871 9.884M12.05 2c-5.833 0-10.58 4.747-10.58 10.58 0 1.865.488 3.687 1.416 5.297L1 23l5.292-1.388a10.53 10.53 0 005.752 1.688h.005c5.831 0 10.578-4.747 10.578-10.58A10.518 10.518 0 0012.05 2z" />
  </svg>
);

interface ProductCardProps {
  product: Product;
  currentCurrency: Currency;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, colorName?: string, storageSize?: string) => void;
  onToggleCompare: (product: Product) => void;
  isCompared: boolean;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  currentCurrency,
  onSelectProduct,
  onAddToCart,
  onToggleCompare,
  isCompared,
  onToggleWishlist,
  isWishlisted,
}) => {
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [addedAnimation, setAddedAnimation] = useState(false);
  const [glarePosition, setGlarePosition] = useState({ x: 50, y: 50, opacity: 0 });

  const cardRef = useRef<HTMLDivElement>(null);

  // Framer Motion Spring & MotionValues for 3D Tilt
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x, { stiffness: 300, damping: 20 });
  const mouseYSpring = useSpring(y, { stiffness: 300, damping: 20 });

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ['10deg', '-10deg']);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ['-10deg', '10deg']);
  
  const imgRotateX = useTransform(mouseYSpring, [-0.5, 0.5], ['6deg', '-6deg']);
  const imgRotateY = useTransform(mouseXSpring, [-0.5, 0.5], ['-6deg', '6deg']);
  const imgZ = useTransform(mouseXSpring, [-0.5, 0, 0.5], [10, 30, 10]);
  const imgScale = useTransform(mouseXSpring, [-0.5, 0, 0.5], [1.0, 1.08, 1.0]);

  // Mouse Move 3D Spring Tilt Handler
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;

    x.set(xPct);
    y.set(yPct);

    setGlarePosition({
      x: (mouseX / width) * 100,
      y: (mouseY / height) * 100,
      opacity: 0.25,
    });
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
    setGlarePosition((prev) => ({ ...prev, opacity: 0 }));
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card || !e.touches[0]) return;

    const rect = card.getBoundingClientRect();
    const touchX = e.touches[0].clientX - rect.left;
    const touchY = e.touches[0].clientY - rect.top;

    const xPct = touchX / rect.width - 0.5;
    const yPct = touchY / rect.height - 0.5;

    x.set(xPct * 0.6);
    y.set(yPct * 0.6);
  };

  const activeColor = product.colors?.[selectedColorIndex] || product.colors?.[0] || { name: 'Standard', hex: '#333333' };
  const activeStorage = product.storageOptions?.[0]?.size;

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, activeColor?.name, activeStorage);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1500);
  };

  const handleWhatsAppOrder = (e: React.MouseEvent) => {
    e.stopPropagation();
    const colorName = activeColor?.name || 'Standard';
    const storageOption = activeStorage || 'Standard';
    const formattedPrice = formatPrice(product.priceUSD, currentCurrency);

    const message = `Hello ElSory Store (السوري ستور)! 👋\n\nI would like to place a quick order / inquiry for:\n📱 *Product:* ${product.name} (${product.brand})\n🎨 *Color:* ${colorName}\n💾 *Storage:* ${storageOption}\n💰 *Price:* ${formattedPrice}\n\n📍 Please confirm stock availability at Zagazig store and delivery options to my location. Thank you!`;

    const url = `https://wa.me/201012345678?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleMouseLeave}
      onClick={() => onSelectProduct(product)}
      className="[perspective:1000px] cursor-pointer group select-none h-full"
    >
      <motion.div
        style={{
          rotateX,
          rotateY,
          transformStyle: 'preserve-3d',
        }}
        className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 group-hover:border-zinc-400 dark:group-hover:border-zinc-600 rounded-2xl overflow-hidden transition-colors duration-200 flex flex-col justify-between relative shadow-xs group-hover:shadow-2xl dark:group-hover:shadow-white/5 h-full"
      >
        {/* Dynamic Light Reflection / Glare Overlay */}
        <div
          className="absolute inset-0 pointer-events-none z-30 transition-opacity duration-300 rounded-2xl"
          style={{
            opacity: glarePosition.opacity,
            background: `radial-gradient(circle at ${glarePosition.x}% ${glarePosition.y}%, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0) 70%)`,
          }}
        />

        <div>
          {/* Top Badges & Actions */}
          <div className="p-4 pb-0 flex items-center justify-between z-20 [transform-style:preserve-3d]">
            <div>
              {product.badge && (
                <span
                  className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full tracking-wider uppercase inline-block shadow-xs ${
                    product.badge === 'Luxury Edition'
                      ? 'bg-amber-400 text-black'
                      : product.badge === 'New'
                      ? 'bg-zinc-900 dark:bg-white text-white dark:text-black'
                      : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700'
                  }`}
                >
                  {product.badge}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              {/* Compare Toggle */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleCompare(product);
                }}
                className={`p-2 rounded-full transition-colors ${
                  isCompared
                    ? 'bg-zinc-900 dark:bg-white text-white dark:text-black'
                    : 'bg-zinc-100 dark:bg-zinc-800/80 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-200 dark:hover:bg-zinc-700'
                }`}
                title={isCompared ? 'Remove from Compare' : 'Add to Compare'}
              >
                <Scale className="w-3.5 h-3.5" />
              </button>

              {/* Wishlist Toggle */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleWishlist(product);
                }}
                className={`p-2 rounded-full transition-colors ${
                  isWishlisted
                    ? 'bg-red-500 text-white'
                    : 'bg-zinc-100 dark:bg-zinc-800/80 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-200 dark:hover:bg-zinc-700'
                }`}
                title={isWishlisted ? 'Wishlisted' : 'Save to Wishlist'}
              >
                <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>
          </div>

          {/* 3D Pop-Out Image Container */}
          <div className="px-6 py-4 flex items-center justify-center h-48 sm:h-52 relative overflow-visible [transform-style:preserve-3d]">
            <motion.div
              style={{
                rotateX: imgRotateX,
                rotateY: imgRotateY,
                z: imgZ,
                scale: imgScale,
                transformStyle: 'preserve-3d',
              }}
              className="w-full h-full flex items-center justify-center"
            >
              <ProgressiveImage
                src={product.image}
                alt={product.name}
                className="max-h-40 sm:max-h-44 object-contain drop-shadow-[0_12px_20px_rgba(0,0,0,0.12)] dark:drop-shadow-[0_12px_20px_rgba(0,0,0,0.5)]"
              />
            </motion.div>
          </div>
        </div>

        {/* Product Details Footer */}
        <div className="p-4 sm:p-5 pt-2 bg-zinc-50/80 dark:bg-zinc-900/90 border-t border-zinc-100 dark:border-zinc-800/50 flex flex-col gap-2.5 z-10 transition-colors">
          {/* Brand & Ratings */}
          <div className="flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400">
            <span className="uppercase tracking-widest font-bold text-zinc-500 text-[10px]">{product.brand}</span>
            <div className="flex items-center gap-1 text-[11px]">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span className="font-semibold text-zinc-700 dark:text-zinc-200">{product.rating}</span>
              <span className="text-zinc-400 dark:text-zinc-500">({product.reviewsCount})</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="text-sm sm:text-base font-bold text-zinc-900 dark:text-white group-hover:text-black dark:group-hover:text-zinc-100 transition-colors line-clamp-1">
            {product.name}
          </h3>

          {/* Color Swatches */}
          {product.colors && product.colors.length > 0 ? (
            <div className="flex items-center gap-1.5 py-0.5">
              {product.colors.map((c, idx) => (
                <button
                  key={c.name}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedColorIndex(idx);
                  }}
                  className={`w-3.5 h-3.5 rounded-full border transition-transform ${
                    selectedColorIndex === idx
                      ? 'border-zinc-900 dark:border-white scale-125 ring-2 ring-black/20 dark:ring-white/30'
                      : 'border-zinc-300 dark:border-zinc-600 hover:scale-110'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                />
              ))}
              <span className="text-[10px] text-zinc-500 dark:text-zinc-400 ml-1 font-medium">{activeColor.name}</span>
            </div>
          ) : (
            <div className="h-5" />
          )}

          {/* Price & Add To Cart CTA */}
          <div className="pt-2 flex flex-col gap-2 border-t border-zinc-200 dark:border-zinc-800/80">
            <div className="flex items-center justify-between">
              <div>
                {product.hidePrice ? (
                  <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 dark:bg-emerald-500/20 px-2 py-0.5 rounded-lg border border-emerald-500/30">
                    Inquire Price
                  </div>
                ) : (
                  <>
                    <div className="text-base sm:text-lg font-extrabold text-zinc-900 dark:text-white">
                      {formatPrice(product.priceUSD, currentCurrency)}
                    </div>
                    {product.originalPriceUSD && (
                      <div className="text-[10px] text-zinc-400 dark:text-zinc-500 line-through font-mono">
                        {formatPrice(product.originalPriceUSD, currentCurrency)}
                      </div>
                    )}
                  </>
                )}
              </div>

              <button
                onClick={handleQuickAdd}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs ${
                  addedAnimation
                    ? 'bg-emerald-600 text-white'
                    : 'bg-zinc-900 dark:bg-white text-white dark:text-black hover:bg-zinc-800 dark:hover:bg-zinc-200'
                }`}
              >
                {addedAnimation ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> Added
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-3.5 h-3.5" /> Add
                  </>
                )}
              </button>
            </div>

            {/* Quick Order via WhatsApp Button */}
            <button
              onClick={handleWhatsAppOrder}
              className="w-full py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-[0.98]"
              title="Quick Order via WhatsApp"
            >
              <WhatsAppIcon className="w-3.5 h-3.5 text-white shrink-0" />
              <span>Quick Order via WhatsApp</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
