import React, { useState } from 'react';
import { X, ShoppingBag, ShieldCheck, Truck, Star, Check, Scale, Phone, Share2, Sparkles } from 'lucide-react';
import { Product, Currency } from '../types';
import { formatPrice } from '../data/currencies';
import { ProgressiveImage } from './ProgressiveImage';

interface ProductDetailModalProps {
  product: Product | null;
  currentCurrency: Currency;
  onClose: () => void;
  onAddToCart: (product: Product, colorName: string, storageSize?: string, quantity?: number) => void;
  onToggleCompare: (product: Product) => void;
  isCompared: boolean;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  currentCurrency,
  onClose,
  onAddToCart,
  onToggleCompare,
  isCompared,
}) => {
  if (!product) return null;

  const [selectedColor, setSelectedColor] = useState(product.colors[0] || { name: 'Standard', hex: '#ffffff' });
  const [selectedStorage, setSelectedStorage] = useState(
    product.storageOptions?.[0] || { size: 'Default', priceUSD: product.priceUSD }
  );
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedToast, setAddedToast] = useState(false);

  const images = product.gallery && product.gallery.length > 0 ? product.gallery : [product.image];
  const currentPriceUSD = selectedStorage?.priceUSD || product.priceUSD;

  const handleAddToCart = () => {
    onAddToCart(product, selectedColor.name, selectedStorage?.size, quantity);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2000);
  };

  const whatsappMessage = encodeURIComponent(
    `Hello ElSory Store (السوري ستور)! 👋\n\nI would like to place a quick order / inquiry for:\n📱 *Product:* ${product.name} (${product.brand})\n🎨 *Color:* ${selectedColor.name}\n💾 *Storage:* ${selectedStorage.size || 'Standard'}\n🔢 *Quantity:* ${quantity}\n💰 *Total Price:* ${formatPrice(currentPriceUSD * quantity, currentCurrency)}\n\n📍 Please confirm stock availability at Zagazig store and delivery options to my location. Thank you!`
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto text-white shadow-2xl relative my-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 z-20 p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 p-6 sm:p-8">
          
          {/* Left Gallery */}
          <div className="md:col-span-6 space-y-4">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 h-72 sm:h-80 flex items-center justify-center relative overflow-hidden">
              {product.badge && (
                <span className="absolute top-4 left-4 z-20 bg-white text-black text-xs font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
                  {product.badge}
                </span>
              )}
              <ProgressiveImage
                src={images[activeImageIndex] || product.image}
                alt={product.name}
                className="max-h-full max-w-full object-contain transition-all duration-300"
              />
            </div>

            {/* Thumbnail selector */}
            {images.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-1">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`w-16 h-16 rounded-xl bg-zinc-900 border p-1 shrink-0 overflow-hidden cursor-pointer transition-all ${
                      activeImageIndex === idx ? 'border-white ring-2 ring-white/30' : 'border-zinc-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <ProgressiveImage src={img} alt="thumb" className="w-full h-full object-contain" />
                  </button>
                ))}
              </div>
            )}

            {/* Quick Guarantee Highlights */}
            <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-2 text-xs text-zinc-400">
              <div className="flex items-center gap-2 text-zinc-200 font-semibold">
                <ShieldCheck className="w-4 h-4 text-white" /> 100% Genuine & {product.warrantyYears}-Year Official Warranty
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-white" /> Zagazig Same-Day Express & Egypt Nationwide Delivery
              </div>
            </div>
          </div>

          {/* Right Product Options */}
          <div className="md:col-span-6 space-y-6">
            <div>
              <div className="flex items-center justify-between text-xs text-zinc-400 mb-1">
                <span className="uppercase tracking-widest font-bold text-zinc-500">{product.brand}</span>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="font-bold text-white">{product.rating}</span>
                  <span>({product.reviewsCount} reviews)</span>
                </div>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                {product.name}
              </h2>
              <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Storage Selection */}
            {product.storageOptions && product.storageOptions.length > 0 && (
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                  Select Capacity
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {product.storageOptions.map((opt) => (
                    <button
                      key={opt.size}
                      onClick={() => setSelectedStorage(opt)}
                      className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all cursor-pointer text-center ${
                        selectedStorage.size === opt.size
                          ? 'bg-white text-black border-white shadow-md'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-600'
                      }`}
                    >
                      <div>{opt.size}</div>
                      <div className="text-[10px] font-normal opacity-75 mt-0.5">
                        {formatPrice(opt.priceUSD, currentCurrency)}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Color Selection */}
            {product.colors && product.colors.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                    Finish / Color
                  </label>
                  <span className="text-xs font-semibold text-white">{selectedColor.name}</span>
                </div>
                <div className="flex items-center gap-3">
                  {product.colors.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => setSelectedColor(c)}
                      className={`w-7 h-7 rounded-full border-2 transition-transform cursor-pointer ${
                        selectedColor.name === c.name
                          ? 'border-white scale-125 ring-4 ring-white/20'
                          : 'border-zinc-700 hover:scale-110'
                      }`}
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Quantity & Total Price */}
            <div className="pt-4 border-t border-zinc-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-zinc-500 uppercase tracking-wider block font-semibold">Total Price</span>
                {product.hidePrice ? (
                  <span className="text-sm font-extrabold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-lg border border-emerald-500/30 inline-block mt-1">
                    Contact us for today's price
                  </span>
                ) : (
                  <span className="text-2xl font-extrabold text-white">
                    {formatPrice(currentPriceUSD * quantity, currentCurrency)}
                  </span>
                )}
              </div>

              {/* Quantity Counter */}
              <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-xl p-1">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 rounded-lg text-zinc-400 hover:text-white flex items-center justify-center font-bold hover:bg-zinc-800"
                >
                  -
                </button>
                <span className="w-8 text-center text-sm font-bold text-white">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-8 h-8 rounded-lg text-zinc-400 hover:text-white flex items-center justify-center font-bold hover:bg-zinc-800"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5">
              <button
                onClick={handleAddToCart}
                className={`w-full py-3.5 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg ${
                  addedToast
                    ? 'bg-emerald-500 text-white'
                    : 'bg-white text-black hover:bg-zinc-200'
                }`}
              >
                {addedToast ? (
                  <>
                    <Check className="w-4 h-4" /> Added to Bag
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" /> Add to Shopping Bag
                  </>
                )}
              </button>

              <div className="grid grid-cols-2 gap-2">
                <a
                  href={`https://wa.me/201012345678?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-extrabold text-white flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                >
                  <Phone className="w-3.5 h-3.5 text-white" /> Quick Order via WhatsApp
                </a>

                <button
                  onClick={() => onToggleCompare(product)}
                  className={`py-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    isCompared
                      ? 'bg-zinc-800 text-white border-zinc-500'
                      : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  <Scale className="w-3.5 h-3.5" /> {isCompared ? 'Compared' : 'Compare Specs'}
                </button>
              </div>
            </div>

            {/* Detailed Hardware Specs Accordion */}
            <div className="pt-4 border-t border-zinc-800 space-y-3">
              <h4 className="text-xs font-extrabold uppercase tracking-widest text-zinc-400">
                Hardware Specifications
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-zinc-900/80 rounded-lg border border-zinc-800/80">
                  <span className="text-zinc-500 block text-[10px]">Display</span>
                  <span className="text-zinc-200 font-medium">{product.specsDetail.display}</span>
                </div>
                <div className="p-2.5 bg-zinc-900/80 rounded-lg border border-zinc-800/80">
                  <span className="text-zinc-500 block text-[10px]">Processor / Chipset</span>
                  <span className="text-zinc-200 font-medium">{product.specsDetail.chipset}</span>
                </div>
                <div className="p-2.5 bg-zinc-900/80 rounded-lg border border-zinc-800/80">
                  <span className="text-zinc-500 block text-[10px]">Main Camera</span>
                  <span className="text-zinc-200 font-medium">{product.specsDetail.mainCamera}</span>
                </div>
                <div className="p-2.5 bg-zinc-900/80 rounded-lg border border-zinc-800/80">
                  <span className="text-zinc-500 block text-[10px]">Battery & Charging</span>
                  <span className="text-zinc-200 font-medium">{product.specsDetail.battery} ({product.specsDetail.charging})</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
