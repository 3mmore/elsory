import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Smartphone } from 'lucide-react';

interface ProgressiveImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'onAnimationStart' | 'onDragStart' | 'onDragEnd' | 'onDrag'> {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
}

export const ProgressiveImage: React.FC<ProgressiveImageProps> = ({
  src,
  alt,
  className = '',
  containerClassName = '',
  ...props
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    setHasError(false);
    setIsLoaded(false);

    if (imgRef.current && imgRef.current.complete) {
      if (imgRef.current.naturalWidth > 0) {
        setIsLoaded(true);
      } else if (imgRef.current.src) {
        setHasError(true);
        setIsLoaded(true);
      }
    }
  }, [src]);

  return (
    <div className={`relative overflow-hidden flex items-center justify-center ${containerClassName}`}>
      {/* Skeleton Blur Background Pulse */}
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-200 via-zinc-100 to-zinc-200 dark:from-zinc-900 dark:via-zinc-800 dark:to-zinc-900 animate-pulse rounded-lg" />
      )}

      {hasError ? (
        <div className="w-full h-full min-h-[140px] flex flex-col items-center justify-center p-4 bg-zinc-100 dark:bg-zinc-800/80 rounded-xl text-zinc-400 dark:text-zinc-500 border border-zinc-200 dark:border-zinc-700/60 text-center">
          <Smartphone className="w-12 h-12 mb-2 text-zinc-400 dark:text-zinc-500 animate-pulse" />
          <span className="text-[11px] font-bold text-zinc-600 dark:text-zinc-300 line-clamp-1">{alt}</span>
          <span className="text-[9px] text-zinc-400">Official Device Asset</span>
        </div>
      ) : (
        <motion.img
          ref={imgRef}
          src={src}
          alt={alt}
          onLoad={() => setIsLoaded(true)}
          onError={() => {
            setHasError(true);
            setIsLoaded(true);
          }}
          initial={{ opacity: 0, filter: 'blur(8px)', scale: 1.02 }}
          animate={{
            opacity: isLoaded ? 1 : 0,
            filter: isLoaded ? 'blur(0px)' : 'blur(8px)',
            scale: isLoaded ? 1 : 1.02,
          }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className={className}
          referrerPolicy="no-referrer"
          {...props}
        />
      )}
    </div>
  );
};
