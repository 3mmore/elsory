import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Star, CheckCircle, MessageSquarePlus, X, Send } from 'lucide-react';
import { Review } from '../types';

export const ReviewsSection: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>([
    {
      id: 'rev-1',
      productId: 'syr-iphone16promax',
      authorName: 'Tareq K.',
      rating: 5,
      date: 'July 21, 2026',
      title: 'Flawless Damascus Same-Day Delivery!',
      comment: 'Ordered the iPhone 16 Pro Max 512GB Natural Titanium in Damascus. Arrived sealed with official 1-year Syrian warranty within 3 hours. Phenomenal service!',
      verifiedPurchase: true,
      recommended: true,
    },
    {
      id: 'rev-2',
      productId: 'syr-s25ultra',
      authorName: 'Lina M.',
      rating: 5,
      date: 'July 18, 2026',
      title: 'Galaxy S25 Ultra is a beast',
      comment: 'The camera zoom and Galaxy AI features are amazing. Syrian Store offered me a $650 trade-in voucher for my S23 Ultra which made upgrading seamless.',
      verifiedPurchase: true,
      recommended: true,
    },
    {
      id: 'rev-3',
      productId: 'syr-gold-iphone16',
      authorName: 'Eng. Basel H.',
      rating: 5,
      date: 'July 14, 2026',
      title: 'The 24K Gold Falcon Edition is pure artistry',
      comment: 'Pure luxury. The custom engraved Syrian Falcon on solid 24K gold is stunning. Hand delivered in a luxury wooden display box.',
      verifiedPurchase: true,
      recommended: true,
    },
    {
      id: 'rev-4',
      productId: 'syr-nothing2a',
      authorName: 'Rami A.',
      rating: 5,
      date: 'July 10, 2026',
      title: 'Nothing Phone 2a Plus design is legendary',
      comment: 'Unique design, smooth 120Hz display, great camera. Best value smartphone at Syrian Store!',
      verifiedPurchase: true,
      recommended: true,
    },
  ]);

  const [modalOpen, setModalOpen] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState(5);

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor || !newTitle || !newComment) return;

    const created: Review = {
      id: `rev-${Date.now()}`,
      productId: 'syr-iphone16promax',
      authorName: newAuthor,
      rating: newRating,
      date: 'Just Now',
      title: newTitle,
      comment: newComment,
      verifiedPurchase: true,
      recommended: true,
    };

    setReviews([created, ...reviews]);
    setNewAuthor('');
    setNewTitle('');
    setNewComment('');
    setModalOpen(false);
  };

  return (
    <motion.section 
      className="bg-zinc-950 text-white py-16 border-t border-zinc-800"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-zinc-500 mb-2">
              <CheckCircle className="w-4 h-4 text-white" /> Verified Customer Reviews
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
              WHAT OUR CLIENTS SAY
            </h2>
            <p className="text-zinc-400 text-sm mt-1">
              Read real experiences from tech enthusiasts across Syria.
            </p>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-center sm:text-right">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-400" />
                ))}
              </div>
              <div className="text-sm font-bold text-white mt-1">
                4.9 out of 5.0 <span className="text-zinc-500 font-normal">(800+ Ratings)</span>
              </div>
            </div>

            <button
              onClick={() => setModalOpen(true)}
              className="px-5 py-3 bg-white text-black hover:bg-zinc-200 font-bold rounded-xl text-xs transition-colors flex items-center gap-2 cursor-pointer shadow-md"
            >
              <MessageSquarePlus className="w-4 h-4" /> Write Review
            </button>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.map((rev, index) => (
            <motion.div
              key={rev.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.08 }}
              className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl flex flex-col justify-between space-y-4 shadow-md"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                    ))}
                  </div>
                  <span className="text-[10px] text-zinc-500">{rev.date}</span>
                </div>

                <h3 className="font-bold text-white text-sm leading-snug">{rev.title}</h3>
                <p className="text-xs text-zinc-400 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs">
                <span className="font-bold text-zinc-200">{rev.authorName}</span>
                <span className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" /> Verified Buyer
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Add Review Modal */}
        {modalOpen && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
            <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-lg w-full text-white shadow-2xl p-6 sm:p-8 relative">
              
              <button
                onClick={() => setModalOpen(false)}
                className="absolute top-5 right-5 p-2 bg-zinc-900 border border-zinc-800 rounded-full text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="text-xl font-extrabold text-white mb-4">Write a Verified Review</h3>

              <form onSubmit={handleAddReview} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-zinc-400 block mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Maher N."
                    value={newAuthor}
                    onChange={(e) => setNewAuthor(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-400 block mb-1">Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setNewRating(s)}
                        className={`p-2 rounded-lg border text-sm ${
                          newRating >= s ? 'bg-amber-400 text-black border-amber-400 font-bold' : 'bg-zinc-900 text-zinc-500 border-zinc-800'
                        }`}
                      >
                        ★ {s}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-400 block mb-1">Headline Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Premium quality & fast shipping"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-400 block mb-1">Review Experience</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Tell us about the phone and delivery..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-white text-black font-bold rounded-xl text-sm hover:bg-zinc-200 transition-colors"
                >
                  Submit Review
                </button>
              </form>
            </div>
          </div>
        )}

      </div>
    </motion.section>
  );
};

