import React from 'react';
import { motion, useScroll, useSpring } from 'motion/react';

export const ScrollProgress: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-zinc-400 via-white to-emerald-400 origin-left z-[100] shadow-[0_0_10px_rgba(255,255,255,0.5)] pointer-events-none"
      style={{ scaleX }}
    />
  );
};
