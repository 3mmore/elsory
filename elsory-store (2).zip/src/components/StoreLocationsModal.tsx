import React from 'react';
import { X, MapPin, Phone, Clock, Navigation, ExternalLink } from 'lucide-react';

interface StoreLocationsModalProps {
  onClose: () => void;
}

export const StoreLocationsModal: React.FC<StoreLocationsModalProps> = ({ onClose }) => {
  const stores = [
    {
      city: 'Zagazig (الزقازيق - الشرقية - مصر)',
      name: 'ELSORY STORE (السوري ستور) - Main Branch & Express Repair HQ',
      address: 'Villas El Gamea District, Al Qawmia, Zagazig, Sharqia Governorate, Egypt',
      phone: '+20 101 893 8933',
      hours: 'Daily: 10:00 AM - 11:00 PM',
      badge: 'Official Store & Certified Repair Center',
      isHQ: true,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-3xl w-full text-white shadow-2xl relative p-6 sm:p-8 my-auto max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white text-black rounded-xl">
              <MapPin className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                ElSory Store (السوري ستور) Branches
              </h2>
              <p className="text-xs text-zinc-400">
                Main Headquarters: Zagazig, Al Qawmia, Villas El Gamea District.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Store Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
          {stores.map((st, idx) => (
            <div
              key={idx}
              className={`p-5 bg-zinc-900 border ${st.isHQ ? 'border-white/50 bg-zinc-900/90' : 'border-zinc-800'} hover:border-zinc-500 rounded-2xl space-y-3 transition-colors flex flex-col justify-between`}
            >
              <div className="space-y-1.5">
                <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${st.isHQ ? 'bg-white text-black' : 'bg-zinc-800 text-zinc-300'}`}>
                  {st.badge}
                </span>
                <h3 className="text-base font-bold text-white pt-1">{st.name}</h3>
                <div className="text-xs text-zinc-400 flex items-start gap-1.5 pt-1">
                  <MapPin className="w-4 h-4 text-white shrink-0 mt-0.5" />
                  <span>{st.address}</span>
                </div>
              </div>

              <div className="space-y-2 pt-3 border-t border-zinc-800/80 text-xs text-zinc-400">
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-white" />
                  <a href={`tel:${st.phone}`} className="hover:text-white font-mono font-semibold">
                    {st.phone}
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-white" />
                  <span>{st.hours}</span>
                </div>
              </div>

              <div className="pt-2">
                <a
                  href={`https://wa.me/201018938933?text=Hello ElSory Store, I am inquiring about the store location in Zagazig`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" /> Contact via WhatsApp
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
