import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Image as ImageIcon, 
  Layers, 
  ShoppingBag, 
  Users, 
  Wrench, 
  Layout, 
  BookOpen, 
  Sparkles, 
  Brain, 
  ShieldCheck, 
  Settings, 
  Database, 
  LogOut, 
  ArrowLeft, 
  Bell, 
  Search, 
  Menu, 
  X,
  ChevronRight,
  MessageSquare
} from 'lucide-react';
import { adminStore } from '../../lib/adminStore';
import { AdminUser, Currency } from '../../types';

// Tab components
import { DashboardTab } from './tabs/DashboardTab';
import { ProductsTab } from './tabs/ProductsTab';
import { MediaTab } from './tabs/MediaTab';
import { CategoriesBrandsTab } from './tabs/CategoriesBrandsTab';
import { OrdersTab } from './tabs/OrdersTab';
import { CustomersTab } from './tabs/CustomersTab';
import { LeadsTab } from './tabs/LeadsTab';
import { RepairsTab } from './tabs/RepairsTab';
import { HomepageCMSTab } from './tabs/HomepageCMSTab';
import { BlogCMSTab } from './tabs/BlogCMSTab';
import { MarketingTab } from './tabs/MarketingTab';
import { AIManagementTab } from './tabs/AIManagementTab';
import { RBACUsersTab } from './tabs/RBACUsersTab';
import { SettingsTab } from './tabs/SettingsTab';
import { BackupsAuditTab } from './tabs/BackupsAuditTab';

interface AdminLayoutProps {
  isOpen: boolean;
  onClose: () => void;
  currentCurrency: Currency;
  onCurrencyChange: (c: Currency) => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  isOpen,
  onClose,
  currentCurrency,
  onCurrencyChange,
}) => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(adminStore.getCurrentUser());

  useEffect(() => {
    const unsub = adminStore.subscribe(() => {
      setCurrentUser(adminStore.getCurrentUser());
    });
    return () => {
      unsub();
    };
  }, []);

  if (!isOpen) return null;

  const handleLogout = () => {
    adminStore.setCurrentUser(null);
    onClose();
  };

  const navItems = [
    { key: 'dashboard', label: 'Dashboard Analytics', icon: LayoutDashboard, perm: 'dashboard_read' },
    { key: 'products', label: 'Product Catalog & CMS', icon: Package, perm: 'products_read' },
    { key: 'media', label: 'Media Asset Library', icon: ImageIcon, perm: 'cms_manage' },
    { key: 'categories_brands', label: 'Categories & Brands', icon: Layers, perm: 'categories_manage' },
    { key: 'orders', label: 'Order Fulfilment', icon: ShoppingBag, perm: 'orders_read' },
    { key: 'customers', label: 'Customer CRM', icon: Users, perm: 'customers_read' },
    { key: 'leads', label: 'Customer Leads & WhatsApp', icon: MessageSquare, perm: 'customers_read' },
    { key: 'repairs', label: 'Micro-Repair Lab', icon: Wrench, perm: 'repairs_read' },
    { key: 'homepage_cms', label: 'Homepage Builder', icon: Layout, perm: 'cms_manage' },
    { key: 'blog_cms', label: 'Blog & News CMS', icon: BookOpen, perm: 'blog_manage' },
    { key: 'marketing', label: 'Marketing & Coupons', icon: Sparkles, perm: 'marketing_manage' },
    { key: 'ai_manage', label: 'AI Store Assistant Studio', icon: Brain, perm: 'ai_manage' },
    { key: 'rbac_users', label: 'Admin Users & RBAC', icon: ShieldCheck, perm: 'users_manage' },
    { key: 'settings', label: 'Website Settings', icon: Settings, perm: 'settings_manage' },
    { key: 'backups', label: 'Backups & Audit Logs', icon: Database, perm: 'backups_manage' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black text-white flex flex-col overflow-hidden font-sans antialiased">
      
      {/* Top Header Navigation Bar */}
      <header className="h-16 bg-zinc-950 border-b border-zinc-800 px-4 flex items-center justify-between shrink-0 z-20">
        
        {/* Left Branding & Mobile Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-zinc-400 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-white text-black font-black text-xl rounded-xl flex items-center justify-center shadow-lg">
              S
            </div>
            <div>
              <div className="font-extrabold text-sm leading-none text-white tracking-wide flex items-center gap-1.5">
                <span>ELSORY ADMIN</span>
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[9px] font-bold px-2 py-0.5 rounded-full">
                  Enterprise
                </span>
              </div>
              <span className="text-[10px] text-zinc-500 font-mono">Control Center v2.5</span>
            </div>
          </div>
        </div>

        {/* Right Admin Controls */}
        <div className="flex items-center gap-3">
          
          {/* Back to Public Website CTA */}
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Return to Website</span>
          </button>

          {/* User Profile */}
          <div className="flex items-center gap-2 pl-2 border-l border-zinc-800">
            <img
              src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
              alt={currentUser?.name || 'Admin'}
              className="w-8 h-8 rounded-xl object-cover border border-zinc-700 shrink-0"
            />
            <div className="hidden lg:block text-left text-xs">
              <div className="font-bold text-white leading-none">{currentUser?.name || 'Ammar ElSory'}</div>
              <div className="text-[10px] text-emerald-400 font-semibold">{currentUser?.role || 'Super Admin'}</div>
            </div>

            <button
              onClick={handleLogout}
              className="p-2 text-zinc-400 hover:text-rose-400 hover:bg-zinc-900 rounded-xl transition-colors cursor-pointer"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

        </div>
      </header>

      {/* Main App Body */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* Sidebar Navigation */}
        <aside className={`fixed md:static inset-y-0 left-0 z-10 w-64 bg-zinc-950 border-r border-zinc-800 flex flex-col justify-between transition-transform duration-300 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}>
          
          <div className="p-3 space-y-1 overflow-y-auto flex-1">
            <div className="px-3 py-2 text-[10px] font-extrabold uppercase tracking-widest text-zinc-500">
              Management Modules
            </div>

            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.key;
              const hasPerm = adminStore.hasPermission(item.perm as any);

              if (!hasPerm) return null;

              return (
                <button
                  key={item.key}
                  onClick={() => {
                    setActiveTab(item.key);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-white text-black shadow-lg font-black'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-black' : 'text-zinc-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {isActive && <ChevronRight className="w-3.5 h-3.5 text-black" />}
                </button>
              );
            })}
          </div>

          {/* Footer Info */}
          <div className="p-4 border-t border-zinc-900 bg-zinc-950/80 text-[11px] text-zinc-500 space-y-1">
            <div className="font-bold text-zinc-400">ElSory Store HQ</div>
            <div>Zagazig, Sharqia, Egypt</div>
          </div>

        </aside>

        {/* Content Container */}
        <main className="flex-1 bg-zinc-950 p-4 md:p-6 overflow-y-auto">
          {activeTab === 'dashboard' && <DashboardTab currentCurrency={currentCurrency} onNavigateTab={setActiveTab} />}
          {activeTab === 'products' && <ProductsTab currentCurrency={currentCurrency} />}
          {activeTab === 'media' && <MediaTab />}
          {activeTab === 'categories_brands' && <CategoriesBrandsTab />}
          {activeTab === 'orders' && <OrdersTab currentCurrency={currentCurrency} />}
          {activeTab === 'customers' && <CustomersTab currentCurrency={currentCurrency} />}
          {activeTab === 'leads' && <LeadsTab />}
          {activeTab === 'repairs' && <RepairsTab />}
          {activeTab === 'homepage_cms' && <HomepageCMSTab />}
          {activeTab === 'blog_cms' && <BlogCMSTab />}
          {activeTab === 'marketing' && <MarketingTab />}
          {activeTab === 'ai_manage' && <AIManagementTab />}
          {activeTab === 'rbac_users' && <RBACUsersTab />}
          {activeTab === 'settings' && <SettingsTab />}
          {activeTab === 'backups' && <BackupsAuditTab />}
        </main>

      </div>

    </div>
  );
};
