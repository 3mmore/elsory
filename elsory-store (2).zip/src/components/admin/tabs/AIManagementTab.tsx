import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Upload, 
  Mic, 
  Video, 
  Image as ImageIcon, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Layers, 
  ShoppingBag, 
  TrendingUp, 
  Package, 
  Megaphone, 
  Brain, 
  Plus, 
  Trash2, 
  Copy, 
  Check, 
  ExternalLink, 
  Send, 
  Search, 
  Tag, 
  Percent, 
  Clock, 
  ShieldCheck, 
  ChevronRight, 
  Wand2, 
  RefreshCw,
  Eye,
  Sliders,
  DollarSign,
  Share2
} from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { safeFetch } from '../../../lib/apiClient';
import { Product, AIDocument } from '../../../types';
import { db, doc, setDoc } from '../../../lib/firebase';

export const AIManagementTab: React.FC = () => {
  // Navigation Sub-Tabs
  const [activeSubTab, setActiveSubTab] = useState<
    'creator' | 'optimizer' | 'inventory' | 'marketing' | 'approvals' | 'knowledge'
  >('creator');

  // Products & Store State
  const [products, setProducts] = useState<Product[]>(adminStore.getProducts());
  const [pendingApprovals, setPendingApprovals] = useState<any[]>(adminStore.getPendingAIApprovals());
  const [aiDocs, setAiDocs] = useState<AIDocument[]>(adminStore.getAIDocs());

  useEffect(() => {
    const unsubscribe = adminStore.subscribe(() => {
      setProducts([...adminStore.getProducts()]);
      setPendingApprovals([...adminStore.getPendingAIApprovals()]);
      setAiDocs([...adminStore.getAIDocs()]);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  // Toast Notification State
  const [toast, setToast] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  // ==========================================
  // SUB-TAB 1: AI PRODUCT CREATOR ASSISTANT
  // ==========================================
  const [creatorInput, setCreatorInput] = useState({
    productName: '',
    shortDescription: '',
    voiceNotesText: '',
    videoUrl: '',
    brand: 'Apple',
    estimatedPriceUSD: 1199,
  });
  const [uploadedImages, setUploadedImages] = useState<string[]>([
    'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=800&auto=format&fit=crop&q=80'
  ]);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [creatorLoading, setCreatorLoading] = useState(false);
  const [generatedDraft, setGeneratedDraft] = useState<any | null>(null);
  const [selectedPlacements, setSelectedPlacements] = useState<string[]>([
    'Featured Products',
    'Latest Arrivals',
    'Apple Category'
  ]);

  // Voice Note Recording Simulation
  const handleToggleVoiceRecording = () => {
    if (isRecordingVoice) {
      setIsRecordingVoice(false);
      showToast('Voice note transcribed successfully!');
    } else {
      setIsRecordingVoice(true);
      setCreatorInput((prev) => ({
        ...prev,
        voiceNotesText: 'Recording... (Speaking: iPhone 17 Pro Max 512GB Natural Titanium, brand new sealed with 1 year warranty and GaN fast charger included)',
      }));
      setTimeout(() => {
        setCreatorInput((prev) => ({
          ...prev,
          voiceNotesText: 'iPhone 17 Pro Max 512GB Natural Titanium, brand new sealed box with official 1 year ElSory warranty. Includes 45W GaN fast charger bundle and MagSafe protective armor case.',
        }));
        setIsRecordingVoice(false);
      }, 3000);
    }
  };

  // Handle Image Upload / Paste
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUploadedImages((prev) => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
    showToast('Image uploaded and queued for AI analysis.');
  };

  // Generate Product Entry via Server API
  const handleGenerateProductEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreatorLoading(true);

    try {
      const res = await safeFetch('/api/ai-product-creator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productName: creatorInput.productName || 'Flagship Smartphone',
          shortDescription: creatorInput.shortDescription,
          voiceNotesText: creatorInput.voiceNotesText,
          basicInfo: {
            brand: creatorInput.brand,
            estimatedPriceUSD: creatorInput.estimatedPriceUSD,
          },
          images: uploadedImages,
          videoUrl: creatorInput.videoUrl,
        }),
      });

      const data = await res.json();
      if (data.success && data.draftProduct) {
        setGeneratedDraft(data.draftProduct);
        if (data.draftProduct.websitePlacementSuggestions) {
          setSelectedPlacements(data.draftProduct.websitePlacementSuggestions);
        }
        showToast('AI analyzed content & generated complete product listing!');
      } else {
        showToast('AI analysis completed with default template.');
      }
    } catch (err) {
      console.error('Failed to generate product draft:', err);
      showToast('Generation complete!');
    } finally {
      setCreatorLoading(false);
    }
  };

  // Publish Draft Directly to Store Inventory
  const handlePublishDraftDirectly = async () => {
    if (!generatedDraft) return;

    const newProduct: Product = {
      id: `p-${Date.now()}`,
      name: generatedDraft.name || creatorInput.productName || 'New AI Product',
      nameArabic: generatedDraft.nameArabic || 'منتج جديد',
      brand: generatedDraft.brand || creatorInput.brand,
      category: generatedDraft.category || 'Smartphones',
      badge: generatedDraft.badge || 'New Arrival',
      priceUSD: generatedDraft.priceUSD || creatorInput.estimatedPriceUSD,
      originalPriceUSD: generatedDraft.originalPriceUSD || creatorInput.estimatedPriceUSD + 100,
      rating: 5.0,
      reviewsCount: 1,
      image: (uploadedImages.length > 0 ? uploadedImages[0] : 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80'),
      gallery: uploadedImages.length > 0 ? uploadedImages : [
        'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80'
      ],
      colors: generatedDraft.colors || [
        { name: 'Natural Titanium', hex: '#8a8680' },
        { name: 'Space Black', hex: '#2c2c2e' }
      ],
      storageOptions: (generatedDraft.storageOptions || ['256GB', '512GB']).map((s: string) => ({
        size: s,
        priceUSD: generatedDraft.priceUSD || creatorInput.estimatedPriceUSD
      })),
      description: generatedDraft.fullDescription || generatedDraft.shortDescription || 'High quality product available at ElSory Store.',
      features: generatedDraft.features || ['1-Year Official Warranty', 'Express Delivery in Zagazig', '0% Interest Installment Available'],
      specsDetail: generatedDraft.specsDetail || {
        display: '6.9" Super Retina OLED',
        chipset: 'Latest Flagship Chipset',
        mainCamera: 'Triple Lens System',
        selfieCamera: '12MP TrueDepth',
        battery: 'All-Day Battery Life',
        charging: '45W Fast Charge',
        weight: '221g',
        network: '5G Sub-6',
        os: 'iOS / Android',
        waterResistance: 'IP68'
      },
      warrantyYears: 1,
      inStock: true,
      stockQuantity: 10,
      sku: `ELS-${Date.now().toString().slice(-6)}`,
      seoTitle: generatedDraft.seoTitle || `${generatedDraft.name} | ElSory Store Zagazig`,
      seoDescription: generatedDraft.seoDescription || `Buy ${generatedDraft.name} in Zagazig with 1-Year Warranty.`,
    };

    adminStore.saveProduct(newProduct);

    try {
      await setDoc(doc(db, 'products', newProduct.id), newProduct);
      console.log('Saved AI draft product to Firestore:', newProduct.id);
    } catch (err) {
      console.warn('Firestore sync note:', err);
    }

    showToast(`Published "${newProduct.name}" to Live Store Catalog!`);
    setGeneratedDraft(null);
  };

  // Send to Pending AI Approvals Queue
  const handleSendToApprovalsQueue = () => {
    if (!generatedDraft) return;

    adminStore.addPendingAIApproval({
      id: `ai-app-${Date.now()}`,
      type: 'product_draft',
      title: `New Product Entry: ${generatedDraft.name}`,
      description: `Bilingual descriptions, specifications, SEO tags, and ${selectedPlacements.length} website placements suggested by AI.`,
      suggestedPlacement: selectedPlacements,
      payload: {
        id: `p-${Date.now()}`,
        name: generatedDraft.name,
        nameArabic: generatedDraft.nameArabic,
        brand: generatedDraft.brand,
        category: generatedDraft.category,
        badge: generatedDraft.badge,
        priceUSD: generatedDraft.priceUSD,
        originalPriceUSD: generatedDraft.originalPriceUSD,
        rating: 5.0,
        reviewsCount: 1,
        images: uploadedImages,
        colors: generatedDraft.colors || [{ name: 'Default', hex: '#000000' }],
        storageOptions: (generatedDraft.storageOptions || ['256GB']).map((s: string) => ({
          size: s,
          priceUSD: generatedDraft.priceUSD
        })),
        shortDescription: generatedDraft.shortDescription,
        shortDescriptionArabic: generatedDraft.shortDescriptionArabic,
        fullDescription: generatedDraft.fullDescription,
        fullDescriptionArabic: generatedDraft.fullDescriptionArabic,
        specifications: generatedDraft.specsDetail || {},
        warrantyYears: 1,
        inStock: true,
        stockQuantity: 10,
        sku: `SKU-${Date.now().toString().slice(-5)}`,
        seoTitle: generatedDraft.seoTitle,
        seoDescription: generatedDraft.seoDescription,
      },
      createdAt: new Date().toISOString(),
      status: 'Pending'
    });

    showToast('Sent draft to AI Pending Approvals queue!');
    setGeneratedDraft(null);
  };


  // ==========================================
  // SUB-TAB 2: AI SALES & PRODUCT OPTIMIZER
  // ==========================================
  const [selectedOptProductId, setSelectedOptProductId] = useState<string>(products[0]?.id || '');
  const [optLoading, setOptLoading] = useState(false);
  const [optResults, setOptResults] = useState<any | null>(null);

  const handleRunProductOptimization = async () => {
    const prod = products.find((p) => p.id === selectedOptProductId);
    if (!prod) return;

    setOptLoading(true);
    try {
      const res = await safeFetch('/api/ai-inventory-sales-optimizer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          selectedProduct: prod,
          task: 'product_sales_optimization',
        }),
      });
      const data = await res.json();
      if (data.success && data.insights) {
        setOptResults(data.insights.productOptimization || data.insights);
        showToast('AI Sales Optimization generated!');
      }
    } catch (err) {
      console.error('Optimization error:', err);
      showToast('Optimization analysis generated.');
    } finally {
      setOptLoading(false);
    }
  };

  const handleApplyOptimizationToProduct = () => {
    if (!optResults || !selectedOptProductId) return;
    const prod = products.find((p) => p.id === selectedOptProductId);
    if (!prod) return;

    const updated: Product = {
      ...prod,
      seoTitle: optResults.improvedTitle || prod.seoTitle,
      seoDescription: optResults.improvedDescriptionEN || prod.seoDescription,
      description: optResults.improvedDescriptionEN || prod.description,
    };

    adminStore.saveProduct(updated);
    showToast(`Applied AI sales optimizations to ${prod.name}!`);
  };


  // ==========================================
  // SUB-TAB 3: AI INVENTORY INTELLIGENCE
  // ==========================================
  const [invLoading, setInvLoading] = useState(false);
  const [invInsights, setInvInsights] = useState<any | null>({
    inventoryHealthScore: 94,
    lowStockAlerts: [
      {
        productName: 'iPhone 16 Pro Max 512GB Natural Titanium',
        currentStock: 3,
        recommendedReorder: 12,
        urgency: 'High',
        reason: 'Sales velocity is 2.4 units/day in Zagazig branch. Expected stockout in 36 hours.'
      },
      {
        productName: 'Anker MagGo GaN 100W Fast Charger',
        currentStock: 2,
        recommendedReorder: 25,
        urgency: 'Medium',
        reason: 'Frequently bundled with new Galaxy S25 & iPhone 16 purchases.'
      }
    ],
    unstockedDemandInsights: [
      {
        searchedTerm: 'Sony Xperia 1 VI 512GB',
        searchCount: 88,
        recommendation: '88 customer queries logged in Zagazig portal. Suggest import batch of 5 units.'
      },
      {
        searchedTerm: 'Asus ROG Phone 9 Pro Gaming Edition',
        searchCount: 64,
        recommendation: '64 search logs. High demand in Gaming Collection section.'
      }
    ],
    purchaseOrderDrafts: [
      {
        supplier: 'Official Authorized Apple Distributor Egypt',
        itemsToOrder: ['iPhone 16 Pro Max 512GB x12', 'AirPods Pro 2 x15'],
        estimatedCostUSD: 16200,
        notes: 'Urgent weekend restock order for Zagazig main store.'
      }
    ]
  });

  const handleAnalyzeInventoryIntelligence = async () => {
    setInvLoading(true);
    try {
      const res = await safeFetch('/api/ai-inventory-sales-optimizer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          inventory: products,
          searchQueries: ['Sony Xperia 1 VI', 'Asus ROG Phone 9', 'iPhone 16 Pro 1TB'],
          task: 'inventory_demand_analysis',
        }),
      });
      const data = await res.json();
      if (data.success && data.insights) {
        setInvInsights(data.insights);
        showToast('Inventory Intelligence analysis refreshed!');
      }
    } catch (err) {
      showToast('Inventory analysis refreshed.');
    } finally {
      setInvLoading(false);
    }
  };


  // ==========================================
  // SUB-TAB 4: AI MARKETING ASSISTANT
  // ==========================================
  const [marketingPrompt, setMarketingPrompt] = useState('');
  const [marketingFocus, setMarketingFocus] = useState('whatsapp');
  const [marketingLoading, setMarketingLoading] = useState(false);
  const [marketingReport, setMarketingReport] = useState<string | null>(`
### 🚀 WhatsApp Broadcast & Social Media Campaign
**Campaign Title:** ElSory Store Zagazig Flagship Extravaganza  
**Target Audience:** Registered Zagazig Clients & Tech Enthusiasts in Sharqia

#### 📲 WhatsApp Broadcast Message (Copy & Send):
> 🌟 **عروض حصرية من السوري ستور بالزقازيق!** 🌟  
> 
> اشتري أي هاتف آيفون 16 برو ماكس أو سامسونج S25 ألترا واحصل على:  
> ✅ شاحن أنكر الأصلي السريع مجاناً  
> ✅ جراب حماية فاخر وشاشة هيدروجيل حرارية  
> ✅ ضمان رسمي لمدة سنة كاملة من محل السوري ستور  
> 
> 🚚 **توصيل سريع مجاني بداخل الزقازيق خلال 60 دقيقة فقط!**  
> 💳 **أنظمة تقسيط متعددة:** فالي، سهولة، حاسبات، وبدون فوائد مع InstaPay.  
> 
> 📍 **فرعنا:** حي فيلات الجامعة - القومية - الزقازيق  
> 📞 **تواصل معنا فوراً على الواتساب:** +20 101 234 5678

---

#### 📱 Instagram Reels / TikTok Hook Concept:
- **Visual:** Fast cut of unboxing 24K Gold Syrian Edition iPhone 16 Pro Max inside ElSory Store Zagazig showroom.
- **Audio Hook:** "هل تعلم أنك تقدر تجيب أحدث آيفون بالزقازيق بالتقسيط المباشر وبضمان سنة؟"
- **CTA:** "زرنا اليوم بفرع القومية بالزقازيق أو احجز جهازك أونلاين!"
`);

  const handleGenerateMarketingCampaign = async () => {
    setMarketingLoading(true);
    try {
      const res = await safeFetch('/api/ai-marketing-analyst', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          focusArea: marketingFocus,
          customPrompt: marketingPrompt,
        }),
      });
      const data = await res.json();
      if (data.report) {
        setMarketingReport(data.report);
        showToast('Marketing Campaign Generated!');
      }
    } catch (err) {
      showToast('Campaign generated!');
    } finally {
      setMarketingLoading(false);
    }
  };

  const handleCopyMarketingCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast('Copied campaign text to clipboard!');
  };


  // ==========================================
  // SUB-TAB 5: AI APPROVALS QUEUE
  // ==========================================
  const handleApproveProposal = (id: string) => {
    adminStore.approveAIProposal(id);
    showToast('Approved and executed AI proposal!');
  };

  const handleRejectProposal = (id: string) => {
    adminStore.rejectAIProposal(id);
    showToast('Rejected AI proposal.');
  };


  // ==========================================
  // SUB-TAB 6: AI KNOWLEDGE BASE (RAG)
  // ==========================================
  const [docTitle, setDocTitle] = useState('');
  const [docCategory, setDocCategory] = useState<AIDocument['category']>('Warranty');
  const [docContent, setDocContent] = useState('');
  const [showDocModal, setShowDocModal] = useState(false);

  const handleSaveDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim() || !docContent.trim()) return;

    const newDoc: AIDocument = {
      id: `doc-${Date.now()}`,
      title: docTitle,
      category: docCategory,
      content: docContent,
      uploadedAt: new Date().toISOString(),
      size: `${Math.round(docContent.length / 100)} KB`,
      status: 'Indexed',
    };

    adminStore.saveAIDoc(newDoc);
    setShowDocModal(false);
    setDocTitle('');
    setDocContent('');
    showToast('Knowledge Document Indexed into AI Concierge!');
  };

  const handleDeleteDoc = (id: string) => {
    adminStore.deleteAIDoc(id);
    showToast('Deleted AI Knowledge document.');
  };


  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      
      {/* Toast Notification Banner */}
      {toast && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-500 text-black font-extrabold text-xs px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 animate-bounce">
          <CheckCircle className="w-4 h-4" />
          <span>{toast}</span>
        </div>
      )}

      {/* Main Studio Header */}
      <div className="p-6 bg-gradient-to-r from-zinc-950 via-purple-950/40 to-zinc-950 border border-purple-900/50 rounded-3xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-1 relative z-10">
          <div className="flex items-center gap-2">
            <span className="bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-purple-400" /> AI Co-Pilot & Studio v3.0
            </span>
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
              Full Store Autopilot
            </span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">
            ElSory Store AI Management Assistant
          </h1>
          <p className="text-xs text-zinc-400 max-w-2xl leading-relaxed">
            Your automated E-commerce Director, Product Manager, Content Creator, SEO Specialist, Sales Advisor, and Marketing Manager in one studio.
          </p>
        </div>

        {/* Quick Pending AI Approvals Badge */}
        <div className="flex items-center gap-3 relative z-10 shrink-0">
          <button
            onClick={() => setActiveSubTab('approvals')}
            className="p-3 bg-zinc-900/90 border border-zinc-800 hover:border-purple-500/50 rounded-2xl flex items-center gap-3 transition-all cursor-pointer group"
          >
            <div className="w-9 h-9 bg-purple-600/20 text-purple-400 rounded-xl flex items-center justify-center font-bold text-sm group-hover:scale-105 transition-transform">
              {pendingApprovals.length}
            </div>
            <div className="text-left text-xs">
              <div className="font-bold text-white flex items-center gap-1">
                Pending Approvals <ChevronRight className="w-3.5 h-3.5 text-zinc-500" />
              </div>
              <div className="text-[10px] text-zinc-400">Owner final review queue</div>
            </div>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-zinc-800 scrollbar-none">
        <button
          onClick={() => setActiveSubTab('creator')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'creator'
              ? 'bg-purple-600 text-white shadow-lg font-black'
              : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Wand2 className="w-4 h-4" />
          <span>Product Creator</span>
        </button>

        <button
          onClick={() => setActiveSubTab('optimizer')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'optimizer'
              ? 'bg-purple-600 text-white shadow-lg font-black'
              : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Sales & Product Optimizer</span>
        </button>

        <button
          onClick={() => setActiveSubTab('inventory')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'inventory'
              ? 'bg-purple-600 text-white shadow-lg font-black'
              : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Inventory Assistant</span>
        </button>

        <button
          onClick={() => setActiveSubTab('marketing')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'marketing'
              ? 'bg-purple-600 text-white shadow-lg font-black'
              : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          <span>Marketing Assistant</span>
        </button>

        <button
          onClick={() => setActiveSubTab('approvals')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'approvals'
              ? 'bg-purple-600 text-white shadow-lg font-black'
              : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <CheckCircle className="w-4 h-4" />
          <span>Approvals Queue ({pendingApprovals.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('knowledge')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'knowledge'
              ? 'bg-purple-600 text-white shadow-lg font-black'
              : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Brain className="w-4 h-4" />
          <span>Knowledge Base (RAG)</span>
        </button>
      </div>


      {/* ========================================================================= */}
      {/* SUB-TAB 1: AI PRODUCT CREATOR ASSISTANT                                   */}
      {/* ========================================================================= */}
      {activeSubTab === 'creator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Input Form Column (5 Cols) */}
          <div className="lg:col-span-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h2 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-purple-400" />
                <span>Upload Product Content & Assets</span>
              </h2>
              <span className="text-[10px] text-zinc-400">Multimodal Gemini AI</span>
            </div>

            <form onSubmit={handleGenerateProductEntry} className="space-y-4 text-xs">
              
              {/* Product Name / Raw Prompt */}
              <div>
                <label className="block text-zinc-300 font-bold mb-1">
                  Product Name or Raw Prompt
                </label>
                <input
                  type="text"
                  value={creatorInput.productName}
                  onChange={(e) => setCreatorInput({ ...creatorInput, productName: e.target.value })}
                  placeholder="e.g. Add new Samsung Galaxy S25 Ultra 512GB Titanium"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              {/* Brand & Price Row */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-300 font-bold mb-1">Brand</label>
                  <select
                    value={creatorInput.brand}
                    onChange={(e) => setCreatorInput({ ...creatorInput, brand: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="Apple">Apple</option>
                    <option value="Samsung">Samsung</option>
                    <option value="Xiaomi">Xiaomi</option>
                    <option value="Google">Google</option>
                    <option value="Nothing">Nothing</option>
                    <option value="Anker">Anker</option>
                  </select>
                </div>

                <div>
                  <label className="block text-zinc-300 font-bold mb-1">Estimated Price (USD)</label>
                  <input
                    type="number"
                    value={creatorInput.estimatedPriceUSD}
                    onChange={(e) => setCreatorInput({ ...creatorInput, estimatedPriceUSD: Number(e.target.value) })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              {/* Voice Notes Input / Recorder */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-zinc-300 font-bold flex items-center gap-1.5">
                    <Mic className="w-3.5 h-3.5 text-purple-400" /> Voice Notes / Audio Instructions
                  </label>
                  <button
                    type="button"
                    onClick={handleToggleVoiceRecording}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded-lg cursor-pointer transition-all ${
                      isRecordingVoice 
                        ? 'bg-rose-600 text-white animate-pulse' 
                        : 'bg-purple-600/20 text-purple-300 border border-purple-500/30 hover:bg-purple-600/40'
                    }`}
                  >
                    {isRecordingVoice ? 'Recording... (Click Stop)' : '🎤 Record Voice Note'}
                  </button>
                </div>
                <textarea
                  rows={2}
                  value={creatorInput.voiceNotesText}
                  onChange={(e) => setCreatorInput({ ...creatorInput, voiceNotesText: e.target.value })}
                  placeholder="Record voice notes or paste transcript details (e.g., 'In stock 512GB Titanium Black with 1 yr warranty')..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white text-xs"
                />
              </div>

              {/* Product Images Drag & Drop / File Input */}
              <div>
                <label className="block text-zinc-300 font-bold mb-1.5 flex items-center justify-between">
                  <span>Product Images ({uploadedImages.length})</span>
                  <span className="text-[10px] text-zinc-500">Auto background cleanup & thumbnail selection</span>
                </label>

                {/* Uploaded Gallery Previews */}
                <div className="grid grid-cols-4 gap-2 mb-2">
                  {uploadedImages.map((img, idx) => (
                    <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-zinc-800 group">
                      <img src={img} alt={`Asset ${idx}`} className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setUploadedImages(uploadedImages.filter((_, i) => i !== idx))}
                        className="absolute top-1 right-1 bg-black/80 text-rose-400 p-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                      {idx === 0 && (
                        <span className="absolute bottom-1 left-1 bg-purple-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded">
                          Main
                        </span>
                      )}
                    </div>
                  ))}

                  <label className="aspect-square border-2 border-dashed border-zinc-800 hover:border-purple-500 rounded-xl flex flex-col items-center justify-center text-zinc-500 hover:text-purple-400 cursor-pointer transition-colors">
                    <Upload className="w-4 h-4 mb-1" />
                    <span className="text-[9px] font-bold">+ Upload</span>
                    <input type="file" multiple accept="image/*" onChange={handleImageUpload} className="hidden" />
                  </label>
                </div>
              </div>

              {/* Video Link */}
              <div>
                <label className="block text-zinc-300 font-bold mb-1 flex items-center gap-1.5">
                  <Video className="w-3.5 h-3.5 text-purple-400" /> Product Video URL
                </label>
                <input
                  type="url"
                  value={creatorInput.videoUrl}
                  onChange={(e) => setCreatorInput({ ...creatorInput, videoUrl: e.target.value })}
                  placeholder="https://youtube.com/shorts/... or video link"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white text-xs"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={creatorLoading}
                className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xl transition-all disabled:opacity-50"
              >
                {creatorLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Analyzing Multimodal Assets with Gemini...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-purple-200" />
                    <span>Generate Complete Product Entry</span>
                  </>
                )}
              </button>

            </form>
          </div>


          {/* Output Preview Column (7 Cols) */}
          <div className="lg:col-span-7 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div>
                <h2 className="text-sm font-extrabold text-white flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>AI Generated Product Draft & Approval Review</span>
                </h2>
                <p className="text-[10px] text-zinc-400">Owner maintains final approval before storefront publishing</p>
              </div>

              {generatedDraft && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSendToApprovalsQueue}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold rounded-xl text-xs cursor-pointer"
                  >
                    Save to Queue
                  </button>
                  <button
                    onClick={handlePublishDraftDirectly}
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-black font-extrabold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-lg"
                  >
                    <CheckCircle className="w-3.5 h-3.5" /> Publish to Store
                  </button>
                </div>
              )}
            </div>

            {!generatedDraft && !creatorLoading && (
              <div className="py-16 text-center space-y-3">
                <div className="w-16 h-16 bg-zinc-800 text-purple-400 rounded-3xl flex items-center justify-center mx-auto">
                  <Wand2 className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-white text-sm">Ready to Create Product</h3>
                <p className="text-xs text-zinc-500 max-w-sm mx-auto">
                  Upload images, video, or voice notes on the left and click "Generate Complete Product Entry". The AI will assemble a publication-ready entry.
                </p>
              </div>
            )}

            {creatorLoading && (
              <div className="py-16 text-center space-y-3">
                <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
                <h3 className="font-bold text-white text-sm">AI Engine Analyzing Content...</h3>
                <p className="text-xs text-zinc-400">Detecting brand, extracting specs, writing bilingual copy, and generating SEO metadata...</p>
              </div>
            )}

            {generatedDraft && !creatorLoading && (
              <div className="space-y-4 animate-fadeIn text-xs">
                
                {/* Header Title & Pricing Card */}
                <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-purple-400 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded-full">
                      {generatedDraft.brand} &bull; {generatedDraft.category}
                    </span>
                    <span className="text-sm font-black text-emerald-400 font-mono">
                      ${generatedDraft.priceUSD} <span className="text-zinc-500 line-through text-xs">${generatedDraft.originalPriceUSD}</span>
                    </span>
                  </div>

                  <h3 className="text-base font-extrabold text-white">{generatedDraft.name}</h3>
                  <div className="text-xs font-semibold text-zinc-300 font-arabic text-right">{generatedDraft.nameArabic}</div>
                </div>

                {/* Bilingual Descriptions */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-1">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">English Description</span>
                    <p className="text-zinc-300 text-xs leading-relaxed">{generatedDraft.shortDescription}</p>
                  </div>

                  <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-1 text-right font-arabic">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">الوصف بالعربية</span>
                    <p className="text-zinc-300 text-xs leading-relaxed">{generatedDraft.shortDescriptionArabic}</p>
                  </div>
                </div>

                {/* Extracted Specs Table */}
                <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                  <span className="text-[10px] font-extrabold text-purple-400 uppercase tracking-wider">Extracted Hardware Specifications</span>
                  <div className="grid grid-cols-2 gap-2 text-zinc-300 text-[11px]">
                    <div><span className="text-zinc-500 font-bold">Display:</span> {generatedDraft.specsDetail?.display || '6.9" OLED'}</div>
                    <div><span className="text-zinc-500 font-bold">Chipset:</span> {generatedDraft.specsDetail?.chipset || 'A19 Pro Silicon'}</div>
                    <div><span className="text-zinc-500 font-bold">Camera:</span> {generatedDraft.specsDetail?.mainCamera || '48MP Triple'}</div>
                    <div><span className="text-zinc-500 font-bold">Battery:</span> {generatedDraft.specsDetail?.battery || '4682 mAh'}</div>
                  </div>
                </div>

                {/* Smart Image Management Insights */}
                <div className="p-4 bg-purple-950/20 border border-purple-800/40 rounded-2xl space-y-2">
                  <span className="text-[10px] font-extrabold text-purple-300 uppercase tracking-wider flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5" /> Smart Image & Gallery Optimization
                  </span>
                  <p className="text-zinc-300 text-xs">
                    {generatedDraft.smartImageAnalysis?.cropRecommendations || 'Image crop 1:1 ratio applied. Background clean with studio contrast.'}
                  </p>
                  <div className="text-[10px] text-zinc-400">
                    Alt Text: "{generatedDraft.smartImageAnalysis?.imageAltTexts?.[0] || generatedDraft.name}"
                  </div>
                </div>

                {/* Smart Website Placement Suggestions */}
                <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                  <span className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider">
                    Smart Website Placement Suggestions
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {['Featured Products', 'Latest Arrivals', 'Apple Category', 'Gaming Collection', 'Flash Deals'].map((place) => {
                      const isSelected = selectedPlacements.includes(place);
                      return (
                        <button
                          key={place}
                          type="button"
                          onClick={() => {
                            if (isSelected) setSelectedPlacements(selectedPlacements.filter((p) => p !== place));
                            else setSelectedPlacements([...selectedPlacements, place]);
                          }}
                          className={`px-3 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer border ${
                            isSelected
                              ? 'bg-purple-600 text-white border-purple-500'
                              : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'
                          }`}
                        >
                          {isSelected ? '✓ ' : '+ '} {place}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* SEO Metadata */}
                <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-1.5 font-mono text-[11px]">
                  <span className="text-[10px] font-extrabold text-emerald-400 uppercase tracking-wider font-sans">
                    SEO Preview & Metadata
                  </span>
                  <div className="text-blue-400 font-bold truncate">{generatedDraft.seoTitle}</div>
                  <div className="text-zinc-400 text-[10px] line-clamp-2">{generatedDraft.seoDescription}</div>
                </div>

                {/* Final Action Buttons */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handlePublishDraftDirectly}
                    className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-black rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xl transition-all"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>Approve & Publish to Live Inventory</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSendToApprovalsQueue}
                    className="px-5 py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl text-xs cursor-pointer"
                  >
                    Send to Queue
                  </button>
                </div>

              </div>
            )}

          </div>

        </div>
      )}


      {/* ========================================================================= */}
      {/* SUB-TAB 2: AI SALES & PRODUCT OPTIMIZER                                   */}
      {/* ========================================================================= */}
      {activeSubTab === 'optimizer' && (
        <div className="space-y-6">
          <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-4 shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-purple-400" />
                  <span>AI Sales & Conversion Optimizer</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Select any existing product in inventory. AI will evaluate titles, pricing strategy, and generate high-margin bundle offers.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <select
                  value={selectedOptProductId}
                  onChange={(e) => setSelectedOptProductId(e.target.value)}
                  className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-bold text-white max-w-xs"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (${p.priceUSD})
                    </option>
                  ))}
                </select>

                <button
                  onClick={handleRunProductOptimization}
                  disabled={optLoading}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer"
                >
                  {optLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                  <span>Run AI Optimization</span>
                </button>
              </div>
            </div>

            {optResults && (
              <div className="p-5 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-4 animate-fadeIn text-xs">
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-zinc-900/80 border border-zinc-800 rounded-xl space-y-2">
                    <span className="text-[10px] font-bold text-purple-400 uppercase">Original Product Title</span>
                    <div className="font-bold text-white text-sm">{optResults.originalTitle || 'Selected Device'}</div>
                  </div>

                  <div className="p-4 bg-purple-950/20 border border-purple-800/40 rounded-xl space-y-2">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase">AI Improved Title</span>
                    <div className="font-bold text-white text-sm">{optResults.improvedTitle || 'Optimized Title'}</div>
                  </div>
                </div>

                {/* Improved Copywriting */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl space-y-1">
                    <span className="text-[10px] font-bold text-zinc-400">High Converting English Copy</span>
                    <p className="text-zinc-300 text-xs">{optResults.improvedDescriptionEN}</p>
                  </div>

                  <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl space-y-1 text-right font-arabic">
                    <span className="text-[10px] font-bold text-zinc-400">وصف تسويقي أسرع في المبيعات</span>
                    <p className="text-zinc-300 text-xs">{optResults.improvedDescriptionAR}</p>
                  </div>
                </div>

                {/* Pricing & Bundle Strategy */}
                <div className="p-4 bg-zinc-900/80 border border-zinc-800 rounded-xl space-y-2">
                  <span className="text-[10px] font-extrabold text-amber-400 uppercase tracking-wider">
                    Recommended High-Margin Accessory Bundle
                  </span>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">{optResults.bundleOffer?.bundleTitle || 'VIP Starter Bundle'}</div>
                      <div className="text-zinc-400 text-xs">
                        Includes: {(optResults.bundleOffer?.items || ['45W GaN Charger', 'Hydrogel Guard']).join(', ')}
                      </div>
                    </div>
                    <button
                      onClick={handleApplyOptimizationToProduct}
                      className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold rounded-xl text-xs cursor-pointer shadow-lg shrink-0"
                    >
                      Apply Optimization to Product
                    </button>
                  </div>
                </div>

              </div>
            )}
          </div>
        </div>
      )}


      {/* ========================================================================= */}
      {/* SUB-TAB 3: AI INVENTORY ASSISTANT                                         */}
      {/* ========================================================================= */}
      {activeSubTab === 'inventory' && (
        <div className="space-y-6">
          
          <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex items-center justify-between gap-4 shadow-xl">
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <Package className="w-5 h-5 text-purple-400" />
                <span>AI Inventory Intelligence & Restock Assistant</span>
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Real-time stock velocity monitoring, customer search log demand analysis, and automated Purchase Order drafts.
              </p>
            </div>

            <button
              onClick={handleAnalyzeInventoryIntelligence}
              disabled={invLoading}
              className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shrink-0"
            >
              {invLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              <span>Refresh Stock Analysis</span>
            </button>
          </div>

          {/* Health Score Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-2">
              <span className="text-[10px] font-bold text-zinc-400 uppercase">Inventory Health Index</span>
              <div className="text-3xl font-black text-emerald-400">{invInsights?.inventoryHealthScore || 94}/100</div>
              <p className="text-[11px] text-zinc-400">Stock rotation velocity is healthy across Zagazig branch.</p>
            </div>

            <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-2">
              <span className="text-[10px] font-bold text-amber-400 uppercase">Low-Stock Warnings</span>
              <div className="text-3xl font-black text-amber-400">{invInsights?.lowStockAlerts?.length || 2} Items</div>
              <p className="text-[11px] text-zinc-400">High demand items requiring reorder before weekend.</p>
            </div>

            <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-2">
              <span className="text-[10px] font-bold text-purple-400 uppercase">Unstocked Customer Queries</span>
              <div className="text-3xl font-black text-purple-400">152 Logs</div>
              <p className="text-[11px] text-zinc-400">Customers searched for products not currently in store.</p>
            </div>
          </div>

          {/* Low Stock Reorder Table */}
          <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-3">
            <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              <span>Low-Stock Products Needing Reorder</span>
            </h3>

            <div className="space-y-2 text-xs">
              {invInsights?.lowStockAlerts?.map((alert: any, idx: number) => (
                <div key={idx} className="p-3 bg-zinc-950 border border-zinc-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="font-bold text-white">{alert.productName}</div>
                    <div className="text-zinc-400 text-[11px]">{alert.reason}</div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="text-amber-400 font-bold">In Stock: {alert.currentStock}</div>
                      <div className="text-emerald-400 font-semibold">Rec. Reorder: +{alert.recommendedReorder}</div>
                    </div>
                    <button
                      onClick={() => showToast(`Added purchase order draft for ${alert.productName}`)}
                      className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs cursor-pointer"
                    >
                      Draft Purchase Order
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Unstocked Demand & Customer Searches */}
          <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-3">
            <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
              <Search className="w-4 h-4 text-purple-400" />
              <span>Unstocked Search Demand Logs (Customer Intent)</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {invInsights?.unstockedDemandInsights?.map((demand: any, idx: number) => (
                <div key={idx} className="p-4 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-white">{demand.searchedTerm}</span>
                    <span className="bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full font-mono text-[10px]">
                      {demand.searchCount} Searches
                    </span>
                  </div>
                  <p className="text-zinc-400 text-[11px]">{demand.recommendation}</p>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}


      {/* ========================================================================= */}
      {/* SUB-TAB 4: AI MARKETING ASSISTANT                                         */}
      {/* ========================================================================= */}
      {activeSubTab === 'marketing' && (
        <div className="space-y-6">
          <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-4 shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                  <Megaphone className="w-5 h-5 text-purple-400" />
                  <span>AI Marketing Campaign Creator</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Generate Facebook Ads, Instagram Reels ideas, TikTok hooks, and local WhatsApp broadcast copy for Egyptian clients.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={marketingFocus}
                  onChange={(e) => setMarketingFocus(e.target.value)}
                  className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-bold text-white"
                >
                  <option value="whatsapp">WhatsApp Egyptian Broadcast</option>
                  <option value="meta_ads">Meta Facebook & Instagram Ads</option>
                  <option value="tiktok_reels">TikTok Viral Reel Ideas</option>
                  <option value="google_ads">Google Ads Headlines</option>
                </select>

                <button
                  onClick={handleGenerateMarketingCampaign}
                  disabled={marketingLoading}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shrink-0"
                >
                  {marketingLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>Generate Campaign</span>
                </button>
              </div>
            </div>

            {/* Optional Custom Instructions Input */}
            <div>
              <input
                type="text"
                value={marketingPrompt}
                onChange={(e) => setMarketingPrompt(e.target.value)}
                placeholder="Optional custom theme (e.g., 'Promote 10% discount on Galaxy S25 Ultra for Ramadan season in Zagazig')..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-white text-xs"
              />
            </div>

            {/* Generated Marketing Campaign Output */}
            {marketingReport && (
              <div className="p-5 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-4 animate-fadeIn text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                  <span className="font-extrabold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4" /> Ready Marketing Copy
                  </span>
                  <button
                    onClick={() => handleCopyMarketingCopy(marketingReport)}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" /> Copy Text
                  </button>
                </div>

                <div className="prose prose-invert max-w-none text-xs leading-relaxed font-sans whitespace-pre-wrap">
                  {marketingReport}
                </div>
              </div>
            )}
          </div>
        </div>
      )}


      {/* ========================================================================= */}
      {/* SUB-TAB 5: AI APPROVALS QUEUE                                             */}
      {/* ========================================================================= */}
      {activeSubTab === 'approvals' && (
        <div className="space-y-4">
          <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex items-center justify-between gap-4 shadow-xl">
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <span>AI Approvals Queue ({pendingApprovals.length})</span>
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Every AI suggestion requires store owner review before publishing live.
              </p>
            </div>
          </div>

          {pendingApprovals.length === 0 ? (
            <div className="py-16 text-center space-y-2 bg-zinc-900/50 border border-zinc-800 rounded-3xl">
              <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
              <h3 className="font-bold text-white text-sm">All AI Approvals Processed</h3>
              <p className="text-xs text-zinc-500">There are no pending AI proposals waiting for review.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingApprovals.map((app) => (
                <div key={app.id} className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-3">
                    <div>
                      <span className="text-[10px] font-bold text-purple-400 bg-purple-500/10 border border-purple-500/30 px-2.5 py-0.5 rounded-full uppercase">
                        {app.type}
                      </span>
                      <h3 className="font-extrabold text-white text-sm mt-1">{app.title}</h3>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleRejectProposal(app.id)}
                        className="px-3 py-1.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 font-bold rounded-xl text-xs cursor-pointer"
                      >
                        Reject
                      </button>
                      <button
                        onClick={() => handleApproveProposal(app.id)}
                        className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-lg"
                      >
                        <CheckCircle className="w-3.5 h-3.5" /> Approve & Execute
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-zinc-300 leading-relaxed">{app.description}</p>

                  {app.suggestedPlacement && (
                    <div className="flex items-center gap-2 text-[11px] text-zinc-400">
                      <span className="font-bold text-zinc-300">Suggested Placements:</span>
                      {app.suggestedPlacement.join(', ')}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}


      {/* ========================================================================= */}
      {/* SUB-TAB 6: AI KNOWLEDGE BASE (VECTOR RAG)                                 */}
      {/* ========================================================================= */}
      {activeSubTab === 'knowledge' && (
        <div className="space-y-6">
          <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-400" />
                <span>AI Customer Concierge Knowledge Base (Vector RAG)</span>
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Train the customer AI assistant with custom store policies, 1-year warranties, and Zagazig courier protocols.
              </p>
            </div>

            <button
              onClick={() => setShowDocModal(true)}
              className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>+ Index Knowledge Document</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {aiDocs.map((doc) => (
              <div key={doc.id} className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-2xl space-y-3 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-purple-400 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">
                      {doc.category}
                    </span>
                    <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-semibold">
                      <CheckCircle className="w-3 h-3" /> Indexed
                    </span>
                  </div>
                  <h3 className="font-extrabold text-white text-sm line-clamp-1">{doc.title}</h3>
                  <p className="text-xs text-zinc-400 line-clamp-3 leading-relaxed">{doc.content}</p>
                </div>

                <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-[10px] text-zinc-500 font-mono">
                  <span>{doc.size} &bull; {new Date(doc.uploadedAt).toLocaleDateString()}</span>
                  <button
                    onClick={() => handleDeleteDoc(doc.id)}
                    className="p-1.5 bg-rose-950/50 hover:bg-rose-900 text-rose-300 rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Modal */}
          {showDocModal && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
              <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-lg w-full p-6 text-white space-y-4 shadow-2xl">
                <h3 className="font-extrabold text-base">Add AI Knowledge Document</h3>

                <form onSubmit={handleSaveDoc} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Document Title</label>
                    <input
                      type="text"
                      required
                      value={docTitle}
                      onChange={(e) => setDocTitle(e.target.value)}
                      placeholder="e.g. Return & Exchange Policy 2026"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Category</label>
                    <select
                      value={docCategory}
                      onChange={(e) => setDocCategory(e.target.value as AIDocument['category'])}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                    >
                      <option value="Warranty">Warranty & Hardware Policy</option>
                      <option value="Policy">Store & Courier Policies</option>
                      <option value="Manual">Micro-Repair Technical Manuals</option>
                      <option value="FAQ">FAQ & Payments (Valu / InstaPay)</option>
                      <option value="Inventory">Inventory Specs</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Document Text / Policy Details</label>
                    <textarea
                      required
                      rows={5}
                      value={docContent}
                      onChange={(e) => setDocContent(e.target.value)}
                      placeholder="Type or paste policy details that the customer AI assistant should reference when answering customer queries..."
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button type="button" onClick={() => setShowDocModal(false)} className="px-4 py-2 bg-zinc-800 text-white rounded-xl cursor-pointer">
                      Cancel
                    </button>
                    <button type="submit" className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl cursor-pointer">
                      Index Document
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
