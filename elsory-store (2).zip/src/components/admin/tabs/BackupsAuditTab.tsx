import React, { useState } from 'react';
import { Database, Download, Upload, Activity, RefreshCw, CheckCircle2, AlertCircle } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { AuditLog } from '../../../types';

export const BackupsAuditTab: React.FC = () => {
  const [logs] = useState<AuditLog[]>(adminStore.getAuditLogs());
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleExportBackup = () => {
    const jsonStr = adminStore.exportFullBackupJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ElSory_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = adminStore.importFullBackupJSON(content);
      if (success) {
        setImportStatus('success');
      } else {
        setImportStatus('error');
      }
      setTimeout(() => setImportStatus('idle'), 3000);
    };
    reader.readAsText(file);
  };

  const handleResetFactoryDefault = () => {
    if (window.confirm('Are you sure you want to reset all store data to factory defaults?')) {
      adminStore.resetToDefault();
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Backup & Restore Panel */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl space-y-4 shadow-xl">
        <h3 className="font-extrabold text-white text-base flex items-center gap-2">
          <Database className="w-5 h-5 text-emerald-400" />
          <span>Full Store Data Backup & System Restore</span>
        </h3>
        <p className="text-xs text-zinc-400">
          Export or import complete JSON database snapshots including products, categories, orders, blog posts, customers, and AI knowledge documents.
        </p>

        {importStatus === 'success' && (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Database backup restored successfully!</span>
          </div>
        )}

        {importStatus === 'error' && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            <span>Failed to import JSON backup. Verify JSON structure.</span>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleExportBackup}
            className="px-4 py-2.5 bg-white text-black hover:bg-zinc-200 font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow-md"
          >
            <Download className="w-4 h-4 text-black" />
            <span>Export Full JSON Backup</span>
          </button>

          <label className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow-md">
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>Import JSON Backup</span>
            <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
          </label>

          <button
            onClick={handleResetFactoryDefault}
            className="px-4 py-2.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer ml-auto"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Reset to Factory Demo Default</span>
          </button>
        </div>
      </div>

      {/* System Audit Logs */}
      <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
            <Activity className="w-4 h-4 text-indigo-400" />
            <span>Enterprise System Audit Trail & Security Logs</span>
          </h3>
          <span className="text-[10px] text-zinc-500 font-mono">{logs.length} Recorded Security Events</span>
        </div>

        <div className="divide-y divide-zinc-800/80 max-h-96 overflow-y-auto">
          {logs.map((log) => (
            <div key={log.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-white">{log.action}</span>
                  <span className="text-[10px] bg-zinc-800 text-zinc-400 font-bold px-2 py-0.5 rounded">
                    {log.module}
                  </span>
                </div>
                <div className="text-zinc-400">{log.details}</div>
              </div>

              <div className="text-[10px] text-zinc-500 font-mono text-right shrink-0">
                <div>{log.userName} ({log.userRole})</div>
                <div>{new Date(log.timestamp).toLocaleString()} &bull; IP: {log.ipAddress}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
