import React, { useState } from 'react';
import { BookOpen, Plus, Trash2, Edit3, CheckCircle2, Search } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { BlogPost } from '../../../types';

export const BlogCMSTab: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>(adminStore.getBlogPosts());
  const [showModal, setShowModal] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);

  // Form state
  const [title, setTitle] = useState('');
  const [titleArabic, setTitleArabic] = useState('');
  const [slug, setSlug] = useState('');
  const [author, setAuthor] = useState('Ammar ElSory');
  const [category, setCategory] = useState('Hardware & Reviews');
  const [tags, setTags] = useState('Apple, Samsung, Zagazig');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [published, setPublished] = useState(true);

  const refreshPosts = () => {
    setPosts([...adminStore.getBlogPosts()]);
  };

  const handleOpenNewModal = () => {
    setEditingPost(null);
    setTitle('');
    setTitleArabic('');
    setSlug('');
    setAuthor('Ammar ElSory');
    setCategory('Hardware & Reviews');
    setTags('Apple, OLED, Zagazig');
    setExcerpt('');
    setContent('');
    setImageUrl('https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80');
    setPublished(true);
    setShowModal(true);
  };

  const handleOpenEditModal = (p: BlogPost) => {
    setEditingPost(p);
    setTitle(p.title);
    setTitleArabic(p.titleArabic || '');
    setSlug(p.slug);
    setAuthor(p.author);
    setCategory(p.category);
    setTags(p.tags.join(', '));
    setExcerpt(p.excerpt);
    setContent(p.content);
    setImageUrl(p.imageUrl);
    setPublished(p.published);
    setShowModal(true);
  };

  const handleSavePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const postToSave: BlogPost = {
      id: editingPost?.id || `post-${Date.now()}`,
      title,
      titleArabic: titleArabic || undefined,
      slug: slug || title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      author,
      category,
      tags: tags.split(',').map((t) => t.trim()),
      excerpt,
      content,
      imageUrl: imageUrl || 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80',
      publishedAt: editingPost?.publishedAt || new Date().toISOString(),
      published,
    };

    adminStore.saveBlogPost(postToSave);
    refreshPosts();
    setShowModal(false);
  };

  const handleDeletePost = (id: string) => {
    if (window.confirm('Delete article?')) {
      adminStore.deleteBlogPost(id);
      refreshPosts();
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Header */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            <span>Blog & Hardware News CMS</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Publish flagship comparisons, OLED repair guides, and store announcements.
          </p>
        </div>

        <button
          onClick={handleOpenNewModal}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ Create Article</span>
        </button>
      </div>

      {/* Posts List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {posts.map((p) => (
          <div key={p.id} className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-2xl space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <img src={p.imageUrl} alt={p.title} className="w-full h-36 object-cover rounded-xl border border-zinc-800" />
              <div className="text-[10px] text-indigo-400 font-mono font-bold uppercase">{p.category} &bull; {p.author}</div>
              <h3 className="font-extrabold text-white text-sm line-clamp-2">{p.title}</h3>
              {p.titleArabic && <p className="text-xs text-emerald-400 font-arabic font-bold line-clamp-1">{p.titleArabic}</p>}
              <p className="text-xs text-zinc-400 line-clamp-2">{p.excerpt}</p>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-zinc-800 text-xs">
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                p.published ? 'bg-emerald-500/10 text-emerald-400' : 'bg-zinc-800 text-zinc-400'
              }`}>
                {p.published ? 'Published' : 'Draft'}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenEditModal(p)}
                  className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDeletePost(p.id)}
                  className="p-1.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded-lg cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Post Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-xl w-full p-6 text-white space-y-4 shadow-2xl">
            <h3 className="font-extrabold text-base">
              {editingPost ? 'Edit Article' : 'Create New Article'}
            </h3>

            <form onSubmit={handleSavePostSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 font-bold mb-1">Title (English)</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Title (Arabic)</label>
                <input
                  type="text"
                  value={titleArabic}
                  onChange={(e) => setTitleArabic(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white font-arabic"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Author</label>
                  <input
                    type="text"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Category</label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Featured Image URL</label>
                <input
                  type="text"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Short Excerpt</label>
                <textarea
                  value={excerpt}
                  onChange={(e) => setExcerpt(e.target.value)}
                  rows={2}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Article Body Content</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={4}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 bg-zinc-800 text-white rounded-xl">
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2 bg-indigo-600 text-white font-bold rounded-xl">
                  Save Article
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
