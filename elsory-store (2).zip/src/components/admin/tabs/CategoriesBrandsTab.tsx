import React, { useState } from 'react';
import { Tag, Award, Plus, Trash2, Edit2, Check, Smartphone, Tablet, Watch, Headphones, BatteryCharging, Crown, Wrench } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { CategoryCMS, BrandCMS } from '../../../types';

export const CategoriesBrandsTab: React.FC = () => {
  const [categories, setCategories] = useState<CategoryCMS[]>(adminStore.getCategories());
  const [brands, setBrands] = useState<BrandCMS[]>(adminStore.getBrands());

  // Category modal states
  const [catName, setCatName] = useState('');
  const [catNameArabic, setCatNameArabic] = useState('');
  const [catDesc, setCatDesc] = useState('');
  const [showCatModal, setShowCatModal] = useState(false);

  // Brand modal states
  const [brandName, setBrandName] = useState('');
  const [brandLogo, setBrandLogo] = useState('');
  const [brandDesc, setBrandDesc] = useState('');
  const [showBrandModal, setShowBrandModal] = useState(false);

  const refreshData = () => {
    setCategories([...adminStore.getCategories()]);
    setBrands([...adminStore.getBrands()]);
  };

  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim()) return;
    const newCat: CategoryCMS = {
      id: `cat-${Date.now()}`,
      name: catName,
      nameArabic: catNameArabic || undefined,
      description: catDesc,
      iconName: 'Smartphone',
      order: categories.length + 1,
      active: true,
    };
    adminStore.saveCategory(newCat);
    refreshData();
    setShowCatModal(false);
    setCatName('');
    setCatNameArabic('');
    setCatDesc('');
  };

  const handleDeleteCategory = (id: string) => {
    if (window.confirm('Delete category?')) {
      adminStore.deleteCategory(id);
      refreshData();
    }
  };

  const handleSaveBrand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandName.trim()) return;
    const newBrand: BrandCMS = {
      id: `b-${Date.now()}`,
      name: brandName,
      logoUrl: brandLogo || 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=100&auto=format&fit=crop&q=80',
      description: brandDesc,
      featured: true,
      active: true,
    };
    adminStore.saveBrand(newBrand);
    refreshData();
    setShowBrandModal(false);
    setBrandName('');
    setBrandLogo('');
    setBrandDesc('');
  };

  const handleDeleteBrand = (id: string) => {
    if (window.confirm('Delete brand?')) {
      adminStore.deleteBrand(id);
      refreshData();
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Categories CMS Section */}
      <div className="space-y-4">
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-between">
          <div>
            <h3 className="font-black text-white text-base flex items-center gap-2">
              <Tag className="w-5 h-5 text-emerald-400" />
              <span>Category Hierarchy & Arabic Labels</span>
            </h3>
            <p className="text-xs text-zinc-400">
              Manage product categories, Arabic display translations, order, and icons.
            </p>
          </div>
          <button
            onClick={() => setShowCatModal(true)}
            className="px-3.5 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Category</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {categories.map((c) => (
            <div key={c.id} className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-2xl flex items-start justify-between">
              <div>
                <div className="font-extrabold text-white text-sm">{c.name}</div>
                {c.nameArabic && <div className="text-xs text-emerald-400 font-arabic font-bold">{c.nameArabic}</div>}
                <div className="text-[11px] text-zinc-400 mt-1">{c.description}</div>
              </div>
              <button
                onClick={() => handleDeleteCategory(c.id)}
                className="p-1.5 bg-rose-950/50 hover:bg-rose-900 text-rose-300 rounded-lg cursor-pointer shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Brands CMS Section */}
      <div className="space-y-4">
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-between">
          <div>
            <h3 className="font-black text-white text-base flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-400" />
              <span>Brand Partners & Official Manufacturers</span>
            </h3>
            <p className="text-xs text-zinc-400">
              Manage authorized brand logos, warranties, and featured partner badges.
            </p>
          </div>
          <button
            onClick={() => setShowBrandModal(true)}
            className="px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Brand</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {brands.map((b) => (
            <div key={b.id} className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-2xl flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <img src={b.logoUrl} alt={b.name} className="w-10 h-10 object-cover rounded-xl bg-zinc-950 p-1 border border-zinc-800 shrink-0" />
                <div>
                  <div className="font-extrabold text-white text-sm">{b.name}</div>
                  <div className="text-[11px] text-zinc-400 line-clamp-1">{b.description}</div>
                </div>
              </div>
              <button
                onClick={() => handleDeleteBrand(b.id)}
                className="p-1.5 bg-rose-950/50 hover:bg-rose-900 text-rose-300 rounded-lg cursor-pointer shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Add Category Modal */}
      {showCatModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl max-w-md w-full p-6 text-white space-y-4">
            <h3 className="font-extrabold text-base">Add New Category</h3>
            <form onSubmit={handleSaveCategory} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 mb-1 font-bold">Category Name (English)</label>
                <input
                  type="text"
                  required
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1 font-bold">Category Name (Arabic)</label>
                <input
                  type="text"
                  value={catNameArabic}
                  onChange={(e) => setCatNameArabic(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white font-arabic"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1 font-bold">Description</label>
                <input
                  type="text"
                  value={catDesc}
                  onChange={(e) => setCatDesc(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowCatModal(false)} className="px-3 py-2 bg-zinc-800 rounded-xl">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-white text-black font-bold rounded-xl">
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Brand Modal */}
      {showBrandModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl max-w-md w-full p-6 text-white space-y-4">
            <h3 className="font-extrabold text-base">Add New Brand Partner</h3>
            <form onSubmit={handleSaveBrand} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 mb-1 font-bold">Brand Name</label>
                <input
                  type="text"
                  required
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1 font-bold">Logo Image URL</label>
                <input
                  type="text"
                  value={brandLogo}
                  onChange={(e) => setBrandLogo(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1 font-bold">Description</label>
                <input
                  type="text"
                  value={brandDesc}
                  onChange={(e) => setBrandDesc(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowBrandModal(false)} className="px-3 py-2 bg-zinc-800 rounded-xl">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-purple-600 text-white font-bold rounded-xl">
                  Save Brand
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
