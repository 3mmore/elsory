import React, { useState } from 'react';
import { Users, Search, ShieldAlert, Heart, ShoppingBag, Wrench, CheckCircle } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { Customer, Currency } from '../../../types';
import { formatPrice } from '../../../data/currencies';

interface CustomersTabProps {
  currentCurrency: Currency;
}

export const CustomersTab: React.FC<CustomersTabProps> = ({ currentCurrency }) => {
  const [customers, setCustomers] = useState<Customer[]>(adminStore.getCustomers());
  const [searchQuery, setSearchQuery] = useState('');

  const refreshCustomers = () => {
    setCustomers([...adminStore.getCustomers()]);
  };

  const handleToggleBlock = (id: string) => {
    adminStore.toggleBlockCustomer(id);
    refreshCustomers();
  };

  const filteredCustomers = customers.filter((c) =>
    c.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery) ||
    c.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Header */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-400" />
            <span>Customer Relationship Management (CRM)</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Customer lifetime value tracking, order histories, repair tickets & account access controls.
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search customer name, phone, email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white outline-none"
          />
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950 text-zinc-400 font-bold border-b border-zinc-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3.5">Customer Name & Contact</th>
                <th className="p-3.5">City & Primary Address</th>
                <th className="p-3.5">Total Lifetime Spend</th>
                <th className="p-3.5">Orders / Repairs</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-zinc-500">
                    No customers found matching search.
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((c) => (
                  <tr key={c.id} className="hover:bg-zinc-800/40 transition-colors">
                    <td className="p-3.5">
                      <div className="font-extrabold text-white text-xs">{c.fullName}</div>
                      <div className="text-[10px] text-zinc-400">{c.email}</div>
                      <div className="text-[10px] text-emerald-400 font-mono">{c.phone}</div>
                    </td>

                    <td className="p-3.5">
                      <div className="font-bold text-white">{c.city}</div>
                      <div className="text-[10px] text-zinc-400 line-clamp-1">{c.address}</div>
                    </td>

                    <td className="p-3.5 font-extrabold text-white text-sm">
                      {formatPrice(c.totalSpendUSD, currentCurrency)}
                    </td>

                    <td className="p-3.5">
                      <div className="flex items-center gap-3 text-[11px]">
                        <span className="flex items-center gap-1 text-blue-400 font-bold">
                          <ShoppingBag className="w-3.5 h-3.5" /> {c.ordersCount} Orders
                        </span>
                        <span className="flex items-center gap-1 text-purple-400 font-bold">
                          <Wrench className="w-3.5 h-3.5" /> {c.repairCount} Repairs
                        </span>
                      </div>
                    </td>

                    <td className="p-3.5">
                      <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                        c.isBlocked ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      }`}>
                        {c.isBlocked ? 'Blocked Account' : 'Active Account'}
                      </span>
                    </td>

                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => handleToggleBlock(c.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                          c.isBlocked ? 'bg-emerald-600 text-white hover:bg-emerald-500' : 'bg-rose-950/60 hover:bg-rose-900 text-rose-300'
                        }`}
                      >
                        {c.isBlocked ? 'Unblock Customer' : 'Block Access'}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
