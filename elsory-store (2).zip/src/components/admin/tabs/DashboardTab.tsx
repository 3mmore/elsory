import React from 'react';
import { 
  TrendingUp, 
  ShoppingBag, 
  Users, 
  DollarSign, 
  Sparkles, 
  AlertTriangle, 
  PackageCheck, 
  Wrench, 
  ArrowUpRight, 
  Activity,
  Brain,
  MessageSquare,
  ShieldCheck
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { Currency } from '../../../types';
import { formatPrice } from '../../../data/currencies';
import { adminStore } from '../../../lib/adminStore';

interface DashboardTabProps {
  currentCurrency: Currency;
  onNavigateTab: (tabKey: string) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ currentCurrency, onNavigateTab }) => {
  const products = adminStore.getProducts();
  const orders = adminStore.getOrders();
  const customers = adminStore.getCustomers();
  const repairs = adminStore.getRepairs();
  const auditLogs = adminStore.getAuditLogs().slice(0, 5);

  // Calculated Metrics
  const totalRevenueUSD = orders.reduce((sum, o) => sum + o.totalUSD, 0);
  const totalOrdersCount = orders.length;
  const lowStockProducts = products.filter((p) => !p.inStock || (p.stockQuantity && p.stockQuantity < 5));
  const activeRepairsCount = repairs.filter((r) => r.status !== 'Ready for Pickup').length;

  // Chart data
  const revenueChartData = [
    { day: 'Mon', revenue: 2400, orders: 4 },
    { day: 'Tue', revenue: 3800, orders: 6 },
    { day: 'Wed', revenue: 3100, orders: 5 },
    { day: 'Thu', revenue: 5200, orders: 9 },
    { day: 'Fri', revenue: 7800, orders: 14 },
    { day: 'Sat', revenue: 9400, orders: 18 },
    { day: 'Sun', revenue: 8200, orders: 15 },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Welcome & Quick Overview Banner */}
      <div className="p-5 bg-gradient-to-r from-zinc-900 via-zinc-950 to-zinc-900 border border-zinc-800 rounded-3xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Live Store Sync Operational
            </span>
            <span className="text-zinc-500 text-xs font-mono">Zagazig HQ</span>
          </div>
          <h2 className="text-2xl font-black text-white">
            ElSory Store Command Center
          </h2>
          <p className="text-xs text-zinc-400 max-w-xl">
            Real-time analytics, order fulfilment, hardware micro-repairs, and AI customer concierge tracking.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => onNavigateTab('products')}
            className="px-3.5 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded-xl transition-all cursor-pointer shadow-md"
          >
            + Add New Product
          </button>
          <button
            onClick={() => onNavigateTab('marketing')}
            className="px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-md flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Marketing Suite</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid Widgets */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        {/* Widget 1: Revenue */}
        <div className="bg-zinc-900/90 border border-zinc-800 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span className="font-bold">Total Sales Revenue</span>
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">
            {formatPrice(totalRevenueUSD, currentCurrency)}
          </div>
          <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>+18.4% vs last week</span>
          </div>
        </div>

        {/* Widget 2: Orders */}
        <div className="bg-zinc-900/90 border border-zinc-800 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span className="font-bold">Total Orders</span>
            <div className="p-2 bg-blue-500/10 text-blue-400 rounded-xl">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">
            {totalOrdersCount} Orders
          </div>
          <div className="text-[11px] text-zinc-400 font-semibold">
            100% Express Delivery
          </div>
        </div>

        {/* Widget 3: Active Customers */}
        <div className="bg-zinc-900/90 border border-zinc-800 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span className="font-bold">Registered CRM Customers</span>
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">
            {customers.length} Accounts
          </div>
          <div className="text-[11px] text-amber-400 font-bold">
            Zagazig & Cairo Region
          </div>
        </div>

        {/* Widget 4: Micro-Repairs */}
        <div className="bg-zinc-900/90 border border-zinc-800 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span className="font-bold">Active Repair Tickets</span>
            <div className="p-2 bg-purple-500/10 text-purple-400 rounded-xl">
              <Wrench className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">
            {activeRepairsCount} Devices
          </div>
          <div className="text-[11px] text-purple-300 font-bold">
            Zagazig Hardware Lab
          </div>
        </div>

      </div>

      {/* Revenue & Orders Chart Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div className="lg:col-span-2 bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-white text-base">Weekly Revenue Velocity</h3>
              <p className="text-xs text-zinc-400">Sales volume and customer orders timeline</p>
            </div>
            <span className="text-[11px] text-zinc-400 bg-zinc-800 px-2.5 py-1 rounded-lg font-mono">
              7-Day Window
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueChartData}>
                <XAxis dataKey="day" stroke="#71717a" fontSize={12} />
                <YAxis stroke="#71717a" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', color: '#fff', borderRadius: '12px' }} />
                <Area type="monotone" dataKey="revenue" stroke="#10b981" fill="#10b981" fillOpacity={0.2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Low Stock & Bestseller Radar */}
        <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>Low Stock Inventory Alerts</span>
              </h3>
              <button 
                onClick={() => onNavigateTab('products')}
                className="text-[11px] text-purple-400 hover:underline font-bold"
              >
                Manage
              </button>
            </div>

            <div className="space-y-2.5">
              {lowStockProducts.length === 0 ? (
                <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-zinc-400 text-center">
                  All catalog items are healthy in stock.
                </div>
              ) : (
                lowStockProducts.slice(0, 4).map((p) => (
                  <div key={p.id} className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <img src={p.image} alt={p.name} className="w-7 h-7 object-contain shrink-0" />
                      <div>
                        <div className="font-bold text-white line-clamp-1">{p.name}</div>
                        <div className="text-[10px] text-zinc-400">{p.brand} &bull; {p.category}</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-rose-400 bg-rose-500/10 border border-rose-500/30 px-2 py-0.5 rounded shrink-0">
                      {p.stockQuantity ? `${p.stockQuantity} Left` : 'Out of Stock'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="p-3 bg-purple-950/40 border border-purple-800/60 rounded-xl space-y-1">
            <div className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
              <Brain className="w-4 h-4 text-purple-400" />
              <span>AI Inventory Insight</span>
            </div>
            <p className="text-[11px] text-zinc-300">
              iPhone 16 Pro Max stock velocity is high in Zagazig. Reorder 10 units of 512GB Natural Titanium.
            </p>
          </div>
        </div>

      </div>

      {/* Audit Log Activity Feed */}
      <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-3">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            <h3 className="font-extrabold text-white text-sm">Recent System Audit & Activity Log</h3>
          </div>
          <button 
            onClick={() => onNavigateTab('backups')}
            className="text-xs font-bold text-zinc-400 hover:text-white"
          >
            View Full Audit Logs &rarr;
          </button>
        </div>

        <div className="divide-y divide-zinc-800/80">
          {auditLogs.map((log) => (
            <div key={log.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                <div>
                  <span className="font-extrabold text-white">{log.action}</span>
                  <span className="text-zinc-400 ml-2">&bull; {log.details}</span>
                </div>
              </div>
              <div className="text-[10px] text-zinc-500 font-mono shrink-0">
                {log.userName} ({log.userRole}) &bull; {new Date(log.timestamp).toLocaleTimeString()}
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
