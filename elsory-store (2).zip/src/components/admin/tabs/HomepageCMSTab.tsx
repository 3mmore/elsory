import React, { useState } from 'react';
import { Layout, Eye, EyeOff, ArrowUp, ArrowDown, Save, CheckCircle2 } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { HomepageSectionCMS } from '../../../types';

export const HomepageCMSTab: React.FC = () => {
  const [sections, setSections] = useState<HomepageSectionCMS[]>(adminStore.getCMSSections());
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleToggleEnable = (id: string) => {
    const updated = sections.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s));
    setSections(updated);
  };

  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const updated = [...sections];
    const temp = updated[index];
    updated[index] = updated[index - 1];
    updated[index - 1] = temp;
    setSections(updated);
  };

  const handleMoveDown = (index: number) => {
    if (index === sections.length - 1) return;
    const updated = [...sections];
    const temp = updated[index];
    updated[index] = updated[index + 1];
    updated[index + 1] = temp;
    setSections(updated);
  };

  const handleSaveSections = () => {
    adminStore.updateCMSSections(sections);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Header */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Layout className="w-5 h-5 text-emerald-400" />
            <span>Homepage Section Builder & CMS Layout</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Reorder homepage components, enable or hide sections, and customize live content blocks.
          </p>
        </div>

        <button
          onClick={handleSaveSections}
          className="px-5 py-2.5 bg-white text-black hover:bg-zinc-200 font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow-md shrink-0"
        >
          {savedSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Save className="w-4 h-4 text-black" />}
          <span>{savedSuccess ? 'Layout Saved!' : 'Save Homepage Layout'}</span>
        </button>
      </div>

      {/* Sections List */}
      <div className="space-y-2.5">
        {sections.map((sec, idx) => (
          <div
            key={sec.id}
            className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-4 ${
              sec.enabled
                ? 'bg-zinc-900/90 border-zinc-800 text-white'
                : 'bg-zinc-950/60 border-zinc-900 text-zinc-500 opacity-60'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="w-6 h-6 rounded-full bg-zinc-800 text-zinc-400 font-mono text-xs flex items-center justify-center font-bold">
                {idx + 1}
              </span>
              <div>
                <div className="font-extrabold text-sm text-white">{sec.title}</div>
                {sec.titleArabic && <div className="text-xs text-emerald-400 font-arabic">{sec.titleArabic}</div>}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleMoveUp(idx)}
                disabled={idx === 0}
                className="p-2 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 rounded-xl cursor-pointer text-zinc-300"
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => handleMoveDown(idx)}
                disabled={idx === sections.length - 1}
                className="p-2 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 rounded-xl cursor-pointer text-zinc-300"
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => handleToggleEnable(sec.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                  sec.enabled ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-zinc-800 text-zinc-400'
                }`}
              >
                {sec.enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{sec.enabled ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
