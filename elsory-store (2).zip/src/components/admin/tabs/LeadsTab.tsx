import React, { useState, useEffect } from 'react';
import { MessageSquare, Search, Phone, ExternalLink, Trash2, CheckCircle2, Clock, Sparkles } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { CustomerLead } from '../../../types';

export const LeadsTab: React.FC = () => {
  const [leads, setLeads] = useState<CustomerLead[]>(adminStore.getLeads());
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const unsub = adminStore.subscribe(() => {
      setLeads([...adminStore.getLeads()]);
    });
    return unsub;
  }, []);

  const handleStatusChange = (id: string, status: CustomerLead['status']) => {
    adminStore.updateLeadStatus(id, status);
  };

  const handleDeleteLead = (id: string) => {
    if (confirm('Are you sure you want to delete this customer lead entry?')) {
      adminStore.deleteLead(id);
    }
  };

  const filteredLeads = leads.filter(
    (l) =>
      l.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.phone.includes(searchQuery) ||
      l.messageSummary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.source.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatWhatsAppUrl = (lead: CustomerLead) => {
    // Clean phone number (strip spaces, dashes, plus signs for wa.me)
    let cleanPhone = lead.phone.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('01')) {
      cleanPhone = '20' + cleanPhone;
    }

    const draftMessage = `Hello ${lead.name}, this is ElSory Store (Zagazig). We received your inquiry regarding: "${lead.messageSummary}". How can we best assist you today?`;
    return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(draftMessage)}`;
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Header Banner */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <span>AI Customer Leads & Inquiries</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Real customer leads captured via AI Assistant, repair quotes, and store inquiries. Review and message via 1-click WhatsApp.
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search lead name, phone, request..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Leads Table */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950 text-zinc-400 font-bold border-b border-zinc-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3.5">Customer Name & Phone</th>
                <th className="p-3.5">Request / AI Conversation Summary</th>
                <th className="p-3.5">Source</th>
                <th className="p-3.5">Date & Time</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80">
              {filteredLeads.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-zinc-500">
                    No customer leads recorded yet.
                  </td>
                </tr>
              ) : (
                filteredLeads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-zinc-800/40 transition-colors">
                    <td className="p-3.5">
                      <div className="font-extrabold text-white text-xs">{lead.name || 'Anonymous User'}</div>
                      <div className="text-[11px] text-emerald-400 font-mono flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3" /> {lead.phone || 'No phone provided'}
                      </div>
                    </td>

                    <td className="p-3.5 max-w-xs md:max-w-md">
                      <p className="text-zinc-200 text-xs leading-relaxed line-clamp-3 bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800/60 font-sans">
                        "{lead.messageSummary}"
                      </p>
                    </td>

                    <td className="p-3.5 whitespace-nowrap">
                      <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-bold px-2.5 py-1 rounded-full inline-flex items-center gap-1">
                        <MessageSquare className="w-3 h-3" /> {lead.source}
                      </span>
                    </td>

                    <td className="p-3.5 text-[11px] text-zinc-400 whitespace-nowrap">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-zinc-500" />
                        {new Date(lead.timestamp).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </td>

                    <td className="p-3.5 whitespace-nowrap">
                      <select
                        value={lead.status}
                        onChange={(e) => handleStatusChange(lead.id, e.target.value as CustomerLead['status'])}
                        className={`text-[10px] font-extrabold rounded-lg px-2.5 py-1 border outline-none cursor-pointer ${
                          lead.status === 'New'
                            ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                            : lead.status === 'Contacted'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        }`}
                      >
                        <option value="New">New</option>
                        <option value="Contacted">Contacted</option>
                        <option value="Closed">Closed</option>
                      </select>
                    </td>

                    <td className="p-3.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        {lead.phone && (
                          <a
                            href={formatWhatsAppUrl(lead)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold px-3 py-1.5 rounded-xl inline-flex items-center gap-1.5 shadow transition-colors"
                          >
                            <span>Message on WhatsApp</span>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}

                        <button
                          onClick={() => handleDeleteLead(lead.id)}
                          className="p-1.5 text-zinc-500 hover:text-rose-400 transition-colors cursor-pointer"
                          title="Delete Lead"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
