import React, { useState } from 'react';
import { Tag, Sparkles, Plus, Trash2, Zap } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { Coupon, FlashSale } from '../../../types';

export const MarketingTab: React.FC = () => {
  const [coupons, setCoupons] = useState<Coupon[]>(adminStore.getCoupons());
  const [flashSales, setFlashSales] = useState<FlashSale[]>(adminStore.getFlashSales());

  const [code, setCode] = useState('');
  const [discountType, setDiscountType] = useState<'fixed' | 'percentage'>('fixed');
  const [discountValue, setDiscountValue] = useState(20);
  const [showCouponModal, setShowCouponModal] = useState(false);

  const refreshData = () => {
    setCoupons([...adminStore.getCoupons()]);
    setFlashSales([...adminStore.getFlashSales()]);
  };

  const handleSaveCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;

    const newCoupon: Coupon = {
      id: `c-${Date.now()}`,
      code: code.toUpperCase(),
      discountType,
      discountValue: Number(discountValue),
      minOrderUSD: 100,
      expiryDate: '2026-12-31',
      usageCount: 0,
      maxUsage: 500,
      active: true,
    };

    adminStore.saveCoupon(newCoupon);
    refreshData();
    setShowCouponModal(false);
    setCode('');
  };

  const handleDeleteCoupon = (id: string) => {
    adminStore.deleteCoupon(id);
    refreshData();
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Coupons Section */}
      <div className="space-y-4">
        <div className="p-5 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-white text-base flex items-center gap-2">
              <Tag className="w-5 h-5 text-emerald-400" />
              <span>Promo Coupons & Discount Codes</span>
            </h3>
            <p className="text-xs text-zinc-400">
              Create coupon codes with percentage or fixed USD discounts.
            </p>
          </div>
          <button
            onClick={() => setShowCouponModal(true)}
            className="px-4 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Coupon</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {coupons.map((c) => (
            <div key={c.id} className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-2xl flex items-center justify-between">
              <div>
                <div className="font-mono font-black text-emerald-400 text-base">{c.code}</div>
                <div className="text-xs text-white font-bold">
                  {c.discountType === 'percentage' ? `${c.discountValue}% OFF` : `$${c.discountValue} OFF`}
                </div>
                <div className="text-[10px] text-zinc-400">Uses: {c.usageCount} / {c.maxUsage}</div>
              </div>

              <button
                onClick={() => handleDeleteCoupon(c.id)}
                className="p-2 bg-rose-950/50 hover:bg-rose-900 text-rose-300 rounded-lg cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Flash Sales Section */}
      <div className="space-y-4">
        <div className="p-5 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-white text-base flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              <span>Zagazig Summer Flash Sales</span>
            </h3>
            <p className="text-xs text-zinc-400">
              Active limited-time discount campaigns with countdown timers.
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {flashSales.map((f) => (
            <div key={f.id} className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-2xl flex items-center justify-between">
              <div>
                <div className="font-black text-white text-sm">{f.title}</div>
                <div className="text-xs text-emerald-400 font-arabic">{f.titleArabic}</div>
                <div className="text-xs text-amber-400 font-bold mt-1">{f.discountPercent}% Instant Storewide Discount</div>
              </div>
              <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs font-bold px-3 py-1 rounded-xl">
                Active Campaign
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Add Coupon Modal */}
      {showCouponModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl max-w-md w-full p-6 text-white space-y-4">
            <h3 className="font-extrabold text-base">New Coupon Code</h3>
            <form onSubmit={handleSaveCoupon} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 font-bold mb-1">Coupon Code</label>
                <input
                  type="text"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="e.g. ZAGAZIG100"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white uppercase font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Discount Type</label>
                  <select
                    value={discountType}
                    onChange={(e) => setDiscountType(e.target.value as any)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="fixed">Fixed USD ($)</option>
                    <option value="percentage">Percentage (%)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Value</label>
                  <input
                    type="number"
                    required
                    value={discountValue}
                    onChange={(e) => setDiscountValue(Number(e.target.value))}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowCouponModal(false)} className="px-3 py-2 bg-zinc-800 rounded-xl">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-white text-black font-bold rounded-xl">
                  Save Coupon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
