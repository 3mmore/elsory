import React, { useState } from 'react';
import { Image as ImageIcon, Upload, Trash2, Check, Crop, Layers } from 'lucide-react';

export const MediaTab: React.FC = () => {
  const [mediaItems, setMediaItems] = useState<string[]>([
    'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1597740985671-2a8a3b80502e?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&auto=format&fit=crop&q=80',
  ]);

  const [newUrlInput, setNewUrlInput] = useState('');

  const handleAddMedia = () => {
    if (!newUrlInput.trim()) return;
    setMediaItems([newUrlInput.trim(), ...mediaItems]);
    setNewUrlInput('');
  };

  const handleDeleteMedia = (idx: number) => {
    setMediaItems(mediaItems.filter((_, i) => i !== idx));
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Bar */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-emerald-400" />
            <span>Central Media Asset Library</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Store product photographs, banner images, brand logos, and compressed assets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Paste image asset URL..."
            value={newUrlInput}
            onChange={(e) => setNewUrlInput(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white outline-none w-64"
          />
          <button
            onClick={handleAddMedia}
            className="px-4 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded-xl cursor-pointer shrink-0"
          >
            + Upload Asset
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {mediaItems.map((url, idx) => (
          <div key={idx} className="relative group bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden aspect-square">
            <img src={url} alt={`Media ${idx}`} className="w-full h-full object-cover" />
            
            <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity p-3 flex flex-col justify-between">
              <span className="text-[10px] text-zinc-300 font-mono truncate">{url}</span>
              <button
                onClick={() => handleDeleteMedia(idx)}
                className="p-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold self-end cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
