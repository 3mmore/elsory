import React, { useState } from 'react';
import { ShoppingBag, Search, Printer, Download, Eye, CheckCircle2, Clock, Truck, Package, XCircle } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { Order, Currency } from '../../../types';
import { formatPrice } from '../../../data/currencies';

interface OrdersTabProps {
  currentCurrency: Currency;
}

export const OrdersTab: React.FC<OrdersTabProps> = ({ currentCurrency }) => {
  const [orders, setOrders] = useState<Order[]>(adminStore.getOrders());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  
  // Selected Order for Printable Invoice Modal
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);

  const refreshOrders = () => {
    setOrders([...adminStore.getOrders()]);
  };

  const handleStatusChange = (orderId: string, newStatus: Order['status']) => {
    adminStore.updateOrderStatus(orderId, newStatus);
    refreshOrders();
  };

  const handleExportCSV = () => {
    const csvRows = [
      ['Order ID', 'Date', 'Customer', 'Phone', 'City', 'Total USD', 'Payment Method', 'Status'],
      ...orders.map((o) => [
        o.orderId,
        o.date,
        o.customerInfo.fullName,
        o.customerInfo.phone,
        o.customerInfo.city,
        o.totalUSD,
        o.paymentMethod,
        o.status,
      ]),
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ElSory_Orders_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredOrders = orders.filter((o) => {
    const matchesSearch = o.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          o.customerInfo.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          o.customerInfo.phone.includes(searchQuery);
    const matchesStatus = selectedStatus === 'All' || o.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Bar */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-blue-400" />
            <span>Order Fulfilment & Invoice Management</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Process incoming hardware orders, dispatch express couriers, and generate printable receipts.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer shrink-0"
        >
          <Download className="w-4 h-4 text-emerald-400" />
          <span>Export Orders CSV</span>
        </button>
      </div>

      {/* Search & Status Filter */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search Order ID, Customer Name, Phone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white outline-none"
          />
        </div>

        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white outline-none"
        >
          <option value="All">All Order Statuses</option>
          <option value="Pending">Pending</option>
          <option value="Confirmed">Confirmed</option>
          <option value="Processing">Processing</option>
          <option value="Out for Delivery">Out for Delivery</option>
          <option value="Delivered">Delivered</option>
          <option value="Cancelled">Cancelled</option>
        </select>
      </div>

      {/* Orders Table */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950 text-zinc-400 font-bold border-b border-zinc-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3.5">Order ID & Date</th>
                <th className="p-3.5">Customer Info</th>
                <th className="p-3.5">Purchased Items</th>
                <th className="p-3.5">Total & Payment</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Invoice & Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-zinc-500">
                    No orders matched your query.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((o) => (
                  <tr key={o.orderId} className="hover:bg-zinc-800/40 transition-colors">
                    <td className="p-3.5 font-mono">
                      <div className="font-extrabold text-white text-xs">{o.orderId}</div>
                      <div className="text-[10px] text-zinc-500">{new Date(o.date).toLocaleString()}</div>
                    </td>

                    <td className="p-3.5">
                      <div className="font-bold text-white">{o.customerInfo.fullName}</div>
                      <div className="text-[10px] text-zinc-400">{o.customerInfo.phone} &bull; {o.customerInfo.city}</div>
                    </td>

                    <td className="p-3.5">
                      <div className="space-y-1 max-w-xs">
                        {o.items.map((it, idx) => (
                          <div key={idx} className="text-[11px] text-zinc-300 line-clamp-1">
                            &bull; {it.product.name} ({it.selectedStorage || 'Standard'}) x{it.quantity}
                          </div>
                        ))}
                      </div>
                    </td>

                    <td className="p-3.5">
                      <div className="font-black text-white text-sm">
                        {formatPrice(o.totalUSD, currentCurrency)}
                      </div>
                      <div className="text-[10px] text-emerald-400 font-semibold">{o.paymentMethod}</div>
                    </td>

                    <td className="p-3.5">
                      <select
                        value={o.status}
                        onChange={(e) => handleStatusChange(o.orderId, e.target.value as Order['status'])}
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-lg outline-none cursor-pointer border ${
                          o.status === 'Delivered'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : o.status === 'Out for Delivery'
                            ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                            : o.status === 'Cancelled'
                            ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                        }`}
                      >
                        <option value="Pending">Pending</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Processing">Processing</option>
                        <option value="Out for Delivery">Out for Delivery</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>

                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => setInvoiceOrder(o)}
                        className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Print Receipt</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Printable Invoice Modal */}
      {invoiceOrder && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white text-black max-w-xl w-full p-8 rounded-3xl shadow-2xl space-y-6 font-sans relative overflow-hidden">
            
            {/* Top Action Bar */}
            <div className="flex items-center justify-between border-b pb-4 border-zinc-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-black text-white font-black text-xl rounded-xl flex items-center justify-center">
                  S
                </div>
                <div>
                  <h3 className="font-black text-lg leading-none">ELSORY STORE</h3>
                  <span className="text-[10px] text-zinc-500 font-mono">Zagazig HQ Official Receipt</span>
                </div>
              </div>

              <div className="flex items-center gap-2 print:hidden">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-black text-white hover:bg-zinc-800 font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setInvoiceOrder(null)}
                  className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>

            {/* Invoice Meta */}
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-zinc-400 uppercase tracking-wider text-[10px] font-bold block">Customer Details</span>
                <div className="font-extrabold text-sm">{invoiceOrder.customerInfo.fullName}</div>
                <div className="text-zinc-600">{invoiceOrder.customerInfo.phone}</div>
                <div className="text-zinc-600">{invoiceOrder.customerInfo.address}</div>
              </div>

              <div className="text-right">
                <span className="text-zinc-400 uppercase tracking-wider text-[10px] font-bold block">Invoice Ref</span>
                <div className="font-extrabold text-sm font-mono">{invoiceOrder.orderId}</div>
                <div className="text-zinc-600">{new Date(invoiceOrder.date).toLocaleDateString()}</div>
                <div className="text-emerald-700 font-bold mt-1">{invoiceOrder.paymentMethod}</div>
              </div>
            </div>

            {/* Order Items Table */}
            <table className="w-full text-left text-xs border-t border-b border-zinc-200 divide-y divide-zinc-200">
              <thead>
                <tr className="text-zinc-400 uppercase text-[10px] py-2">
                  <th className="py-2">Item</th>
                  <th className="py-2 text-center">Qty</th>
                  <th className="py-2 text-right">Price</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100">
                {invoiceOrder.items.map((it, idx) => (
                  <tr key={idx} className="py-2">
                    <td className="py-2 font-bold">{it.product.name} ({it.selectedStorage || 'Std'})</td>
                    <td className="py-2 text-center font-mono">{it.quantity}</td>
                    <td className="py-2 text-right font-extrabold">${it.priceUSD * it.quantity}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Total Summary */}
            <div className="flex justify-end text-xs">
              <div className="w-48 space-y-1">
                <div className="flex justify-between text-zinc-500">
                  <span>Subtotal:</span>
                  <span>${invoiceOrder.subtotalUSD}</span>
                </div>
                <div className="flex justify-between text-zinc-500">
                  <span>Shipping:</span>
                  <span>${invoiceOrder.shippingUSD}</span>
                </div>
                <div className="flex justify-between font-black text-sm text-black border-t pt-1 border-zinc-300">
                  <span>Total Amount:</span>
                  <span>{formatPrice(invoiceOrder.totalUSD, currentCurrency)}</span>
                </div>
              </div>
            </div>

            {/* Stamp Footer */}
            <div className="border-t pt-4 border-zinc-200 text-center text-[10px] text-zinc-400 space-y-1">
              <p className="font-bold text-zinc-700">ElSory Store &bull; Certified Hardware & Software 1-Year Warranty</p>
              <p>Villas El Gamea District, Zagazig, Sharqia Governorate &bull; +20 101 234 5678</p>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
