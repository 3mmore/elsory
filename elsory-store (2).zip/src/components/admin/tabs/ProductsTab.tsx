import React, { useState } from 'react';
import { 
  PlusCircle, 
  Search, 
  Edit3, 
  Trash2, 
  Copy, 
  Eye, 
  EyeOff, 
  Check, 
  X, 
  Upload, 
  Image as ImageIcon,
  DollarSign,
  Tag,
  Layers,
  Sparkles,
  ShieldCheck,
  Video,
  FileText,
  CheckCircle2
} from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { Product, Brand, Category, Currency } from '../../../types';
import { formatPrice } from '../../../data/currencies';
import { db, doc, setDoc } from '../../../lib/firebase';

interface ProductsTabProps {
  currentCurrency: Currency;
}

export const ProductsTab: React.FC<ProductsTabProps> = ({ currentCurrency }) => {
  const [products, setProducts] = useState<Product[]>(adminStore.getProducts());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  
  // Modal State
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  
  // Form Input States for Modal
  const [name, setName] = useState('');
  const [nameArabic, setNameArabic] = useState('');
  const [brand, setBrand] = useState<Brand>('Apple');
  const [category, setCategory] = useState<Category>('Smartphones');
  const [model, setModel] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState('');
  const [priceUSD, setPriceUSD] = useState<number>(999);
  const [originalPriceUSD, setOriginalPriceUSD] = useState<number | undefined>(undefined);
  const [hidePrice, setHidePrice] = useState(false);
  const [stockQuantity, setStockQuantity] = useState<number>(10);
  const [inStock, setInStock] = useState(true);
  const [published, setPublished] = useState(true);
  const [description, setDescription] = useState('');
  const [mainImage, setMainImage] = useState('');
  const [galleryImages, setGalleryImages] = useState<string[]>([]);
  const [newGalleryInput, setNewGalleryInput] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [warrantyYears, setWarrantyYears] = useState<number>(1);
  const [isFeatured, setIsFeatured] = useState(false);
  const [isNewArrival, setIsNewArrival] = useState(false);
  const [isBestseller, setIsBestseller] = useState(false);
  const [seoTitle, setSeoTitle] = useState('');
  const [seoDescription, setSeoDescription] = useState('');

  // Variants state
  const [colors, setColors] = useState<{ name: string; hex: string }[]>([{ name: 'Default', hex: '#18181b' }]);
  const [colorNameInput, setColorNameInput] = useState('');
  const [colorHexInput, setColorHexInput] = useState('#3f3f46');

  const [storageOptions, setStorageOptions] = useState<{ size: string; priceUSD: number }[]>([
    { size: '256GB', priceUSD: 999 },
    { size: '512GB', priceUSD: 1199 },
  ]);
  const [storageSizeInput, setStorageSizeInput] = useState('');
  const [storagePriceInput, setStoragePriceInput] = useState<number>(1199);

  const refreshProducts = () => {
    setProducts([...adminStore.getProducts()]);
  };

  const handleOpenAddModal = () => {
    setEditingProduct(null);
    setName('');
    setNameArabic('');
    setBrand('Apple');
    setCategory('Smartphones');
    setModel('');
    setSku(`SKU-${Math.floor(100000 + Math.random() * 900000)}`);
    setBarcode(`690${Math.floor(1000000000 + Math.random() * 9000000000)}`);
    setPriceUSD(999);
    setOriginalPriceUSD(undefined);
    setHidePrice(false);
    setStockQuantity(10);
    setInStock(true);
    setPublished(true);
    setDescription('Flagship luxury smartphone officially imported with 1-Year ElSory Warranty.');
    setMainImage('https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80');
    setGalleryImages(['https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80']);
    setVideoUrl('');
    setWarrantyYears(1);
    setIsFeatured(true);
    setIsNewArrival(true);
    setIsBestseller(false);
    setSeoTitle('');
    setSeoDescription('');
    setColors([{ name: 'Natural Titanium', hex: '#a8a29e' }, { name: 'Black Titanium', hex: '#1c1917' }]);
    setStorageOptions([
      { size: '256GB', priceUSD: 1199 },
      { size: '512GB', priceUSD: 1399 }
    ]);
    setShowModal(true);
  };

  const handleOpenEditModal = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setNameArabic(p.nameArabic || '');
    setBrand(p.brand);
    setCategory(p.category);
    setModel(p.model || '');
    setSku(p.sku || `SKU-${p.id}`);
    setBarcode(p.barcode || '');
    setPriceUSD(p.priceUSD);
    setOriginalPriceUSD(p.originalPriceUSD);
    setHidePrice(!!p.hidePrice);
    setStockQuantity(p.stockQuantity ?? 10);
    setInStock(p.inStock);
    setPublished(p.published !== false);
    setDescription(p.description);
    setMainImage(p.image);
    setGalleryImages(p.gallery || [p.image]);
    setVideoUrl(p.videoUrl || '');
    setWarrantyYears(p.warrantyYears);
    setIsFeatured(!!p.isFeatured);
    setIsNewArrival(!!p.isNewArrival);
    setIsBestseller(!!p.isBestseller);
    setSeoTitle(p.seoTitle || '');
    setSeoDescription(p.seoDescription || '');
    setColors(p.colors || [{ name: 'Default', hex: '#18181b' }]);
    setStorageOptions(p.storageOptions || []);
    setShowModal(true);
  };

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleSaveProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      triggerToast('Please enter a valid product name.');
      return;
    }

    const finalPrice = typeof priceUSD === 'number' && !isNaN(priceUSD) ? priceUSD : 999;
    const finalMainImage = mainImage.trim() || 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80';

    const productToSave: Product = {
      id: editingProduct?.id || `prod-${Date.now()}`,
      name: name.trim(),
      nameArabic: nameArabic.trim() || undefined,
      brand: brand || 'Apple',
      category: category || 'Smartphones',
      model: model.trim() || name.trim(),
      sku: sku.trim() || `SKU-${Date.now().toString().slice(-6)}`,
      barcode: barcode.trim() || undefined,
      priceUSD: finalPrice,
      originalPriceUSD: originalPriceUSD ? Number(originalPriceUSD) : undefined,
      hidePrice,
      stockQuantity: typeof stockQuantity === 'number' && !isNaN(stockQuantity) ? stockQuantity : 10,
      rating: editingProduct?.rating || 5.0,
      reviewsCount: editingProduct?.reviewsCount || 1,
      badge: isNewArrival ? 'New' : isBestseller ? 'Bestseller' : isFeatured ? 'Hot' : undefined,
      description: description.trim() || `${name.trim()} - Flagship hardware officially imported with 1-Year ElSory Warranty.`,
      features: editingProduct?.features || ['1-Year ElSory Warranty', 'Fast Charging', 'OLED Display'],
      image: finalMainImage,
      gallery: galleryImages.length > 0 ? galleryImages : [finalMainImage],
      videoUrl: videoUrl.trim() || undefined,
      colors: colors.length > 0 ? colors : [{ name: 'Default', hex: '#18181b' }],
      storageOptions: storageOptions.length > 0 ? storageOptions : undefined,
      specsDetail: editingProduct?.specsDetail || {
        display: '6.7-inch OLED 120Hz',
        chipset: 'High Performance SoC',
        mainCamera: '50MP Ultra-Clarity Camera',
        selfieCamera: '32MP HDR Camera',
        battery: '5000 mAh',
        charging: 'Fast Charging Supported',
        weight: '198g',
        network: '5G Dual SIM',
        os: 'Latest OS',
        waterResistance: 'IP68 Certified',
      },
      inStock,
      isFeatured,
      isNewArrival,
      isBestseller,
      published,
      warrantyYears: warrantyYears || 1,
      seoTitle: seoTitle.trim() || undefined,
      seoDescription: seoDescription.trim() || undefined,
    };

    // Save to local adminStore
    adminStore.saveProduct(productToSave);

    // Sync to Firestore
    try {
      await setDoc(doc(db, 'products', productToSave.id), productToSave);
      console.log('Successfully saved product to Firestore:', productToSave.id);
    } catch (err) {
      console.warn('Firestore sync notice:', err);
    }

    refreshProducts();
    setShowModal(false);
    triggerToast(`Success! Product "${productToSave.name}" added & published to live store!`);
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('Are you sure you want to delete this product from the store catalog?')) {
      adminStore.deleteProduct(id);
      refreshProducts();
    }
  };

  const handleDuplicateProduct = (id: string) => {
    adminStore.duplicateProduct(id);
    refreshProducts();
  };

  const handleAddGalleryImage = () => {
    if (!newGalleryInput.trim()) return;
    setGalleryImages([...galleryImages, newGalleryInput.trim()]);
    setNewGalleryInput('');
  };

  const handleRemoveGalleryImage = (idx: number) => {
    setGalleryImages(galleryImages.filter((_, i) => i !== idx));
  };

  const handleAddColor = () => {
    if (!colorNameInput.trim()) return;
    setColors([...colors, { name: colorNameInput.trim(), hex: colorHexInput }]);
    setColorNameInput('');
  };

  const handleAddStorage = () => {
    if (!storageSizeInput.trim()) return;
    setStorageOptions([...storageOptions, { size: storageSizeInput.trim(), priceUSD: Number(storagePriceInput) }]);
    setStorageSizeInput('');
  };

  // Filter products
  const filteredProducts = products.filter((p) => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (p.nameArabic && p.nameArabic.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          (p.sku && p.sku.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesBrand = selectedBrand === 'All' || p.brand === selectedBrand;
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesBrand && matchesCategory;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Toast Notification Banner */}
      {toastMsg && (
        <div className="p-4 bg-emerald-950/90 border border-emerald-500/50 rounded-2xl text-emerald-300 text-xs font-bold flex items-center justify-between shadow-xl animate-bounce">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
          <button onClick={() => setToastMsg(null)} className="p-1 text-emerald-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Header & Search Control Bar */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-400" />
            <span>Product Catalog & CMS Manager</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Manage product titles, Arabic translations, prices, hide-price flags, inventory, variants & gallery images.
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center gap-2 bg-white text-black hover:bg-zinc-200 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4 text-black" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Filter Options */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by product name, Arabic title, SKU..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl py-2 pl-9 pr-3 text-xs text-white outline-none"
          />
        </div>

        <div>
          <select
            value={selectedBrand}
            onChange={(e) => setSelectedBrand(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white outline-none"
          >
            <option value="All">All Brands</option>
            <option value="Apple">Apple</option>
            <option value="Samsung">Samsung</option>
            <option value="Xiaomi">Xiaomi</option>
            <option value="Google">Google</option>
            <option value="Nothing">Nothing</option>
            <option value="Anker">Anker</option>
          </select>
        </div>

        <div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white outline-none"
          >
            <option value="All">All Categories</option>
            <option value="Smartphones">Smartphones</option>
            <option value="Tablets">Tablets</option>
            <option value="Smartwatches">Smartwatches</option>
            <option value="Audio & Sound">Audio & Sound</option>
            <option value="Accessories">Accessories</option>
            <option value="Luxury Editions">Luxury Editions</option>
            <option value="Repair Services">Repair Services</option>
          </select>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950 text-zinc-400 font-bold border-b border-zinc-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3.5">Product</th>
                <th className="p-3.5">Brand & Category</th>
                <th className="p-3.5">Price (USD)</th>
                <th className="p-3.5">Stock</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-zinc-500">
                    No products matched your search or filter settings.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-zinc-800/40 transition-colors">
                    <td className="p-3.5 flex items-center gap-3">
                      <img src={p.image} alt={p.name} className="w-10 h-10 object-contain rounded-lg bg-zinc-950 border border-zinc-800 p-1 shrink-0" />
                      <div>
                        <div className="font-extrabold text-white text-xs">{p.name}</div>
                        {p.nameArabic && <div className="text-[10px] text-zinc-400 font-arabic">{p.nameArabic}</div>}
                        <div className="text-[10px] text-zinc-500 font-mono">SKU: {p.sku || p.id}</div>
                      </div>
                    </td>

                    <td className="p-3.5">
                      <div className="font-semibold text-white">{p.brand}</div>
                      <div className="text-[10px] text-zinc-400">{p.category}</div>
                    </td>

                    <td className="p-3.5">
                      {p.hidePrice ? (
                        <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded">
                          Contact for Price
                        </span>
                      ) : (
                        <div>
                          <span className="font-extrabold text-white">${p.priceUSD}</span>
                          {p.originalPriceUSD && (
                            <span className="text-[10px] text-zinc-500 line-through ml-1">${p.originalPriceUSD}</span>
                          )}
                        </div>
                      )}
                    </td>

                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        p.inStock ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/10 text-rose-400'
                      }`}>
                        {p.inStock ? `${p.stockQuantity ?? 10} In Stock` : 'Out of Stock'}
                      </span>
                    </td>

                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        p.published !== false ? 'bg-blue-500/10 text-blue-400' : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {p.published !== false ? 'Published' : 'Draft'}
                      </span>
                    </td>

                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenEditModal(p)}
                          className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg transition-colors cursor-pointer"
                          title="Edit Product"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDuplicateProduct(p.id)}
                          className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg transition-colors cursor-pointer"
                          title="Duplicate Product"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(p.id)}
                          className="p-1.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded-lg transition-colors cursor-pointer"
                          title="Delete Product"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Add / Edit Modal Drawer */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fadeIn">
          <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-3xl w-full max-h-[90vh] flex flex-col text-white shadow-2xl relative my-auto overflow-hidden">
            
            {/* Modal Top Bar */}
            <div className="p-5 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between shrink-0">
              <h3 className="font-extrabold text-base text-white">
                {editingProduct ? 'Edit Catalog Product' : 'Add New Product to ElSory Store'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 bg-zinc-800 hover:bg-zinc-700 rounded-full text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleSaveProductSubmit} className="flex-1 p-6 overflow-y-auto space-y-6 text-xs">
              
              {/* Section 1: Basic Information */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-emerald-400 uppercase tracking-wider text-[11px] border-b border-zinc-800 pb-1">
                  1. Product Identifiers & Localization
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">English Product Name</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. iPhone 16 Pro Max"
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl p-2.5 text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Arabic Product Name (اسم المنتج بالعربية)</label>
                    <input
                      type="text"
                      value={nameArabic}
                      onChange={(e) => setNameArabic(e.target.value)}
                      placeholder="مثال: آيفون 16 برو ماكس"
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl p-2.5 text-white outline-none font-arabic"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Brand</label>
                    <select
                      value={brand}
                      onChange={(e) => setBrand(e.target.value as Brand)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                    >
                      <option value="Apple">Apple</option>
                      <option value="Samsung">Samsung</option>
                      <option value="Xiaomi">Xiaomi</option>
                      <option value="Google">Google</option>
                      <option value="Nothing">Nothing</option>
                      <option value="Anker">Anker</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Category</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as Category)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                    >
                      <option value="Smartphones">Smartphones</option>
                      <option value="Tablets">Tablets</option>
                      <option value="Smartwatches">Smartwatches</option>
                      <option value="Audio & Sound">Audio & Sound</option>
                      <option value="Accessories">Accessories</option>
                      <option value="Luxury Editions">Luxury Editions</option>
                      <option value="Repair Services">Repair Services</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">SKU Code</label>
                    <input
                      type="text"
                      value={sku}
                      onChange={(e) => setSku(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Barcode / EAN</label>
                    <input
                      type="text"
                      value={barcode}
                      onChange={(e) => setBarcode(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Pricing & Hide Price Feature */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-emerald-400 uppercase tracking-wider text-[11px] border-b border-zinc-800 pb-1">
                  2. Pricing & Hide Price Display Option
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Base Price (USD)</label>
                    <input
                      type="number"
                      required
                      value={priceUSD}
                      onChange={(e) => setPriceUSD(Number(e.target.value))}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Original / Compare Price (USD)</label>
                    <input
                      type="number"
                      value={originalPriceUSD || ''}
                      onChange={(e) => setOriginalPriceUSD(e.target.value ? Number(e.target.value) : undefined)}
                      placeholder="Optional"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-bold mb-1">Stock Quantity</label>
                    <input
                      type="number"
                      value={stockQuantity}
                      onChange={(e) => setStockQuantity(Number(e.target.value))}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                    />
                  </div>
                </div>

                <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="font-extrabold text-white">Hide Price on Storefront ("Contact us for today's price")</span>
                    <p className="text-[11px] text-zinc-400">
                      When enabled, the website displays "Contact us for today's price" instead of the numerical price.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={hidePrice}
                    onChange={(e) => setHidePrice(e.target.checked)}
                    className="w-5 h-5 rounded border-zinc-700 bg-zinc-950 text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                </div>
              </div>

              {/* Section 3: Media & Unlimited Images */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-emerald-400 uppercase tracking-wider text-[11px] border-b border-zinc-800 pb-1">
                  3. Image Upload & Media Gallery
                </h4>

                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Main Cover Image URL</label>
                  <input
                    type="text"
                    required
                    value={mainImage}
                    onChange={(e) => setMainImage(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Gallery Images (Unlimited)</label>
                  <div className="flex items-center gap-2 mb-2">
                    <input
                      type="text"
                      placeholder="Paste image URL to add..."
                      value={newGalleryInput}
                      onChange={(e) => setNewGalleryInput(e.target.value)}
                      className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl p-2 text-white outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleAddGalleryImage}
                      className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 font-bold rounded-xl text-white"
                    >
                      + Add Image
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {galleryImages.map((img, idx) => (
                      <div key={idx} className="relative group w-14 h-14 bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden shrink-0">
                        <img src={img} alt="Gallery" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemoveGalleryImage(idx)}
                          className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-rose-400 font-bold"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Product Showcase Video URL (YouTube / MP4)</label>
                  <input
                    type="text"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    placeholder="https://www.youtube.com/watch?v=..."
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white outline-none"
                  />
                </div>
              </div>

              {/* Section 4: Variants & Status */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-emerald-400 uppercase tracking-wider text-[11px] border-b border-zinc-800 pb-1">
                  4. Colors, Storage Options & Visibility
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Colors */}
                  <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl space-y-2">
                    <span className="font-bold text-white block">Color Options</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Color Name"
                        value={colorNameInput}
                        onChange={(e) => setColorNameInput(e.target.value)}
                        className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg p-1.5 text-white"
                      />
                      <input
                        type="color"
                        value={colorHexInput}
                        onChange={(e) => setColorHexInput(e.target.value)}
                        className="w-8 h-8 rounded border-none bg-transparent cursor-pointer"
                      />
                      <button
                        type="button"
                        onClick={handleAddColor}
                        className="px-2.5 py-1 bg-zinc-800 text-white font-bold rounded-lg"
                      >
                        + Add
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {colors.map((c, i) => (
                        <span key={i} className="inline-flex items-center gap-1.5 bg-zinc-950 px-2 py-1 rounded border border-zinc-800 text-[10px]">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.hex }} />
                          <span>{c.name}</span>
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Storage Options */}
                  <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl space-y-2">
                    <span className="font-bold text-white block">Storage Capacities</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Size (e.g. 512GB)"
                        value={storageSizeInput}
                        onChange={(e) => setStorageSizeInput(e.target.value)}
                        className="w-24 bg-zinc-950 border border-zinc-800 rounded-lg p-1.5 text-white"
                      />
                      <input
                        type="number"
                        placeholder="USD Price"
                        value={storagePriceInput}
                        onChange={(e) => setStoragePriceInput(Number(e.target.value))}
                        className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg p-1.5 text-white"
                      />
                      <button
                        type="button"
                        onClick={handleAddStorage}
                        className="px-2.5 py-1 bg-zinc-800 text-white font-bold rounded-lg"
                      >
                        + Add
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {storageOptions.map((s, i) => (
                        <span key={i} className="inline-flex items-center gap-1 bg-zinc-950 px-2 py-1 rounded border border-zinc-800 text-[10px]">
                          <span className="font-bold text-white">{s.size}:</span>
                          <span className="text-emerald-400">${s.priceUSD}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                  <label className="flex items-center gap-2 p-2 bg-zinc-900 border border-zinc-800 rounded-xl cursor-pointer">
                    <input
                      type="checkbox"
                      checked={inStock}
                      onChange={(e) => setInStock(e.target.checked)}
                      className="rounded bg-zinc-950 border-zinc-700 text-emerald-500"
                    />
                    <span className="font-bold text-white">In Stock</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 bg-zinc-900 border border-zinc-800 rounded-xl cursor-pointer">
                    <input
                      type="checkbox"
                      checked={published}
                      onChange={(e) => setPublished(e.target.checked)}
                      className="rounded bg-zinc-950 border-zinc-700 text-emerald-500"
                    />
                    <span className="font-bold text-white">Published</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 bg-zinc-900 border border-zinc-800 rounded-xl cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isFeatured}
                      onChange={(e) => setIsFeatured(e.target.checked)}
                      className="rounded bg-zinc-950 border-zinc-700 text-emerald-500"
                    />
                    <span className="font-bold text-white">Featured</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 bg-zinc-900 border border-zinc-800 rounded-xl cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isNewArrival}
                      onChange={(e) => setIsNewArrival(e.target.checked)}
                      className="rounded bg-zinc-950 border-zinc-700 text-emerald-500"
                    />
                    <span className="font-bold text-white">New Arrival</span>
                  </label>
                </div>
              </div>

              {/* Modal Action Buttons */}
              <div className="pt-4 border-t border-zinc-800 flex items-center justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 bg-zinc-800 text-zinc-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-white text-black font-bold rounded-xl hover:bg-zinc-200"
                >
                  {editingProduct ? 'Save Changes' : 'Create Product'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
