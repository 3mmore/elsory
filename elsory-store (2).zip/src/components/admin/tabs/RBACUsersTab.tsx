import React, { useState } from 'react';
import { ShieldCheck, UserPlus, Trash2, Check, X, Lock } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { AdminUser, AdminRole, PermissionKey, RolePermissionMatrix } from '../../../types';

export const RBACUsersTab: React.FC = () => {
  const [users, setUsers] = useState<AdminUser[]>(adminStore.getAdminUsers());
  const [permissions, setPermissions] = useState<RolePermissionMatrix>(adminStore.getRolePermissions());
  
  const [showUserModal, setShowUserModal] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<AdminRole>('Sales');

  const refreshData = () => {
    setUsers([...adminStore.getAdminUsers()]);
    setPermissions({ ...adminStore.getRolePermissions() });
  };

  const handleTogglePermission = (r: AdminRole, permKey: PermissionKey) => {
    const updated = { ...permissions };
    if (!updated[r]) updated[r] = {} as any;
    updated[r][permKey] = !updated[r][permKey];
    setPermissions(updated);
    adminStore.updateRolePermissions(updated);
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    const newUser: AdminUser = {
      id: `user-${Date.now()}`,
      email,
      name,
      role,
      active: true,
      twoFactorEnabled: false,
      createdAt: new Date().toISOString(),
    };

    adminStore.saveAdminUser(newUser);
    refreshData();
    setShowUserModal(false);
    setEmail('');
    setName('');
  };

  const handleDeleteUser = (id: string) => {
    if (window.confirm('Remove admin user?')) {
      adminStore.deleteAdminUser(id);
      refreshData();
    }
  };

  const rolesList: AdminRole[] = [
    'Super Admin',
    'Admin',
    'Sales',
    'Marketing',
    'Inventory Manager',
    'Technician',
    'Customer Support',
  ];

  const permissionKeysList: { key: PermissionKey; label: string }[] = [
    { key: 'dashboard_read', label: 'View Dashboard' },
    { key: 'products_read', label: 'View Products' },
    { key: 'products_write', label: 'Edit Products' },
    { key: 'products_delete', label: 'Delete Products' },
    { key: 'categories_manage', label: 'Manage Categories' },
    { key: 'brands_manage', label: 'Manage Brands' },
    { key: 'orders_read', label: 'View Orders' },
    { key: 'orders_manage', label: 'Process Orders' },
    { key: 'customers_read', label: 'View CRM' },
    { key: 'customers_manage', label: 'Manage Customers' },
    { key: 'repairs_read', label: 'View Repairs' },
    { key: 'repairs_manage', label: 'Process Repairs' },
    { key: 'cms_manage', label: 'Homepage CMS' },
    { key: 'blog_manage', label: 'Blog CMS' },
    { key: 'marketing_manage', label: 'Marketing & Coupons' },
    { key: 'ai_manage', label: 'AI Knowledge Base' },
    { key: 'users_manage', label: 'Manage Admin Users' },
    { key: 'settings_manage', label: 'Website Settings' },
    { key: 'backups_manage', label: 'Backups & Audit Logs' },
  ];

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Users List Section */}
      <div className="space-y-4">
        <div className="p-5 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-white text-base flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Admin Users & Access Governance</span>
            </h3>
            <p className="text-xs text-zinc-400">
              Manage accounts for admins, sales team, technicians, and marketing leads.
            </p>
          </div>

          <button
            onClick={() => setShowUserModal(true)}
            className="px-4 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <UserPlus className="w-4 h-4 text-black" />
            <span>Add Admin Account</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {users.map((u) => (
            <div key={u.id} className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-2xl space-y-2 flex flex-col justify-between">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
                    {u.role}
                  </span>
                  {u.twoFactorEnabled && (
                    <span className="text-[10px] text-indigo-400 font-bold" title="2FA Enabled">
                      2FA Active
                    </span>
                  )}
                </div>
                <div className="font-extrabold text-white text-sm">{u.name}</div>
                <div className="text-xs text-zinc-400 font-mono line-clamp-1">{u.email}</div>
              </div>

              <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-[10px] text-zinc-500">
                <span>{u.lastLogin ? `Login: ${new Date(u.lastLogin).toLocaleDateString()}` : 'Never logged in'}</span>
                {u.role !== 'Super Admin' && (
                  <button
                    onClick={() => handleDeleteUser(u.id)}
                    className="p-1 bg-rose-950/50 hover:bg-rose-900 text-rose-300 rounded cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Role & Permissions Matrix */}
      <div className="space-y-4">
        <div className="p-5 bg-zinc-900 border border-zinc-800 rounded-2xl">
          <h3 className="font-extrabold text-white text-base flex items-center gap-2">
            <Lock className="w-5 h-5 text-indigo-400" />
            <span>Role-Based Access Control (RBAC) Permission Matrix</span>
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Customize granular access permissions across all administrative roles.
          </p>
        </div>

        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-zinc-300">
              <thead className="bg-zinc-950 text-zinc-400 font-bold border-b border-zinc-800 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Permission Module</th>
                  {rolesList.map((r) => (
                    <th key={r} className="p-3 text-center">{r}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/80">
                {permissionKeysList.map((p) => (
                  <tr key={p.key} className="hover:bg-zinc-800/40 transition-colors">
                    <td className="p-3 font-bold text-white">{p.label}</td>
                    {rolesList.map((r) => {
                      const isChecked = !!permissions[r]?.[p.key];
                      const isSuperAdmin = r === 'Super Admin';
                      return (
                        <td key={r} className="p-3 text-center">
                          <input
                            type="checkbox"
                            disabled={isSuperAdmin}
                            checked={isChecked}
                            onChange={() => handleTogglePermission(r, p.key)}
                            className="w-4 h-4 rounded border-zinc-700 bg-zinc-950 text-emerald-500 cursor-pointer disabled:opacity-50"
                          />
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add User Modal */}
      {showUserModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl max-w-md w-full p-6 text-white space-y-4">
            <h3 className="font-extrabold text-base">Create New Admin Account</h3>
            <form onSubmit={handleAddUser} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 font-bold mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Karim ElSory"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="staff@elsory.com"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Assigned Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as AdminRole)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                >
                  {rolesList.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowUserModal(false)} className="px-3 py-2 bg-zinc-800 rounded-xl">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-white text-black font-bold rounded-xl">
                  Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
