import React, { useState } from 'react';
import { Wrench, UserCheck, MessageSquare, Plus, Clock, CheckCircle2, AlertCircle, Edit3 } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { RepairBooking } from '../../../types';

export const RepairsTab: React.FC = () => {
  const [repairs, setRepairs] = useState<RepairBooking[]>(adminStore.getRepairs());
  const [showModal, setShowModal] = useState(false);
  const [editingRepair, setEditingRepair] = useState<RepairBooking | null>(null);

  // Form states
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [deviceBrand, setDeviceBrand] = useState('Apple');
  const [deviceModel, setDeviceModel] = useState('iPhone 15 Pro Max');
  const [issueType, setIssueType] = useState<RepairBooking['issueType']>('Screen & OLED');
  const [preferredDate, setPreferredDate] = useState('2026-07-28');
  const [estimatedCostEGP, setEstimatedCostEGP] = useState(3500);
  const [status, setStatus] = useState<RepairBooking['status']>('Diagnosing');
  const [assignedTechnician, setAssignedTechnician] = useState('Eng. Ahmed Hassan');
  const [notes, setNotes] = useState('');

  const refreshRepairs = () => {
    setRepairs([...adminStore.getRepairs()]);
  };

  const handleOpenNewModal = () => {
    setEditingRepair(null);
    setCustomerName('');
    setPhone('+20 100 ');
    setDeviceBrand('Apple');
    setDeviceModel('iPhone 16 Pro Max');
    setIssueType('Screen & OLED');
    setPreferredDate(new Date().toISOString().slice(0, 10));
    setEstimatedCostEGP(4500);
    setStatus('Diagnosing');
    setAssignedTechnician('Eng. Ahmed Hassan');
    setNotes('Transferred IC chip for OEM panel to retain TrueTone.');
    setShowModal(true);
  };

  const handleOpenEditModal = (r: RepairBooking) => {
    setEditingRepair(r);
    setCustomerName(r.customerName);
    setPhone(r.phone);
    setDeviceBrand(r.deviceBrand);
    setDeviceModel(r.deviceModel);
    setIssueType(r.issueType);
    setPreferredDate(r.preferredDate);
    setEstimatedCostEGP(r.estimatedCostEGP || 0);
    setStatus(r.status);
    setAssignedTechnician(r.assignedTechnician || 'Eng. Ahmed Hassan');
    setNotes(r.notes || '');
    setShowModal(true);
  };

  const handleSaveRepairSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) return;

    const repairToSave: RepairBooking = {
      id: editingRepair?.id || `REP-2026-${Math.floor(100 + Math.random() * 900)}`,
      customerName,
      phone,
      deviceBrand,
      deviceModel,
      issueType,
      preferredDate,
      estimatedCostEGP: Number(estimatedCostEGP),
      status,
      assignedTechnician,
      notes,
    };

    adminStore.saveRepair(repairToSave);
    refreshRepairs();
    setShowModal(false);
  };

  const handleSendWhatsAppNotification = (r: RepairBooking) => {
    const text = encodeURIComponent(
      `Hello ${r.customerName}, this is ElSory Store Repair Center in Zagazig.\nYour device (${r.deviceBrand} ${r.deviceModel}) status has been updated to: *${r.status}*.\nEstimated Repair Cost: ${r.estimatedCostEGP} EGP.\nFor inquiries reply to this chat.`
    );
    const cleanPhone = r.phone.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${cleanPhone}?text=${text}`, '_blank');
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Header Bar */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Wrench className="w-5 h-5 text-purple-400" />
            <span>Zagazig Express Micro-Repair Lab</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Hardware ticket management, certified master technicians, estimated cost calculators & WhatsApp client dispatches.
          </p>
        </div>

        <button
          onClick={handleOpenNewModal}
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs transition-all flex items-center gap-2 cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ Create Repair Ticket</span>
        </button>
      </div>

      {/* Repairs Table */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950 text-zinc-400 font-bold border-b border-zinc-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3.5">Ticket ID & Customer</th>
                <th className="p-3.5">Device & Issue Type</th>
                <th className="p-3.5">Assigned Technician</th>
                <th className="p-3.5">Cost (EGP)</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions & WhatsApp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80">
              {repairs.map((r) => (
                <tr key={r.id} className="hover:bg-zinc-800/40 transition-colors">
                  <td className="p-3.5">
                    <div className="font-extrabold text-white text-xs font-mono">{r.id}</div>
                    <div className="text-zinc-300 font-semibold">{r.customerName}</div>
                    <div className="text-[10px] text-emerald-400 font-mono">{r.phone}</div>
                  </td>

                  <td className="p-3.5">
                    <div className="font-bold text-white">{r.deviceBrand} {r.deviceModel}</div>
                    <div className="text-[10px] text-zinc-400">{r.issueType}</div>
                  </td>

                  <td className="p-3.5">
                    <div className="flex items-center gap-1.5 text-purple-300 font-bold">
                      <UserCheck className="w-3.5 h-3.5 text-purple-400" />
                      <span>{r.assignedTechnician || 'Eng. Ahmed Hassan'}</span>
                    </div>
                  </td>

                  <td className="p-3.5 font-black text-white text-sm">
                    {r.estimatedCostEGP ? `${r.estimatedCostEGP.toLocaleString()} ج.م` : 'TBD'}
                  </td>

                  <td className="p-3.5">
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border ${
                      r.status === 'Ready for Pickup'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : r.status === 'Repairing'
                        ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                        : r.status === 'Waiting for Parts'
                        ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                        : 'bg-purple-500/10 text-purple-400 border-purple-500/30'
                    }`}>
                      {r.status}
                    </span>
                  </td>

                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleSendWhatsAppNotification(r)}
                        className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                        title="Send WhatsApp update to client"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>WhatsApp</span>
                      </button>

                      <button
                        onClick={() => handleOpenEditModal(r)}
                        className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg cursor-pointer"
                        title="Edit Ticket"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Repair Ticket Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-lg w-full p-6 text-white space-y-4 shadow-2xl">
            <h3 className="font-extrabold text-base">
              {editingRepair ? `Edit Repair Ticket (${editingRepair.id})` : 'New Micro-Repair Ticket'}
            </h3>

            <form onSubmit={handleSaveRepairSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Customer Name</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Phone Number</label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Device Model</label>
                  <input
                    type="text"
                    required
                    value={deviceModel}
                    onChange={(e) => setDeviceModel(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Issue / Service Required</label>
                  <select
                    value={issueType}
                    onChange={(e) => setIssueType(e.target.value as RepairBooking['issueType'])}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="Screen & OLED">Screen & OLED</option>
                    <option value="Original Battery">Original Battery</option>
                    <option value="Back Glass Laser">Back Glass Laser</option>
                    <option value="Motherboard & Soldering">Motherboard & Soldering</option>
                    <option value="Water Damage">Water Damage</option>
                    <option value="Camera & Lens">Camera & Lens</option>
                    <option value="Charging Port">Charging Port</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Estimated Cost (EGP)</label>
                  <input
                    type="number"
                    value={estimatedCostEGP}
                    onChange={(e) => setEstimatedCostEGP(Number(e.target.value))}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 font-bold mb-1">Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as RepairBooking['status'])}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="Diagnosing">Diagnosing</option>
                    <option value="Waiting for Parts">Waiting for Parts</option>
                    <option value="Repairing">Repairing</option>
                    <option value="Testing & QA">Testing & QA</option>
                    <option value="Ready for Pickup">Ready for Pickup</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Assigned Master Technician</label>
                <select
                  value={assignedTechnician}
                  onChange={(e) => setAssignedTechnician(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                >
                  <option value="Eng. Ahmed Hassan">Eng. Ahmed Hassan (Micro-Soldering Expert)</option>
                  <option value="Hassan Mahmoud">Hassan Mahmoud (OLED Calibration Specialist)</option>
                  <option value="Karim ElSory">Karim ElSory (Hardware Lead)</option>
                </select>
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Internal Technician Notes</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-zinc-800 text-white rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl"
                >
                  Save Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
