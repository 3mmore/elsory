import React, { useState } from 'react';
import { Settings, Save, CheckCircle2, MapPin, Phone, Globe, CreditCard, DollarSign } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { WebsiteSettings } from '../../../types';

export const SettingsTab: React.FC = () => {
  const [settings, setSettings] = useState<WebsiteSettings>(adminStore.getSettings());
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    adminStore.updateSettings(settings);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Header */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-400" />
            <span>Storefront & Regional Settings</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Store identity, Zagazig branch address, contact numbers, currencies, taxes & payment gateways.
          </p>
        </div>

        <button
          onClick={handleSaveSettings}
          className="px-5 py-2.5 bg-white text-black hover:bg-zinc-200 font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow-md shrink-0"
        >
          {savedSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Save className="w-4 h-4 text-black" />}
          <span>{savedSuccess ? 'Settings Saved!' : 'Save All Settings'}</span>
        </button>
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6 text-xs">
        
        {/* Section 1: Store Branding */}
        <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-2xl space-y-4">
          <h3 className="font-extrabold text-emerald-400 uppercase tracking-wider text-[11px] border-b border-zinc-800 pb-1 flex items-center gap-2">
            <Globe className="w-4 h-4" />
            <span>1. General Store Identity & Logos</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-zinc-400 font-bold mb-1">Store Name (English)</label>
              <input
                type="text"
                value={settings.storeName}
                onChange={(e) => setSettings({ ...settings, storeName: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">Store Name (Arabic)</label>
              <input
                type="text"
                value={settings.storeNameArabic}
                onChange={(e) => setSettings({ ...settings, storeNameArabic: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white font-arabic"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-zinc-400 font-bold mb-1">Tagline (English)</label>
              <input
                type="text"
                value={settings.tagline}
                onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">Tagline (Arabic)</label>
              <input
                type="text"
                value={settings.taglineArabic}
                onChange={(e) => setSettings({ ...settings, taglineArabic: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white font-arabic"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-zinc-400 font-bold mb-1">Logo Image URL</label>
              <input
                type="text"
                value={settings.logoUrl}
                onChange={(e) => setSettings({ ...settings, logoUrl: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">Favicon URL</label>
              <input
                type="text"
                value={settings.faviconUrl}
                onChange={(e) => setSettings({ ...settings, faviconUrl: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white font-mono"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Physical Branch & Contact */}
        <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-2xl space-y-4">
          <h3 className="font-extrabold text-emerald-400 uppercase tracking-wider text-[11px] border-b border-zinc-800 pb-1 flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            <span>2. Zagazig Branch Contact & Map Location</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-zinc-400 font-bold mb-1">Phone Number</label>
              <input
                type="text"
                value={settings.phone}
                onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">WhatsApp Business Number</label>
              <input
                type="text"
                value={settings.whatsappPhone}
                onChange={(e) => setSettings({ ...settings, whatsappPhone: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">Official Email</label>
              <input
                type="email"
                value={settings.email}
                onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-zinc-400 font-bold mb-1">Physical Address (English)</label>
              <input
                type="text"
                value={settings.address}
                onChange={(e) => setSettings({ ...settings, address: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">Physical Address (Arabic)</label>
              <input
                type="text"
                value={settings.addressArabic}
                onChange={(e) => setSettings({ ...settings, addressArabic: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white font-arabic"
              />
            </div>
          </div>

          <div>
            <label className="block text-zinc-400 font-bold mb-1">Business Operating Hours</label>
            <input
              type="text"
              value={settings.businessHours}
              onChange={(e) => setSettings({ ...settings, businessHours: e.target.value })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-white"
            />
          </div>
        </div>

        {/* Section 3: Payment Gateways */}
        <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-2xl space-y-4">
          <h3 className="font-extrabold text-emerald-400 uppercase tracking-wider text-[11px] border-b border-zinc-800 pb-1 flex items-center gap-2">
            <CreditCard className="w-4 h-4" />
            <span>3. Payment Gateways & Local Mobile Wallets</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <label className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between cursor-pointer">
              <span className="font-bold text-white">Vodafone Cash</span>
              <input
                type="checkbox"
                checked={settings.enableVodafoneCash}
                onChange={(e) => setSettings({ ...settings, enableVodafoneCash: e.target.checked })}
                className="rounded border-zinc-700 bg-zinc-900 text-emerald-500"
              />
            </label>

            <label className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between cursor-pointer">
              <span className="font-bold text-white">InstaPay</span>
              <input
                type="checkbox"
                checked={settings.enableInstaPay}
                onChange={(e) => setSettings({ ...settings, enableInstaPay: e.target.checked })}
                className="rounded border-zinc-700 bg-zinc-900 text-emerald-500"
              />
            </label>

            <label className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between cursor-pointer">
              <span className="font-bold text-white">valU Instalments</span>
              <input
                type="checkbox"
                checked={settings.enableValu}
                onChange={(e) => setSettings({ ...settings, enableValu: e.target.checked })}
                className="rounded border-zinc-700 bg-zinc-900 text-emerald-500"
              />
            </label>

            <label className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between cursor-pointer">
              <span className="font-bold text-white">Credit Card (CIB)</span>
              <input
                type="checkbox"
                checked={settings.enableCIB}
                onChange={(e) => setSettings({ ...settings, enableCIB: e.target.checked })}
                className="rounded border-zinc-700 bg-zinc-900 text-emerald-500"
              />
            </label>

            <label className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between cursor-pointer">
              <span className="font-bold text-white">Cash on Delivery</span>
              <input
                type="checkbox"
                checked={settings.enableCOD}
                onChange={(e) => setSettings({ ...settings, enableCOD: e.target.checked })}
                className="rounded border-zinc-700 bg-zinc-900 text-emerald-500"
              />
            </label>
          </div>
        </div>

      </form>

    </div>
  );
};
