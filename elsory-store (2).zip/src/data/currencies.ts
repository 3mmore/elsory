import { Currency, CurrencyConfig } from '../types';

export const CURRENCIES: Record<Currency, CurrencyConfig> = {
  EGP: { code: 'EGP', symbol: 'ج.م', rateToUSD: 48.5, decimals: 0 },
  USD: { code: 'USD', symbol: '$', rateToUSD: 1, decimals: 0 },
  EUR: { code: 'EUR', symbol: '€', rateToUSD: 0.92, decimals: 0 },
  SAR: { code: 'SAR', symbol: 'ر.س', rateToUSD: 3.75, decimals: 0 },
  AED: { code: 'AED', symbol: 'د.إ', rateToUSD: 3.67, decimals: 0 },
  SYP: { code: 'SYP', symbol: 'ل.س', rateToUSD: 14800, decimals: 0 },
};

export function formatPrice(amountUSD: number, _currency?: Currency): string {
  // Always format as EGP (Egyptian Pound - ج.م)
  const egpAmount = amountUSD > 3000 ? amountUSD : amountUSD * 48.5;
  return `${Math.round(egpAmount).toLocaleString('en-US')} ج.م`;
}
