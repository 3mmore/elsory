import { Product } from '../types';

export const PRODUCTS: Product[] = [
  // --------------------------------------------------------------------------
  // FLAGSHIP SMARTPHONES
  // --------------------------------------------------------------------------
  {
    id: 'syr-iphone17promax',
    name: 'iPhone 17 Pro Max',
    brand: 'Apple',
    category: 'Smartphones',
    priceUSD: 1299,
    originalPriceUSD: 1399,
    rating: 5.0,
    reviewsCount: 420,
    badge: 'Flagship Hero',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'The ultimate pinnacle of Apple innovation. Engineered with Grade 5 Titanium chassis, revolutionary A19 Pro Neural chip, 48MP Quad-Fusion Camera Array with 10x Periscope Optical Zoom, and Tandem OLED Super Retina XDR Display.',
    features: [
      'A19 Pro 3nm Silicon Engine with 16-Core Neural Processing',
      'Tandem OLED Super Retina XDR with 3000 nits Peak Outdoor Brightness',
      '48MP Quad-Fusion Main + 48MP Ultra-Wide + 48MP 10x Optical Periscope Zoom',
      'Grade 5 Aerospace Titanium with Micro-milled Thermal Vapor Chamber',
      'Up to 36 hours continuous video playback with Silicon-Carbon Battery'
    ],
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Deep Titanium', hex: '#1c1d21' },
      { name: 'Desert Sand', hex: '#cfa98b' },
      { name: 'Space Black', hex: '#2b2b2e' },
      { name: 'Silver Titanium', hex: '#f0f0f0' }
    ],
    storageOptions: [
      { size: '256GB', priceUSD: 1299 },
      { size: '512GB', priceUSD: 1499 },
      { size: '1TB', priceUSD: 1799 },
      { size: '2TB', priceUSD: 2099 }
    ],
    specsDetail: {
      display: '6.9" Tandem OLED Super Retina XDR, 120Hz ProMotion, 3000 nits',
      chipset: 'Apple A19 Pro (3nm Ultra-Efficiency)',
      mainCamera: '48MP Quad-Fusion + 48MP Ultra-Wide + 48MP 10x Periscope OIS',
      selfieCamera: '24MP TrueDepth with Autofocus & 4K60 HDR',
      battery: '4,850 mAh Silicon-Carbon High Density',
      charging: '45W Wired, 25W MagSafe 2 Wireless',
      weight: '221 grams',
      network: '5G Sub-6/mmWave, Wi-Fi 7, Satellite Messaging',
      os: 'iOS 19 with Apple Intelligence Pro',
      waterResistance: 'IP68 (6m up to 30 mins)'
    }
  },
  {
    id: 'syr-s26ultra',
    name: 'Samsung Galaxy S26 Ultra',
    brand: 'Samsung',
    category: 'Smartphones',
    priceUSD: 1399,
    originalPriceUSD: 1499,
    rating: 5.0,
    reviewsCount: 310,
    badge: 'New Arrival',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Samsung flagship with Snapdragon 8 Elite Gen 2 for Galaxy, 200MP Quad-Tele Quantum Camera System, Corning Gorilla Armor 2 anti-reflective display, and built-in S Pen.',
    features: [
      'Snapdragon 8 Elite Gen 2 (3nm Extreme Performance)',
      '200MP Primary Sensor + 50MP 10x Periscope + 50MP 3x + 50MP Ultra-Wide',
      'Corning Gorilla Armor 2 with 90% Anti-Reflective Coating',
      'Built-in S Pen with 2.8ms Ultra-Low Latency',
      'Galaxy AI 3.0 Real-Time On-Device Multimodal Translation'
    ],
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1580910051074-3eb694886505?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Titanium Cobalt', hex: '#233246' },
      { name: 'Titanium Emerald', hex: '#1e382d' },
      { name: 'Titanium Onyx', hex: '#1a1b1d' },
      { name: 'Titanium Silver', hex: '#d4d8dd' }
    ],
    storageOptions: [
      { size: '256GB / 12GB RAM', priceUSD: 1399 },
      { size: '512GB / 16GB RAM', priceUSD: 1599 },
      { size: '1TB / 16GB RAM', priceUSD: 1849 }
    ],
    specsDetail: {
      display: '6.8" Dynamic AMOLED 2X, 120Hz LTPO, 2800 nits Anti-Reflective',
      chipset: 'Qualcomm Snapdragon 8 Elite Gen 2 for Galaxy',
      mainCamera: '200MP OIS + 50MP 10x Periscope + 50MP 3x + 50MP UW',
      selfieCamera: '12MP Dual Pixel PDAF',
      battery: '5,000 mAh Silicon-Anode',
      charging: '65W Super Fast Charging 2.0, 15W Wireless',
      weight: '218 grams',
      network: '5G Dual SIM, Wi-Fi 7, UWB',
      os: 'Android 16 with One UI 8',
      waterResistance: 'IP68'
    }
  },
  {
    id: 'syr-iphone16promax',
    name: 'iPhone 16 Pro Max',
    brand: 'Apple',
    category: 'Smartphones',
    priceUSD: 1199,
    originalPriceUSD: 1299,
    rating: 4.9,
    reviewsCount: 328,
    badge: 'Bestseller',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Forged in Grade 5 titanium with desert titanium colorway. Features A18 Pro chip, 48MP Fusion camera with 4K 120 fps Dolby Vision recording, and 6.9-inch display.',
    features: [
      'Grade 5 Titanium enclosure with Ceramic Shield',
      'A18 Pro chip with 6-core GPU',
      '48MP Fusion Camera + 5x Telephoto Zoom',
      'Camera Control button for intuitive photography',
      'Up to 33 hours video playback'
    ],
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Natural Titanium', hex: '#beaba1' },
      { name: 'Desert Titanium', hex: '#cfa98b' },
      { name: 'White Titanium', hex: '#f0f0f0' },
      { name: 'Black Titanium', hex: '#2b2b2e' }
    ],
    storageOptions: [
      { size: '256GB', priceUSD: 1199 },
      { size: '512GB', priceUSD: 1399 },
      { size: '1TB', priceUSD: 1599 }
    ],
    specsDetail: {
      display: '6.9-inch Super Retina XDR OLED, 120Hz ProMotion, 2000 nits',
      chipset: 'Apple A18 Pro (3nm)',
      mainCamera: '48MP Fusion + 48MP Ultra Wide + 12MP 5x Telephoto',
      selfieCamera: '12MP TrueDepth with Autofocus',
      battery: '4,685 mAh',
      charging: '45W Wired, 25W MagSafe Wireless',
      weight: '227 grams',
      network: '5G NR (Sub-6GHz and mmWave), Wi-Fi 7',
      os: 'iOS 18 with Apple Intelligence',
      waterResistance: 'IP68'
    }
  },
  {
    id: 'syr-s25ultra',
    name: 'Samsung Galaxy S25 Ultra',
    brand: 'Samsung',
    category: 'Smartphones',
    priceUSD: 1299,
    originalPriceUSD: 1399,
    rating: 4.9,
    reviewsCount: 215,
    badge: 'Popular',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'The Android flagship with Galaxy AI built into every interaction. Sculpted titanium frame, built-in S Pen, Snapdragon 8 Elite chip, and 200MP Quad Tele System camera.',
    features: [
      'Snapdragon 8 Elite for Galaxy (3nm)',
      'Built-in precision S Pen',
      '200MP Camera with 100x Space Zoom',
      'Corning Gorilla Armor anti-reflective glass',
      'Galaxy AI Live Translate & Circle to Search'
    ],
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Titanium Black', hex: '#1c1d21' },
      { name: 'Titanium Silver', hex: '#d4d8dd' },
      { name: 'Titanium Blue', hex: '#3b5368' }
    ],
    storageOptions: [
      { size: '256GB', priceUSD: 1299 },
      { size: '512GB', priceUSD: 1499 },
      { size: '1TB', priceUSD: 1749 }
    ],
    specsDetail: {
      display: '6.8-inch Dynamic AMOLED 2X, 120Hz, 2600 nits Anti-Glare',
      chipset: 'Qualcomm Snapdragon 8 Elite (3nm)',
      mainCamera: '200MP Main + 50MP Periscope 5x + 50MP Ultra Wide',
      selfieCamera: '12MP Dual Pixel PDAF',
      battery: '5,000 mAh',
      charging: '45W Super Fast Wired, 15W Wireless 2.0',
      weight: '219 grams',
      network: '5G, Wi-Fi 7, UWB',
      os: 'Android 15 with One UI 7.1',
      waterResistance: 'IP68'
    }
  },
  {
    id: 'syr-pixel9pro',
    name: 'Google Pixel 9 Pro XL',
    brand: 'Google',
    category: 'Smartphones',
    priceUSD: 1099,
    originalPriceUSD: 1199,
    rating: 4.8,
    reviewsCount: 178,
    badge: 'Popular',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Google Tensor G4 chip engineered for Gemini AI intelligence. Sleek polished metal frame with silky matte back glass and studio-grade pro triple camera array.',
    features: [
      'Google Tensor G4 with Titan M2 security',
      'Gemini Nano with Multimodality built-in',
      'Super Res Zoom up to 30x + Video Boost',
      '7 years of Android OS updates',
      '24+ hour battery with Extreme Battery Saver'
    ],
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Obsidian', hex: '#1b1b1b' },
      { name: 'Porcelain', hex: '#f3f3f1' },
      { name: 'Hazel', hex: '#525a52' }
    ],
    storageOptions: [
      { size: '256GB', priceUSD: 1199 },
      { size: '512GB', priceUSD: 1349 }
    ],
    specsDetail: {
      display: '6.8-inch Super Actua OLED, 1-120Hz LTPO, 3000 nits peak',
      chipset: 'Google Tensor G4 (4nm)',
      mainCamera: '50MP Main OIS + 48MP Ultra Wide + 48MP 5x Telephoto',
      selfieCamera: '42MP Ultra Wide with Autofocus',
      battery: '5,060 mAh',
      charging: '37W Fast Charging, Wireless Qi',
      weight: '221 grams',
      network: '5G, Wi-Fi 7',
      os: 'Android 15 Native Google',
      waterResistance: 'IP68'
    }
  },
  {
    id: 'syr-nothing2a',
    name: 'Nothing Phone (2a) Plus',
    brand: 'Nothing',
    category: 'Smartphones',
    priceUSD: 449,
    originalPriceUSD: 499,
    rating: 4.8,
    reviewsCount: 142,
    badge: 'Popular',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Iconic transparent design with Glyph Interface illumination. Powered by the MediaTek Dimensity 7350 Pro 5G processor and dual 50MP studio-grade camera sensors.',
    features: [
      'Signature Glyph Interface lighting',
      'MediaTek Dimensity 7350 Pro 5G',
      'Dual 50MP Rear Cameras + 50MP Selfie',
      'Nothing OS 3.0 minimalist interface',
      '120Hz Flexible AMOLED Display'
    ],
    image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Metallic Grey', hex: '#4e5359' },
      { name: 'Pure Black', hex: '#121212' },
      { name: 'Milky White', hex: '#e8e8e8' }
    ],
    storageOptions: [
      { size: '256GB / 12GB RAM', priceUSD: 449 }
    ],
    specsDetail: {
      display: '6.7-inch Flexible AMOLED, 120Hz Adaptive, 1300 nits',
      chipset: 'MediaTek Dimensity 7350 Pro (4nm)',
      mainCamera: '50MP OIS Main + 50MP Ultra Wide',
      selfieCamera: '50MP 4K Video Selfie',
      battery: '5,000 mAh',
      charging: '50W Fast Charging',
      weight: '190 grams',
      network: '5G Dual SIM',
      os: 'Nothing OS 3.0 (Android 15)',
      waterResistance: 'IP54'
    }
  },
  {
    id: 'syr-gold-iphone16',
    name: '24K Gold Syrian Falcon Edition iPhone 16 Pro Max',
    brand: 'Apple',
    category: 'Luxury Editions',
    priceUSD: 4800,
    originalPriceUSD: 5200,
    rating: 5.0,
    reviewsCount: 19,
    badge: 'Luxury Masterpiece',
    isFeatured: true,
    inStock: true,
    warrantyYears: 2,
    description: 'Exclusive hand-crafted luxury edition plated in 24-Karat Solid Gold with custom laser-engraved Syrian Falcon emblem on the back. Limited to 50 numbered pieces worldwide.',
    features: [
      '24K Solid Gold Electroplated Enclosure',
      'Custom Engraved Syrian Falcon Heritage Emblem',
      'Includes Wooden Collector Box with Authenticity Certificate',
      'VIP Priority 24/7 Concierge & Express World Warranty',
      '1TB Storage Top Configuration'
    ],
    image: 'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: '24K Yellow Gold', hex: '#d4af37' },
      { name: 'Rose Gold & Black Diamond', hex: '#b76e79' }
    ],
    storageOptions: [
      { size: '1TB Luxury Box', priceUSD: 4800 }
    ],
    specsDetail: {
      display: '6.9-inch Super Retina XDR OLED, 120Hz ProMotion',
      chipset: 'Apple A18 Pro Custom Tuned',
      mainCamera: '48MP Triple Lens Studio System',
      selfieCamera: '12MP TrueDepth',
      battery: '4,685 mAh',
      charging: '45W Fast Charging',
      weight: '255 grams (Gold Plated)',
      network: '5G Unlocked Global',
      os: 'iOS 18 Pro',
      waterResistance: 'IP68'
    }
  },

  // --------------------------------------------------------------------------
  // ANKER ACCESSORIES
  // --------------------------------------------------------------------------
  {
    id: 'syr-anker-nano30w',
    name: 'Anker Nano 30W GaN Fast Wall Charger',
    brand: 'Anker',
    category: 'Accessories',
    priceUSD: 22,
    originalPriceUSD: 28,
    rating: 4.9,
    reviewsCount: 189,
    badge: 'Essential',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Ultra-compact 30W USB-C GaN fast charger. Powers up iPhone 17 Pro Max and Galaxy S26 Ultra to 50% in just 25 minutes. ActiveShield 2.0 dynamic temperature monitoring.',
    features: [
      '30W USB-C Power Delivery 3.0 Output',
      'GaN Technology for 70% smaller size than standard chargers',
      'ActiveShield 2.0 temperature protection',
      'Universal compatibility with Apple, Samsung, and Pixel',
      'Foldable plug design'
    ],
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Phantom Black', hex: '#111111' },
      { name: 'Glacier White', hex: '#f0f0f0' },
      { name: 'Misty Blue', hex: '#8ea8c3' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Anker GaNPrime Silicon',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'N/A',
      charging: '30W USB-C PD / PPS Output',
      weight: '40 grams',
      network: 'N/A',
      os: 'PowerIQ 3.0',
      waterResistance: 'Indoor'
    }
  },
  {
    id: 'syr-anker-prime67w',
    name: 'Anker Prime 67W 3-Port GaN Wall Charger',
    brand: 'Anker',
    category: 'Accessories',
    priceUSD: 59,
    originalPriceUSD: 69,
    rating: 4.9,
    reviewsCount: 145,
    badge: 'Pro Grade',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Multi-device 67W GaN fast charger with 2x USB-C and 1x USB-A ports. Simultaneously fast-charges a MacBook Pro, iPhone, and AirPods with intelligent power distribution.',
    features: [
      '67W Maximum Total Power Delivery',
      'Dual USB-C Ports + USB-A Port',
      'MultiPlex PowerIQ 4.0 Dynamic Allocation',
      '51% smaller than standard 67W single chargers',
      'Compact foldable pins for travel'
    ],
    image: 'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Space Grey', hex: '#2c2d30' },
      { name: 'Silver White', hex: '#e5e5e7' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Anker PowerIQ 4.0 GaN',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'N/A',
      charging: '67W Max Output (USB-C1 + USB-C2 + USB-A)',
      weight: '115 grams',
      network: 'N/A',
      os: 'MultiPlex Distribution',
      waterResistance: 'Indoor'
    }
  },
  {
    id: 'syr-anker-cable',
    name: 'Anker PowerLine III Flow USB-C to USB-C (100W)',
    brand: 'Anker',
    category: 'Accessories',
    priceUSD: 19,
    originalPriceUSD: 24,
    rating: 4.8,
    reviewsCount: 290,
    badge: 'Popular',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Ultra-soft silicone finish cable with 25,000 bend lifespan. Supports up to 100W USB Power Delivery for laptops, tablets, and flagship smartphones.',
    features: [
      'Soft-touch silicone jacket resists tangling',
      'Supports 100W (20V/5A) Power Delivery charging',
      '25,000+ bend lifespan certified',
      'Includes silicone cable tie organizer',
      '6ft / 1.8m length'
    ],
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Midnight Black', hex: '#111111' },
      { name: 'Cloud White', hex: '#f2f2f2' },
      { name: 'Lilac Purple', hex: '#b3a5c2' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'E-Marker Smart Chip',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'N/A',
      charging: '100W PD (20V/5A)',
      weight: '35 grams',
      network: 'N/A',
      os: 'USB 2.0 Data 480Mbps',
      waterResistance: 'Indoor'
    }
  },
  {
    id: 'syr-magsafebank',
    name: 'Anker MagGo 10,000mAh Power Bank',
    brand: 'Anker',
    category: 'Accessories',
    priceUSD: 89,
    originalPriceUSD: 99,
    rating: 4.8,
    reviewsCount: 230,
    badge: 'Special Offer',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Qi2-certified 15W wireless magnetic power bank with smart digital screen showing real-time battery percentage and remaining charging time.',
    features: [
      'Qi2 Certified 15W Ultra Magnetic Fast Wireless',
      '10,000mAh capacity charges iPhone 16/17 Pro 2.2 times',
      'Smart Color Display with live wattage output',
      '27W USB-C bi-directional wired fast charging',
      'Built-in foldable kickstand'
    ],
    image: 'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Matte Black', hex: '#111111' },
      { name: 'Glacier White', hex: '#f0f0f0' }
    ],
    specsDetail: {
      display: 'LCD Power Display',
      chipset: 'Anker ActiveShield 2.0',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: '10,000 mAh High-Density Li-Po',
      charging: '15W Wireless Qi2 + 27W USB-C PD',
      weight: '250 grams',
      network: 'N/A',
      os: 'PowerIQ 4.0',
      waterResistance: 'Indoor'
    }
  },

  // --------------------------------------------------------------------------
  // JOYROOM ACCESSORIES
  // --------------------------------------------------------------------------
  {
    id: 'syr-joyroom-anc',
    name: 'Joyroom JR-T03S Pro ANC True Wireless Earbuds',
    brand: 'Joyroom',
    category: 'Audio & Sound',
    priceUSD: 39,
    originalPriceUSD: 49,
    rating: 4.8,
    reviewsCount: 312,
    badge: 'Top Value',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Active Noise Cancellation wireless earbuds with 35dB noise reduction, popup quick pairing for iOS/Android, wireless charging case, and HD spatial microphone.',
    features: [
      '35dB Active Noise Cancellation + Transparency Mode',
      'Wireless charging supported case',
      'Pop-up auto pairing interface',
      'Up to 30 hours total playback time',
      '13mm composite diaphragm speaker drivers'
    ],
    image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Gloss White', hex: '#ffffff' },
      { name: 'Matte Black', hex: '#121212' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'JL AC7003 ANC Audio DSP',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: '360mAh Case / 30mAh Earbuds (6 Hours continuous)',
      charging: 'Qi Wireless & Lightning/USB-C',
      weight: '4.2 grams per earbud',
      network: 'Bluetooth 5.3',
      os: 'Universal iOS/Android',
      waterResistance: 'IPX4'
    }
  },
  {
    id: 'syr-joyroom-carcharger',
    name: 'Joyroom 65W Fast Metal Car Charger Dual Port',
    brand: 'Joyroom',
    category: 'Accessories',
    priceUSD: 25,
    originalPriceUSD: 32,
    rating: 4.9,
    reviewsCount: 167,
    badge: 'Best Seller',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'All-metal alloy 65W dual-port car charger with soft blue LED ring light. Supports PD 3.0 & QC 4.0 fast charging for smartphones and laptops on the go.',
    features: [
      '65W Dual Output (45W USB-C PD + 20W USB-A QC)',
      'Zinc alloy fireproof metallic heat dissipation body',
      'Soft ring ambient night light',
      'Supports Samsung Super Fast Charging 45W',
      'Multi-protection against overcurrent & voltage spikes'
    ],
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Gunmetal Silver', hex: '#3d4043' },
      { name: 'Obsidian Black', hex: '#191a1c' }
    ],
    specsDetail: {
      display: 'Ambient Ring Light',
      chipset: 'Smart Power ID Chip',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'N/A',
      charging: '65W Max (USB-C PD 45W + USB-A 20W)',
      weight: '32 grams',
      network: 'N/A',
      os: '12V - 24V Car Socket Compatible',
      waterResistance: 'Car Interior'
    }
  },
  {
    id: 'syr-joyroom-pd20w',
    name: 'Joyroom 20W Fast PD Charger & Braided Cable Combo',
    brand: 'Joyroom',
    category: 'Accessories',
    priceUSD: 18,
    originalPriceUSD: 25,
    rating: 4.8,
    reviewsCount: 240,
    badge: 'Value Pack',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: '20W USB-C Fast Wall Charger bundled with a 1.2m nylon braided cable. Safe temperature regulation for iPhone and Android devices.',
    features: [
      '20W PD 3.0 Fast Charging Output',
      'Includes 1.2m high-density braided cable',
      'Smart IC automatically adjusts power output',
      'Fireproof PC shell construction',
      'CE / FCC certified safety standards'
    ],
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Snow White', hex: '#ffffff' },
      { name: 'Stealth Black', hex: '#111111' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Joyroom Safety IC',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'N/A',
      charging: '20W USB-C PD Output',
      weight: '48 grams',
      network: 'N/A',
      os: 'Universal',
      waterResistance: 'Indoor'
    }
  },

  // --------------------------------------------------------------------------
  // BASEUS ACCESSORIES
  // --------------------------------------------------------------------------
  {
    id: 'syr-baseus-blade100w',
    name: 'Baseus Blade 100W Ultra-Thin Laptop Power Bank (20,000mAh)',
    brand: 'Baseus',
    category: 'Accessories',
    priceUSD: 79,
    originalPriceUSD: 95,
    rating: 4.9,
    reviewsCount: 204,
    badge: 'Pro Power',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Ultra-thin 18mm power bank with 100W USB-C Power Delivery. Capable of charging MacBooks, laptops, and flagship smartphones at maximum speed.',
    features: [
      '100W Dual USB-C + Dual USB-A Output Ports',
      '20,000mAh High Capacity in slim 18mm profile',
      'Digital Status Screen showing voltage, current, and time remaining',
      '65W USB-C Fast Input (recharges fully in 90 minutes)',
      'Airline approved battery capacity'
    ],
    image: 'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Dark Grey', hex: '#232426' }
    ],
    specsDetail: {
      display: 'Digital LED Screen',
      chipset: 'Baseus BPS II Technology',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: '20,000 mAh High-Density Polymer',
      charging: '100W Output / 65W Input PD',
      weight: '490 grams',
      network: 'N/A',
      os: 'PD 3.0 / QC 4+ / PPS',
      waterResistance: 'Indoor'
    }
  },
  {
    id: 'syr-baseus-ma10',
    name: 'Baseus Bowie MA10 Hybrid ANC Wireless Earbuds',
    brand: 'Baseus',
    category: 'Audio & Sound',
    priceUSD: 45,
    originalPriceUSD: 59,
    rating: 4.8,
    reviewsCount: 188,
    badge: 'Long Battery',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: '-48dB Hybrid Active Noise Cancellation with massive 140-hour total playtime with charging case. Recommended by Oscar-winning audio engineers.',
    features: [
      '-48dB Active Noise Cancellation with 4-mic ENC',
      'Up to 140 hours battery life with charging case',
      '0.038s Ultra-Low Latency Gaming Mode',
      'IPX6 waterproof rating for intense workouts',
      'Titanium-plated diaphragm drivers'
    ],
    image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Cluster Black', hex: '#101012' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Baseus Dual-Channel Low Latency DSP',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: '8 Hours Earbuds / 140 Hours total with case',
      charging: 'USB-C Fast Charge (10 min charge = 2 hours)',
      weight: '4.8 grams per earbud',
      network: 'Bluetooth 5.3',
      os: 'Baseus App Custom EQ',
      waterResistance: 'IPX6 Waterproof'
    }
  },

  // --------------------------------------------------------------------------
  // UGREEN ACCESSORIES
  // --------------------------------------------------------------------------
  {
    id: 'syr-ugreen-nexode65w',
    name: 'UGREEN Nexode 65W 3-Port GaN Fast Wall Charger',
    brand: 'UGREEN',
    category: 'Accessories',
    priceUSD: 49,
    originalPriceUSD: 59,
    rating: 4.9,
    reviewsCount: 210,
    badge: 'Popular',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Flagship GaNFast charger with 2x USB-C PD ports and 1x USB-A port. Thermal Guard system monitors temperature 800 times per second for safe charging.',
    features: [
      '65W Total Output with GaN III Chipset',
      'Charges 3 devices simultaneously',
      'Thermal Guard 800x/sec temperature protection',
      'Foldable plug pins for travel',
      'Wide compatibility with iPhone, Galaxy, and MacBooks'
    ],
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Space Grey', hex: '#313338' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'GaNFast III & Thermal Guard',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'N/A',
      charging: '65W Max USB-C PD 3.0 / PPS',
      weight: '128 grams',
      network: 'N/A',
      os: 'Power Allocation Engine',
      waterResistance: 'Indoor'
    }
  },
  {
    id: 'syr-ugreen-carmount',
    name: 'UGREEN MagSafe Magnetic Wireless Car Charger (15W)',
    brand: 'UGREEN',
    category: 'Accessories',
    priceUSD: 32,
    originalPriceUSD: 39,
    rating: 4.8,
    reviewsCount: 175,
    badge: 'Top Rated',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Strong N52 neodymium magnets hold your phone securely over bumps and turns while delivering fast 15W Qi wireless charging via air vent clamp.',
    features: [
      '15W Fast Wireless Magnetic Charging',
      'N52 Neodymium Magnetic Array holds up to 1.8kg',
      '360-degree rotating ball joint for portrait & landscape orientation',
      'Upgrade metal hook air vent clip lock',
      'Soft silicone anti-scratch padding'
    ],
    image: 'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Matte Black', hex: '#1a1a1a' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Smart Qi Power IC',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'N/A',
      charging: '15W MagSafe Fast Wireless',
      weight: '90 grams',
      network: 'N/A',
      os: 'Car Air Vent Clip Mount',
      waterResistance: 'Car Interior'
    }
  },

  // --------------------------------------------------------------------------
  // AUDIO & WEARABLES
  // --------------------------------------------------------------------------
  {
    id: 'syr-airpodspro2',
    name: 'AirPods Pro 2 (USB-C MagSafe)',
    brand: 'Apple',
    category: 'Audio & Sound',
    priceUSD: 249,
    originalPriceUSD: 279,
    rating: 4.9,
    reviewsCount: 512,
    badge: 'Bestseller',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Pro-level Active Noise Cancellation twice as effective as previous generation. Transparency mode, Personalized Spatial Audio with dynamic head tracking, and USB-C MagSafe case.',
    features: [
      'H2 Apple Silicon Chip',
      'Adaptive Audio & Conversation Awareness',
      'Up to 6 hours listening time on single charge',
      'IP54 dust, sweat, and water resistance',
      'Precision Finding with U1 chip in case'
    ],
    image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Gloss White', hex: '#ffffff' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Apple H2 Headphone Chip + U1 Case Chip',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'Up to 30 hours total with charging case',
      charging: 'USB-C, MagSafe, Apple Watch Charger',
      weight: '5.3 grams per earbud',
      network: 'Bluetooth 5.3',
      os: 'Apple Audio OS',
      waterResistance: 'IP54'
    }
  },
  {
    id: 'syr-watchultra2',
    name: 'Apple Watch Ultra 2 Titanium',
    brand: 'Apple',
    category: 'Smartwatches',
    priceUSD: 799,
    originalPriceUSD: 849,
    rating: 4.9,
    reviewsCount: 164,
    badge: 'Flagship Watch',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'The most capable and rugged Apple watch. Corrosion-resistant titanium case with 3000-nit display, double tap gesture control, dual-frequency GPS, and up to 72 hours battery life.',
    features: [
      '49mm Grade 5 Titanium Case',
      '3000-nit display - brightest Apple display',
      'S9 SiP chip with Double Tap gesture',
      'Precision dual-frequency GPS (L1 and L5)',
      '100m water resistance + EN13319 dive certified'
    ],
    image: 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Natural Titanium', hex: '#c0c2c6' },
      { name: 'Black Titanium', hex: '#262628' }
    ],
    specsDetail: {
      display: '49mm Sapphire Crystal Always-On Retina, 3000 nits',
      chipset: 'Apple S9 SiP 64-bit dual-core',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'Up to 36 hours normal, 72 hours low power',
      charging: 'Magnetic Fast Charger to USB-C',
      weight: '61.4 grams',
      network: 'GPS + Cellular',
      os: 'watchOS 11',
      waterResistance: '100m Water Resistant'
    }
  },

  // --------------------------------------------------------------------------
  // REPAIR CENTER SERVICES
  // --------------------------------------------------------------------------
  {
    id: 'syr-repair-iphone-screen',
    name: 'iPhone Original OLED Screen Replacement (Express 30-Min)',
    brand: 'Apple',
    category: 'Repair Services',
    priceUSD: 85,
    originalPriceUSD: 110,
    rating: 5.0,
    reviewsCount: 420,
    badge: 'Express Service',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Professional original OLED display replacement at ElSory Store Zagazig Center. Includes TrueTone transfer, dust-and-water seal restoration, and 12-month official store warranty.',
    features: [
      'Original OLED / Super Retina Display Panel',
      'TrueTone & Auto-Brightness IC programming transfer',
      'Water & Dust Resistance Gasket Seal Restoration',
      'Express 30-Minute Turnaround at Zagazig Branch',
      '12 Months Full Replacement Warranty'
    ],
    image: 'https://images.unsplash.com/photo-1597740985671-2a8a3b80502e?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1597740985671-2a8a3b80502e?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Original Factory Display', hex: '#000000' }
    ],
    specsDetail: {
      display: 'OEM / Original OLED Panel with TrueTone Support',
      chipset: 'Original Touch Controller IC Transferred',
      mainCamera: 'Preserved',
      selfieCamera: 'Preserved & Calibrated',
      battery: 'No battery impact',
      charging: 'N/A',
      weight: 'Same as original',
      network: 'N/A',
      os: 'All iOS versions supported',
      waterResistance: 'IP68 Gasket Re-sealed'
    }
  },
  {
    id: 'syr-repair-battery',
    name: 'Genuine High-Capacity Battery Replacement & Health Calibration',
    brand: 'Apple',
    category: 'Repair Services',
    priceUSD: 35,
    originalPriceUSD: 45,
    rating: 4.9,
    reviewsCount: 310,
    badge: 'Official Guarantee',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Restore 100% Battery Health with authentic high-density battery cells. Performed by certified technicians at ElSory Store Zagazig & Cairo service centers.',
    features: [
      'Authentic Zero-Cycle Battery Cells',
      '100% Battery Health % restoring in iOS / Android Settings',
      'Thermal Protection & Overcharge Prevention IC',
      'Express 20-minute installation while you wait',
      '12 Months Store Warranty'
    ],
    image: 'https://images.unsplash.com/photo-1619948326514-668d3a41819f?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1619948326514-668d3a41819f?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'OEM Certified Cell', hex: '#1e293b' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Power Management IC Verified',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: '100% Maximum Capacity Restored',
      charging: 'Supports MagSafe & Fast Charging',
      weight: 'Factory Spec',
      network: 'N/A',
      os: 'Supports iOS 18 & Android 15',
      waterResistance: 'Water Seal Re-applied'
    }
  },
  {
    id: 'syr-repair-backglass',
    name: 'Precision Laser Back Glass Removal & Glass Replacement',
    brand: 'Apple',
    category: 'Repair Services',
    priceUSD: 45,
    originalPriceUSD: 60,
    rating: 4.9,
    reviewsCount: 185,
    badge: 'Laser Tech',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Advanced automated laser separation technique removes shattered rear glass without opening or risking internal phone components. Available for iPhone 8 through 17 series and Samsung Ultra series.',
    features: [
      'Zero-Heat Laser Demounting Machine Tech',
      'OEM Color-Matched Corning Gorilla Glass Panel',
      'Wireless Charging Coil Undamaged Guaranteed',
      '1-Hour Same-Day Service in Zagazig',
      'Includes Lens Protector Ring'
    ],
    image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Color Matched OEM Glass', hex: '#0f172a' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'N/A',
      mainCamera: 'Lens Ring Protected',
      selfieCamera: 'N/A',
      battery: 'Wireless Charging Protected',
      charging: 'MagSafe Compatible',
      weight: 'Factory Spec',
      network: 'N/A',
      os: 'N/A',
      waterResistance: 'Waterproof Seal Applied'
    }
  },
  // --------------------------------------------------------------------------
  // TABLETS
  // --------------------------------------------------------------------------
  {
    id: 'syr-ipad-pro-m4',
    name: 'iPad Pro 13-inch (M4 Chip) Ultra Retina XDR',
    brand: 'Apple',
    category: 'Tablets',
    priceUSD: 1299,
    originalPriceUSD: 1399,
    rating: 5.0,
    reviewsCount: 142,
    badge: 'New',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Impossibly thin 5.1mm design powered by the groundbreaking Apple M4 chip. Features Tandem OLED Ultra Retina XDR display, Thunderbolt 4, and Apple Pencil Pro support.',
    features: [
      'Apple M4 Chip with 10-core CPU & 10-core GPU',
      '13-inch Tandem OLED Ultra Retina XDR with 1600 nits peak HDR',
      'Thin 5.1mm Precision Aluminium Enclosure',
      'Supports Apple Pencil Pro and Magic Keyboard',
      'Four-Speaker Audio and Studio-Quality Microphones'
    ],
    image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Space Black', hex: '#2b2b2e' },
      { name: 'Silver', hex: '#e3e4e6' }
    ],
    storageOptions: [
      { size: '256GB Wi-Fi', priceUSD: 1299 },
      { size: '512GB Wi-Fi + 5G', priceUSD: 1599 },
      { size: '1TB Nano-Texture Glass', priceUSD: 1999 }
    ],
    specsDetail: {
      display: '13.0" Tandem OLED Ultra Retina XDR, 120Hz ProMotion',
      chipset: 'Apple M4 Silicon Engine (3nm)',
      mainCamera: '12MP Wide 4K Video + LiDAR Scanner',
      selfieCamera: '12MP Landscape Ultra Wide Center Stage',
      battery: '38.99 watt-hour Li-Po',
      charging: '38W Fast USB-C / Thunderbolt 4',
      weight: '579 grams',
      network: 'Wi-Fi 6E / 5G Cellular',
      os: 'iPadOS 18 with Apple Intelligence',
      waterResistance: 'N/A'
    }
  },
  {
    id: 'syr-galaxy-tab-s10-ultra',
    name: 'Samsung Galaxy Tab S10 Ultra 5G',
    brand: 'Samsung',
    category: 'Tablets',
    priceUSD: 1199,
    originalPriceUSD: 1299,
    rating: 4.9,
    reviewsCount: 98,
    badge: 'Popular',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Massive 14.6-inch Dynamic AMOLED 2X anti-reflective display. Powered by Dimensity 9300+ 4nm AI processor, Armor Aluminum frame, and included S Pen in box.',
    features: [
      '14.6" Dynamic AMOLED 2X Display with Anti-Reflection',
      'MediaTek Dimensity 9300+ Flagship 4nm Processor',
      'Included Ultra-Low Latency S Pen in the box',
      'IP68 Dust and Water Resistance for Tablet & S Pen',
      'Galaxy AI Multimodal Productivity Suite'
    ],
    image: 'https://images.unsplash.com/photo-1561154464-82e9adf32764?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1561154464-82e9adf32764?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Moonstone Grey', hex: '#3a3d40' },
      { name: 'Platinum Silver', hex: '#d0d4d9' }
    ],
    storageOptions: [
      { size: '256GB / 12GB RAM', priceUSD: 1199 },
      { size: '512GB / 16GB RAM', priceUSD: 1399 }
    ],
    specsDetail: {
      display: '14.6" Dynamic AMOLED 2X, 120Hz, Anti-Reflection',
      chipset: 'MediaTek Dimensity 9300+ (4nm)',
      mainCamera: '13MP Main + 8MP Ultra-Wide',
      selfieCamera: 'Dual 12MP Ultra-Wide Center Stage',
      battery: '11,200 mAh',
      charging: '45W Super Fast Charging 2.0',
      weight: '718 grams',
      network: '5G Dual SIM, Wi-Fi 7',
      os: 'Android 15 with One UI 7 Tab',
      waterResistance: 'IP68'
    }
  }
];
