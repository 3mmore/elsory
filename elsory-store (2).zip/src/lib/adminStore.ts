import { 
  Product, 
  CategoryCMS, 
  BrandCMS, 
  Order, 
  Customer, 
  RepairBooking, 
  BlogPost, 
  Coupon, 
  FlashSale, 
  AIDocument, 
  HomepageSectionCMS, 
  WebsiteSettings, 
  AdminUser, 
  RolePermissionMatrix, 
  AuditLog,
  AdminRole,
  PermissionKey,
  CustomerLead
} from '../types';
import { PRODUCTS } from '../data/products';

// Default Admin Users
export const INITIAL_ADMIN_USERS: AdminUser[] = [
  {
    id: 'user-1',
    email: 'admin@elsory.com',
    name: 'Ammar ElSory',
    role: 'Super Admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    active: true,
    twoFactorEnabled: true,
    lastLogin: new Date().toISOString(),
    createdAt: '2025-01-01T00:00:00.000Z',
  },
  {
    id: 'user-2',
    email: 'sales@elsory.com',
    name: 'Karim Mahmoud',
    role: 'Sales',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    active: true,
    twoFactorEnabled: false,
    lastLogin: '2026-07-24T14:20:00.000Z',
    createdAt: '2025-02-15T00:00:00.000Z',
  },
  {
    id: 'user-3',
    email: 'tech@elsory.com',
    name: 'Eng. Ahmed Hassan',
    role: 'Technician',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    active: true,
    twoFactorEnabled: false,
    lastLogin: '2026-07-25T09:12:00.000Z',
    createdAt: '2025-03-01T00:00:00.000Z',
  },
  {
    id: 'user-4',
    email: 'marketing@elsory.com',
    name: 'Nour El-Din',
    role: 'Marketing',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    active: true,
    twoFactorEnabled: true,
    lastLogin: '2026-07-23T18:45:00.000Z',
    createdAt: '2025-03-10T00:00:00.000Z',
  },
];

// Default Role Permissions Matrix
export const DEFAULT_ROLE_PERMISSIONS: RolePermissionMatrix = {
  'Super Admin': {
    dashboard_read: true, products_read: true, products_write: true, products_delete: true,
    categories_manage: true, brands_manage: true, orders_read: true, orders_manage: true,
    customers_read: true, customers_manage: true, repairs_read: true, repairs_manage: true,
    cms_manage: true, blog_manage: true, marketing_manage: true, ai_manage: true,
    users_manage: true, settings_manage: true, backups_manage: true,
  },
  'Admin': {
    dashboard_read: true, products_read: true, products_write: true, products_delete: true,
    categories_manage: true, brands_manage: true, orders_read: true, orders_manage: true,
    customers_read: true, customers_manage: true, repairs_read: true, repairs_manage: true,
    cms_manage: true, blog_manage: true, marketing_manage: true, ai_manage: true,
    users_manage: false, settings_manage: true, backups_manage: false,
  },
  'Sales': {
    dashboard_read: true, products_read: true, products_write: false, products_delete: false,
    categories_manage: false, brands_manage: false, orders_read: true, orders_manage: true,
    customers_read: true, customers_manage: true, repairs_read: true, repairs_manage: false,
    cms_manage: false, blog_manage: false, marketing_manage: false, ai_manage: false,
    users_manage: false, settings_manage: false, backups_manage: false,
  },
  'Marketing': {
    dashboard_read: true, products_read: true, products_write: true, products_delete: false,
    categories_manage: true, brands_manage: true, orders_read: true, orders_manage: false,
    customers_read: true, customers_manage: false, repairs_read: false, repairs_manage: false,
    cms_manage: true, blog_manage: true, marketing_manage: true, ai_manage: true,
    users_manage: false, settings_manage: false, backups_manage: false,
  },
  'Inventory Manager': {
    dashboard_read: true, products_read: true, products_write: true, products_delete: false,
    categories_manage: true, brands_manage: true, orders_read: true, orders_manage: true,
    customers_read: false, customers_manage: false, repairs_read: false, repairs_manage: false,
    cms_manage: false, blog_manage: false, marketing_manage: false, ai_manage: false,
    users_manage: false, settings_manage: false, backups_manage: false,
  },
  'Technician': {
    dashboard_read: true, products_read: true, products_write: false, products_delete: false,
    categories_manage: false, brands_manage: false, orders_read: false, orders_manage: false,
    customers_read: true, customers_manage: false, repairs_read: true, repairs_manage: true,
    cms_manage: false, blog_manage: false, marketing_manage: false, ai_manage: false,
    users_manage: false, settings_manage: false, backups_manage: false,
  },
  'Customer Support': {
    dashboard_read: true, products_read: true, products_write: false, products_delete: false,
    categories_manage: false, brands_manage: false, orders_read: true, orders_manage: true,
    customers_read: true, customers_manage: true, repairs_read: true, repairs_manage: true,
    cms_manage: false, blog_manage: false, marketing_manage: false, ai_manage: true,
    users_manage: false, settings_manage: false, backups_manage: false,
  },
};

// Default Categories CMS
export const INITIAL_CATEGORIES: CategoryCMS[] = [
  { id: 'cat-1', name: 'Smartphones', nameArabic: 'الهواتف الذكية', description: 'Flagship & Premium Smartphones', iconName: 'Smartphone', order: 1, active: true },
  { id: 'cat-2', name: 'Tablets', nameArabic: 'الأجهزة اللوحية', description: 'iPads, Galaxy Tabs & Pro Tablets', iconName: 'Tablet', order: 2, active: true },
  { id: 'cat-3', name: 'Smartwatches', nameArabic: 'الساعات الذكية', description: 'Apple Watch Ultra, Galaxy Watch & Wearables', iconName: 'Watch', order: 3, active: true },
  { id: 'cat-4', name: 'Audio & Sound', nameArabic: 'الصوتيات والسمّاعات', description: 'AirPods, Wireless Earbuds & High-End Headphones', iconName: 'Headphones', order: 4, active: true },
  { id: 'cat-5', name: 'Accessories', nameArabic: 'الإكسسوارات والشواحن', description: 'GaN Fast Chargers, Power Banks & Leather Cases', iconName: 'BatteryCharging', order: 5, active: true },
  { id: 'cat-6', name: 'Luxury Editions', nameArabic: 'الإصدارات الفاخرة', description: '24K Gold Syria Edition Custom Flagships', iconName: 'Crown', order: 6, active: true },
  { id: 'cat-7', name: 'Repair Services', nameArabic: 'خدمات الصيانة الدقيقة', description: 'OLED Screens, Batteries & Micro-Soldering', iconName: 'Wrench', order: 7, active: true },
];

// Default Brands CMS
export const INITIAL_BRANDS: BrandCMS[] = [
  { id: 'b-1', name: 'Apple', logoUrl: 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=100&auto=format&fit=crop&q=80', description: 'Official Apple Imports & Verified Warranty', featured: true, active: true },
  { id: 'b-2', name: 'Samsung', logoUrl: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=100&auto=format&fit=crop&q=80', description: 'Galaxy Ultra & Z-Fold Series', featured: true, active: true },
  { id: 'b-3', name: 'Xiaomi', logoUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=100&auto=format&fit=crop&q=80', description: 'Flagships & Ultra Camera Phone Lineup', featured: true, active: true },
  { id: 'b-4', name: 'Google', logoUrl: 'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=100&auto=format&fit=crop&q=80', description: 'Pixel 9 Pro AI Flagships', featured: true, active: true },
  { id: 'b-5', name: 'Nothing', logoUrl: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=100&auto=format&fit=crop&q=80', description: 'Transparent Glyph Design Smartphones', featured: true, active: true },
  { id: 'b-6', name: 'Anker', logoUrl: 'https://images.unsplash.com/photo-1622445268465-84024680922c?w=100&auto=format&fit=crop&q=80', description: 'MagGo & GaN Prime High Speed Charging', featured: true, active: true },
];

// Default Sample Orders
export const INITIAL_ORDERS: Order[] = [
  {
    orderId: 'ELS-2026-8812',
    date: '2026-07-25T14:30:00.000Z',
    items: [
      {
        id: 'item-1',
        product: PRODUCTS[0], // iPhone 16 Pro Max
        selectedColor: PRODUCTS[0].colors[0],
        selectedStorage: '512GB',
        priceUSD: 1199,
        quantity: 1,
      },
      {
        id: 'item-2',
        product: PRODUCTS[8], // Anker Power Bank
        selectedColor: PRODUCTS[8].colors[0],
        priceUSD: 89,
        quantity: 1,
      }
    ],
    subtotalUSD: 1288,
    discountUSD: 50,
    shippingUSD: 0,
    totalUSD: 1238,
    currency: 'EGP',
    totalConvertedFormatted: '60,043 ج.م',
    status: 'Confirmed',
    customerInfo: {
      fullName: 'Mohamed Abdel-Rahman',
      email: 'm.abdelrahman@gmail.com',
      phone: '+20 101 234 5678',
      city: 'Zagazig',
      address: 'Villas El Gamea District, Near University Hospital, Zagazig',
      notes: 'Please call 30 mins before arrival.',
    },
    shippingMethod: 'Zagazig Express',
    paymentMethod: 'InstaPay / Vodafone Cash',
    trackingEvents: [
      { title: 'Order Placed & Verified', timestamp: '2026-07-25 14:30', location: 'ElSory Online Portal', completed: true },
      { title: 'Payment Confirmed via InstaPay', timestamp: '2026-07-25 14:35', location: 'ElSory Accounting Office', completed: true },
      { title: 'Packaged & Certified Hardware Inspection', timestamp: '2026-07-25 15:10', location: 'Zagazig Main Branch', completed: true, current: true },
      { title: 'Out for Express Delivery', timestamp: 'Pending', location: 'Zagazig District Courier', completed: false },
      { title: 'Delivered to Customer', timestamp: 'Pending', location: 'Customer Doorstep', completed: false },
    ],
  },
  {
    orderId: 'ELS-2026-8794',
    date: '2026-07-24T18:15:00.000Z',
    items: [
      {
        id: 'item-3',
        product: PRODUCTS[1], // Samsung S25 Ultra
        selectedColor: PRODUCTS[1].colors[0],
        selectedStorage: '512GB',
        priceUSD: 1299,
        quantity: 1,
      }
    ],
    subtotalUSD: 1299,
    discountUSD: 0,
    shippingUSD: 10,
    totalUSD: 1309,
    currency: 'EGP',
    totalConvertedFormatted: '63,486 ج.م',
    status: 'Out for Delivery',
    customerInfo: {
      fullName: 'Dr. Tarek El-Sayed',
      email: 'tarek.elsayed@khalifa.edu.eg',
      phone: '+20 122 889 0112',
      city: 'Cairo',
      address: 'New Cairo, Fifth Settlement, Block 4',
    },
    shippingMethod: 'Egypt Nationwide Courier',
    paymentMethod: 'Credit Card / Online',
    trackingEvents: [
      { title: 'Order Placed & Verified', timestamp: '2026-07-24 18:15', location: 'ElSory Portal', completed: true },
      { title: 'Payment Processed', timestamp: '2026-07-24 18:16', location: 'CIB Gateway', completed: true },
      { title: 'Dispatched via Express Logistics', timestamp: '2026-07-25 08:00', location: 'Sharqia Central Hub', completed: true },
      { title: 'Out for Delivery', timestamp: '2026-07-25 11:30', location: 'New Cairo Logistics Hub', completed: true, current: true },
      { title: 'Delivered to Customer', timestamp: 'Pending', location: 'Customer Address', completed: false },
    ],
  },
];

// Default Customers
export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    fullName: 'Mohamed Abdel-Rahman',
    email: 'm.abdelrahman@gmail.com',
    phone: '+20 101 234 5678',
    city: 'Zagazig',
    address: 'Villas El Gamea District, Near University Hospital, Zagazig',
    totalSpendUSD: 2437,
    ordersCount: 2,
    repairCount: 1,
    isBlocked: false,
    savedAddresses: ['Villas El Gamea, Zagazig', 'Al Qawmia Street, Zagazig'],
    wishlistProductIds: ['p-1', 'p-5'],
    createdAt: '2025-11-10T10:00:00.000Z',
    lastOrderDate: '2026-07-25T14:30:00.000Z',
  },
  {
    id: 'cust-2',
    fullName: 'Dr. Tarek El-Sayed',
    email: 'tarek.elsayed@khalifa.edu.eg',
    phone: '+20 122 889 0112',
    city: 'Cairo',
    address: 'New Cairo, Fifth Settlement, Block 4',
    totalSpendUSD: 1309,
    ordersCount: 1,
    repairCount: 0,
    isBlocked: false,
    savedAddresses: ['Fifth Settlement, New Cairo'],
    wishlistProductIds: ['p-2'],
    createdAt: '2026-01-15T12:00:00.000Z',
    lastOrderDate: '2026-07-24T18:15:00.000Z',
  },
  {
    id: 'cust-3',
    fullName: 'Yasmeen Farouk',
    email: 'yasmeen.farouk@yahoo.com',
    phone: '+20 114 556 7789',
    city: 'Zagazig',
    address: 'Al-Galaa Street, Zagazig',
    totalSpendUSD: 449,
    ordersCount: 1,
    repairCount: 2,
    isBlocked: false,
    savedAddresses: ['Al-Galaa Street, Zagazig'],
    wishlistProductIds: ['p-3', 'p-7'],
    createdAt: '2025-08-20T16:00:00.000Z',
    lastOrderDate: '2026-06-12T11:00:00.000Z',
  },
];

// Default Repair Bookings
export const INITIAL_REPAIR_BOOKINGS: RepairBooking[] = [
  {
    id: 'REP-2026-104',
    customerName: 'Eng. Khaled Al-Masri',
    phone: '+20 100 445 9901',
    deviceBrand: 'Apple',
    deviceModel: 'iPhone 15 Pro Max',
    issueType: 'Screen & OLED',
    preferredDate: '2026-07-26',
    estimatedCostEGP: 4100,
    status: 'Diagnosing',
  },
  {
    id: 'REP-2026-098',
    customerName: 'Hassan Mahmoud',
    phone: '+20 111 223 3445',
    deviceBrand: 'Samsung',
    deviceModel: 'Galaxy S23 Ultra',
    issueType: 'Original Battery',
    preferredDate: '2026-07-25',
    estimatedCostEGP: 1700,
    status: 'Ready for Pickup',
  },
  {
    id: 'REP-2026-092',
    customerName: 'Omnia Sherif',
    phone: '+20 102 334 5566',
    deviceBrand: 'Apple',
    deviceModel: 'iPhone 14 Pro',
    issueType: 'Back Glass Laser',
    preferredDate: '2026-07-24',
    estimatedCostEGP: 2200,
    status: 'Repairing',
  },
];

// Default Blog Posts
export const INITIAL_BLOG_POSTS: BlogPost[] = [
  {
    id: 'post-1',
    title: 'iPhone 16 Pro Max vs Galaxy S25 Ultra: The Ultimate Flagship Showdown',
    titleArabic: 'مقارنة بين آيفون 16 برو ماكس وسامسونج S25 ألترا: أيهما الأفضل لك؟',
    slug: 'iphone-16-pro-max-vs-galaxy-s25-ultra',
    author: 'Ammar ElSory',
    category: 'Comparisons',
    tags: ['Apple', 'Samsung', 'Flagship', 'Zagazig'],
    excerpt: 'An in-depth analysis of camera systems, OLED displays, thermal throttling, and battery benchmarks tested directly at ElSory Store.',
    content: `Choosing between Apple's flagship iPhone 16 Pro Max and Samsung's Galaxy S25 Ultra is one of the most significant decisions for smartphone enthusiasts in Egypt. At ElSory Store in Zagazig, we tested both devices side by side...`,
    imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80',
    publishedAt: '2026-07-20T10:00:00.000Z',
    published: true,
    seoTitle: 'iPhone 16 Pro Max vs Galaxy S25 Ultra | ElSory Store Zagazig',
    seoDescription: 'Detailed camera and battery comparison between iPhone 16 Pro Max and S25 Ultra in Egypt with local warranty details.',
  },
  {
    id: 'post-2',
    title: 'How TrueTone & Original Calibration Keep Your iPhone OLED Screen Flawless',
    titleArabic: 'كيف تحافظ شاشات OLED الأصلية وتقنية TrueTone على قيمة هاتفك',
    slug: 'truetone-original-oled-screen-replacement-guide',
    author: 'Eng. Ahmed Hassan',
    category: 'Hardware & Repair',
    tags: ['Repair', 'OLED', 'TrueTone', 'Apple'],
    excerpt: 'Why cheap third-party screen replacements ruin battery life and touch latency, and how our laser micro-soldering restores factory perfection.',
    content: `When your iPhone screen breaks, selecting a replacement involves more than just resolution. Counterfeit screens disable TrueTone and drain battery faster...`,
    imageUrl: 'https://images.unsplash.com/photo-1597740985671-2a8a3b80502e?w=800&auto=format&fit=crop&q=80',
    publishedAt: '2026-07-15T14:00:00.000Z',
    published: true,
    seoTitle: 'iPhone OLED Repair & TrueTone Restoration | ElSory Repair Center',
    seoDescription: 'Learn why certified original OLED screens and TrueTone programmer calibration are essential for iPhone repairs.',
  },
];

// Default Marketing Coupons
export const INITIAL_COUPONS: Coupon[] = [
  { id: 'c-1', code: 'ELSORY100', discountType: 'fixed', discountValue: 20, minOrderUSD: 300, expiryDate: '2026-12-31', usageCount: 42, maxUsage: 500, active: true },
  { id: 'c-2', code: 'ZAGAZIGVIP', discountType: 'percentage', discountValue: 5, minOrderUSD: 100, expiryDate: '2026-09-30', usageCount: 18, maxUsage: 200, active: true },
  { id: 'c-3', code: 'REPAIR2026', discountType: 'fixed', discountValue: 10, minOrderUSD: 50, expiryDate: '2026-12-31', usageCount: 89, maxUsage: 1000, active: true },
];

// Default Flash Sales
export const INITIAL_FLASH_SALES: FlashSale[] = [
  {
    id: 'fs-1',
    title: 'Zagazig Summer Flagship Extravaganza',
    titleArabic: 'عروض الصيف الكبرى للهواتف الرائدة في الزقازيق',
    discountPercent: 12,
    endDate: '2026-08-01T23:59:59.000Z',
    productIds: ['p-1', 'p-2', 'p-8'],
    active: true,
  }
];

// Default AI Knowledge Base Documents
export const INITIAL_AI_DOCS: AIDocument[] = [
  {
    id: 'doc-1',
    title: 'ElSory Store 1-Year Hardware & Software Warranty Policy',
    category: 'Warranty',
    content: 'ElSory Store provides a full 1-year store warranty covering factory defects, hardware failure, motherboard issues, and software corruption. Liquid damage and accidental drops require certified repair service.',
    uploadedAt: '2026-01-10T09:00:00.000Z',
    size: '14 KB',
    status: 'Indexed',
  },
  {
    id: 'doc-2',
    title: 'Zagazig Express Courier & Doorstep Pickup Protocols',
    category: 'Policy',
    content: 'Orders placed before 4 PM in Zagazig district are delivered within 2 hours. Doorstep pickup for repair devices includes video documentation and a digital receipt signed by the courier.',
    uploadedAt: '2026-02-01T11:00:00.000Z',
    size: '18 KB',
    status: 'Indexed',
  },
  {
    id: 'doc-3',
    title: 'Original TrueTone & OLED Screen Replacement Specs',
    category: 'Manual',
    content: 'All iPhone OLED screens installed at ElSory Repair Center use genuine OEM panels with IC chip transfer to preserve TrueTone and avoid Apple display warning messages.',
    uploadedAt: '2026-03-15T15:30:00.000Z',
    size: '22 KB',
    status: 'Indexed',
  },
];

// Default Homepage Section CMS Config
export const INITIAL_CMS_SECTIONS: HomepageSectionCMS[] = [
  { id: 'sec-1', sectionKey: 'hero', title: 'Hero Carousel & Flagship Banner', titleArabic: 'الواجهة الرئيسية والبانر الإعلاني', enabled: true, order: 1, config: { headline: 'ELSORY STORE', headlineArabic: 'السوري ستور', subtitle: 'Zagazig’s Premier Destination for Flagship Mobile Hardware, Custom Luxury Editions & Certified Express Repairs.', videoBg: true } },
  { id: 'sec-2', sectionKey: 'featured_products', title: 'Featured Products Grid', titleArabic: 'الأجهزة الممتازة والمختارة', enabled: true, order: 2, config: { limit: 8, badgeFilter: 'All' } },
  { id: 'sec-3', sectionKey: 'categories', title: 'Category Browser Pills', titleArabic: 'تصفح الأقسام والخدمات', enabled: true, order: 3, config: { displayMode: 'pills' } },
  { id: 'sec-4', sectionKey: 'brands', title: 'Brand Logos Showcase', titleArabic: 'العلامات التجارية والشركات', enabled: true, order: 4, config: { autoScroll: true } },
  { id: 'sec-5', sectionKey: 'repairs', title: 'Zagazig Express Repair Center', titleArabic: 'مركز الصيانة المعتمد في الزقازيق', enabled: true, order: 5, config: { highlightTimer: '45 Mins' } },
  { id: 'sec-6', sectionKey: 'exploded', title: 'Interactive Exploded Hardware View', titleArabic: 'عرض الهندسة الداخلية المضيء', enabled: true, order: 6, config: { defaultDevice: 'iPhone 16 Pro Max' } },
  { id: 'sec-7', sectionKey: 'offers', title: 'Exclusive Special Offers & Flash Sales', titleArabic: 'العروض الحصرية والتخفيضات', enabled: true, order: 7, config: { showTimer: true } },
  { id: 'sec-8', sectionKey: 'stats', title: 'Store Trust Statistics', titleArabic: 'إحصائيات وثقة العملاء', enabled: true, order: 8, config: { itemsCount: '15,000+ Happy Customers' } },
  { id: 'sec-9', sectionKey: 'faq', title: 'Frequently Asked Questions', titleArabic: 'الأسئلة الشائعة والمعلومات', enabled: true, order: 9, config: { defaultOpen: 0 } },
  { id: 'sec-10', sectionKey: 'reviews', title: 'Customer Reviews & Star Ratings', titleArabic: 'تقييمات وآراء العملاء', enabled: true, order: 10, config: { minStars: 4 } },
  { id: 'sec-11', sectionKey: 'newsletter', title: 'VIP Newsletter & WhatsApp Broadcast Signup', titleArabic: 'النشرة البريدية وخدمة الواتساب', enabled: true, order: 11, config: { discountOffer: '10%' } },
  { id: 'sec-12', sectionKey: 'footer', title: 'Store Footer & Locations Map', titleArabic: 'تذييل الموقع وخريطة الفروع', enabled: true, order: 12, config: { showMap: true } },
];

// Default Website Settings
export const INITIAL_SETTINGS: WebsiteSettings = {
  storeName: 'ElSory Store',
  storeNameArabic: 'السوري ستور',
  tagline: 'Flagship Mobile Hardware & Express Repair Center',
  taglineArabic: 'المركز الأول للهواتف الذكية والصيانة المعتمدة بالزقازيق',
  logoUrl: 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=120&auto=format&fit=crop&q=80',
  faviconUrl: 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=32&auto=format&fit=crop&q=80',
  phone: '+20 101 234 5678',
  whatsappPhone: '+20 101 234 5678',
  email: 'info@elsory.com',
  address: 'Villas El Gamea District, Al Qawmia, Zagazig, Sharqia Governorate, Egypt',
  addressArabic: 'حي فيلات الجامعة، القومية، الزقازيق، محافظة الشرقية، مصر',
  googleMapEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3437.123!2d31.5!3d30.58!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1',
  latitude: 30.587,
  longitude: 31.502,
  businessHours: 'Open Daily: 10:00 AM – 11:30 PM (Friday: 1:30 PM – 11:30 PM)',
  facebookUrl: 'https://facebook.com/elsory.store',
  instagramUrl: 'https://instagram.com/elsory.store',
  tiktokUrl: 'https://tiktok.com/@elsory.store',
  youtubeUrl: 'https://youtube.com/@elsory.store',
  currency: 'EGP',
  languages: ['en', 'ar'],
  shippingFeeUSD: 10,
  freeShippingThresholdUSD: 500,
  taxRatePercent: 0,
  enableVodafoneCash: true,
  enableInstaPay: true,
  enableValu: true,
  enableCIB: true,
  enableCOD: true,
  maintenanceMode: false,
};

// Default Initial Audit Logs
export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    userEmail: 'admin@elsory.com',
    userName: 'Ammar ElSory',
    userRole: 'Super Admin',
    action: 'System Login',
    module: 'Authentication',
    details: 'Admin session authenticated successfully with 2FA verification.',
    ipAddress: '197.35.112.48',
  },
  {
    id: 'log-2',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    userEmail: 'admin@elsory.com',
    userName: 'Ammar ElSory',
    userRole: 'Super Admin',
    action: 'Product Updated',
    module: 'Product CMS',
    details: 'Updated inventory status and specifications for iPhone 16 Pro Max.',
    ipAddress: '197.35.112.48',
  },
  {
    id: 'log-3',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    userEmail: 'sales@elsory.com',
    userName: 'Karim Mahmoud',
    userRole: 'Sales',
    action: 'Order Confirmed',
    module: 'Order Management',
    details: 'Confirmed payment for Order ELS-2026-8812 via InstaPay.',
    ipAddress: '41.233.19.102',
  },
];

// LocalStorage Persistence Keys
export const INITIAL_LEADS: CustomerLead[] = [
  {
    id: 'lead-101',
    name: 'Mohamed Abdel-Rahman',
    phone: '+20 101 234 5678',
    messageSummary: 'Inquired about iPhone 16 Pro Max 256GB Desert Titanium availability and trade-in price for iPhone 14 Pro.',
    source: 'AI Assistant',
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    status: 'New',
  },
  {
    id: 'lead-102',
    name: 'Youssef Mahmoud',
    phone: '+20 112 987 6543',
    messageSummary: 'Asked for genuine screen replacement quote for Galaxy S24 Ultra in Zagazig store.',
    source: 'Repair Quote',
    timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
    status: 'Contacted',
  },
];

const KEYS = {
  PRODUCTS: 'elsory_admin_products',
  CATEGORIES: 'elsory_admin_categories',
  BRANDS: 'elsory_admin_brands',
  ORDERS: 'elsory_admin_orders',
  CUSTOMERS: 'elsory_admin_customers',
  REPAIRS: 'elsory_admin_repairs',
  BLOG: 'elsory_admin_blog',
  COUPONS: 'elsory_admin_coupons',
  FLASH_SALES: 'elsory_admin_flash_sales',
  AI_DOCS: 'elsory_admin_ai_docs',
  CMS_SECTIONS: 'elsory_admin_cms_sections',
  SETTINGS: 'elsory_admin_settings',
  ADMIN_USERS: 'elsory_admin_users',
  PERMISSIONS: 'elsory_admin_permissions',
  AUDIT_LOGS: 'elsory_admin_audit_logs',
  CURRENT_USER: 'elsory_admin_current_user',
  PENDING_AI_APPROVALS: 'elsory_admin_pending_ai_approvals',
  LEADS: 'elsory_admin_customer_leads',
};

// Helper function to read from localStorage with fallback
function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch (err) {
    console.warn(`Error loading ${key} from localStorage:`, err);
    return fallback;
  }
}

// Helper function to write to localStorage
function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error saving ${key} to localStorage:`, err);
  }
}

// Class-based Central Enterprise Admin Store
class AdminStore {
  // State variables
  private products: Product[];
  private categories: CategoryCMS[];
  private brands: BrandCMS[];
  private orders: Order[];
  private customers: Customer[];
  private repairs: RepairBooking[];
  private blogPosts: BlogPost[];
  private coupons: Coupon[];
  private flashSales: FlashSale[];
  private aiDocs: AIDocument[];
  private cmsSections: HomepageSectionCMS[];
  private settings: WebsiteSettings;
  private adminUsers: AdminUser[];
  private rolePermissions: RolePermissionMatrix;
  private auditLogs: AuditLog[];
  private currentUser: AdminUser | null;
  private pendingAIApprovals: any[];
  private leads: CustomerLead[];
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.products = loadFromStorage(KEYS.PRODUCTS, PRODUCTS);
    this.categories = loadFromStorage(KEYS.CATEGORIES, INITIAL_CATEGORIES);
    this.brands = loadFromStorage(KEYS.BRANDS, INITIAL_BRANDS);
    this.orders = loadFromStorage(KEYS.ORDERS, INITIAL_ORDERS);
    this.customers = loadFromStorage(KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    this.repairs = loadFromStorage(KEYS.REPAIRS, INITIAL_REPAIR_BOOKINGS);
    this.blogPosts = loadFromStorage(KEYS.BLOG, INITIAL_BLOG_POSTS);
    this.coupons = loadFromStorage(KEYS.COUPONS, INITIAL_COUPONS);
    this.flashSales = loadFromStorage(KEYS.FLASH_SALES, INITIAL_FLASH_SALES);
    this.aiDocs = loadFromStorage(KEYS.AI_DOCS, INITIAL_AI_DOCS);
    this.cmsSections = loadFromStorage(KEYS.CMS_SECTIONS, INITIAL_CMS_SECTIONS);
    this.settings = loadFromStorage(KEYS.SETTINGS, INITIAL_SETTINGS);
    this.adminUsers = loadFromStorage(KEYS.ADMIN_USERS, INITIAL_ADMIN_USERS);
    this.rolePermissions = loadFromStorage(KEYS.PERMISSIONS, DEFAULT_ROLE_PERMISSIONS);
    this.auditLogs = loadFromStorage(KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
    this.currentUser = loadFromStorage(KEYS.CURRENT_USER, INITIAL_ADMIN_USERS[0]);
    this.leads = loadFromStorage(KEYS.LEADS, INITIAL_LEADS);
    this.pendingAIApprovals = loadFromStorage(KEYS.PENDING_AI_APPROVALS, [
      {
        id: 'ai-app-1',
        type: 'product_draft',
        title: 'New Product Entry: Samsung Galaxy S25 Ultra 512GB Titanium Black',
        description: 'Auto-detected from uploaded device photos. Title, bilingual descriptions, specifications, and SEO tags generated.',
        suggestedPlacement: ['Featured Products', 'Latest Arrivals', 'Samsung Category'],
        payload: {
          id: 'p-s25u-ai',
          name: 'Samsung Galaxy S25 Ultra 512GB Titanium Black',
          nameArabic: 'سامسونج جالاكسي S25 ألترا 512 جيجابايت أسود تيتانيوم',
          brand: 'Samsung',
          category: 'Smartphones',
          badge: 'New Arrival',
          priceUSD: 1299,
          originalPriceUSD: 1399,
          rating: 5.0,
          reviewsCount: 1,
          images: [
            'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=800&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&auto=format&fit=crop&q=80'
          ],
          colors: [
            { name: 'Titanium Black', hex: '#1c1c1e' },
            { name: 'Titanium Gray', hex: '#7c7c80' }
          ],
          storageOptions: [
            { size: '256GB', priceUSD: 1199 },
            { size: '512GB', priceUSD: 1299 }
          ],
          shortDescription: 'Galaxy AI powered flagship with Snapdragon 8 Elite, 200MP Quad Camera, and built-in S-Pen.',
          shortDescriptionArabic: 'هاتف سامسونج الرائد المزود بذكاء Galaxy AI، معالج سنابدراجون 8 إيليت، وقلم S-Pen مدمج.',
          fullDescription: 'Experience the cutting-edge Samsung Galaxy S25 Ultra. Engineered with ultra-durable Titanium frame, Corning Gorilla Armor 2, and AI Zoom.',
          fullDescriptionArabic: 'استمتع بقوة الهاتف الرائد سامسونج جالاكسي S25 ألترا. هيكل من التيتانيوم، حماية جوريلا أرمور، وكاميرا 200 ميجابكسل فائقة الوضوح.',
          specifications: {
            display: '6.8" Dynamic AMOLED 2X 120Hz',
            processor: 'Snapdragon 8 Elite for Galaxy',
            camera: '200MP + 50MP Periscope 5x + 50MP Ultra-Wide',
            battery: '5000 mAh 45W Fast Charging',
            os: 'One UI 7.0 (7 Years Android OS Updates)'
          },
          warrantyYears: 1,
          inStock: true,
          stockQuantity: 12,
          sku: 'S25U-512GB-BLK',
          seoTitle: 'Samsung Galaxy S25 Ultra Egypt Price | ElSory Store Zagazig',
          seoDescription: 'Buy official Samsung S25 Ultra in Zagazig with 1-Year Warranty & InstaPay Installments.'
        },
        createdAt: new Date().toISOString(),
        status: 'Pending'
      },
      {
        id: 'ai-app-2',
        type: 'marketing_campaign',
        title: 'WhatsApp Broadcast Campaign: Weekend Flagship Accessories Flash Sale',
        description: 'Targeted broadcast message for local Zagazig clients offering 15% discount on GaN chargers & Hydrogel guards.',
        payload: {
          channel: 'WhatsApp Broadcast & Social Media',
          headline: '🚀 عروض عطلة نهاية الأسبوع من السوري ستور بالزقازيق!',
          messageBody: 'احصل على خصم 15% على جميع شواحن أنكر الأصلية وشاشات الحماية عند شراء أي هاتف آيفون أو سامسونج رائد! اطلب الآن عبر الواتساب مع خدمة التوصيل السريع لجميع أنحاء الزقازيق خلال 60 دقيقة.',
          targetAudience: 'Registered Zagazig Customers & Active Buyers',
          estimatedReach: '2,400 Customers in Sharqia'
        },
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        status: 'Pending'
      }
    ]);
  }

  // Subscribe to changes
  public subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  // Add Audit Log Entry
  public addAuditLog(action: string, module: string, details: string) {
    const newLog: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userEmail: this.currentUser?.email || 'admin@elsory.com',
      userName: this.currentUser?.name || 'Admin User',
      userRole: this.currentUser?.role || 'Super Admin',
      action,
      module,
      details,
      ipAddress: '197.35.112.48 (Zagazig, EG)',
    };
    this.auditLogs = [newLog, ...this.auditLogs];
    saveToStorage(KEYS.AUDIT_LOGS, this.auditLogs);
    this.notify();
  }

  // Auth Methods
  public getCurrentUser() { return this.currentUser; }
  public setCurrentUser(user: AdminUser | null) {
    this.currentUser = user;
    saveToStorage(KEYS.CURRENT_USER, user);
    if (user) {
      this.addAuditLog('User Login', 'Authentication', `Admin user ${user.email} authenticated.`);
    }
    this.notify();
  }
  public getRolePermissions() { return this.rolePermissions; }
  public updateRolePermissions(matrix: RolePermissionMatrix) {
    this.rolePermissions = matrix;
    saveToStorage(KEYS.PERMISSIONS, matrix);
    this.addAuditLog('Permissions Matrix Updated', 'RBAC & Roles', 'Customized access permissions matrix across roles.');
    this.notify();
  }
  public getAdminUsers() { return this.adminUsers; }
  public saveAdminUser(user: AdminUser) {
    const idx = this.adminUsers.findIndex((u) => u.id === user.id);
    if (idx >= 0) {
      this.adminUsers[idx] = user;
    } else {
      this.adminUsers.push(user);
    }
    saveToStorage(KEYS.ADMIN_USERS, this.adminUsers);
    this.addAuditLog('Admin User Saved', 'User Management', `Saved admin profile for ${user.email} (${user.role}).`);
    this.notify();
  }
  public deleteAdminUser(id: string) {
    this.adminUsers = this.adminUsers.filter((u) => u.id !== id);
    saveToStorage(KEYS.ADMIN_USERS, this.adminUsers);
    this.addAuditLog('Admin User Deleted', 'User Management', `Removed admin user account ID ${id}.`);
    this.notify();
  }

  // Permission Check Helper
  public hasPermission(permission: PermissionKey): boolean {
    if (!this.currentUser) return false;
    const role = this.currentUser.role;
    const rolePerms = this.rolePermissions[role];
    if (!rolePerms) return false;
    return !!rolePerms[permission];
  }

  // Product CRUD
  public getProducts() { return this.products; }
  public saveProduct(product: Product) {
    const idx = this.products.findIndex((p) => p.id === product.id);
    if (idx >= 0) {
      this.products[idx] = product;
      this.addAuditLog('Product Updated', 'Product CMS', `Updated product details for ${product.name} (SKU: ${product.sku || product.id}).`);
    } else {
      this.products = [product, ...this.products];
      this.addAuditLog('Product Created', 'Product CMS', `Created new product ${product.name} ($${product.priceUSD}).`);
    }
    saveToStorage(KEYS.PRODUCTS, this.products);
    this.notify();
  }
  public deleteProduct(id: string) {
    const p = this.products.find((prod) => prod.id === id);
    this.products = this.products.filter((prod) => prod.id !== id);
    saveToStorage(KEYS.PRODUCTS, this.products);
    this.addAuditLog('Product Deleted', 'Product CMS', `Deleted product ${p?.name || id} from catalog.`);
    this.notify();
  }
  public duplicateProduct(id: string) {
    const p = this.products.find((prod) => prod.id === id);
    if (!p) return;
    const dup: Product = {
      ...JSON.parse(JSON.stringify(p)),
      id: `p-copy-${Date.now()}`,
      name: `${p.name} (Copy)`,
      sku: p.sku ? `${p.sku}-COPY` : undefined,
    };
    this.products = [dup, ...this.products];
    saveToStorage(KEYS.PRODUCTS, this.products);
    this.addAuditLog('Product Duplicated', 'Product CMS', `Duplicated product ${p.name} into ${dup.name}.`);
    this.notify();
  }

  // Category & Brand CRUD
  public getCategories() { return this.categories; }
  public saveCategory(cat: CategoryCMS) {
    const idx = this.categories.findIndex((c) => c.id === cat.id);
    if (idx >= 0) this.categories[idx] = cat;
    else this.categories.push(cat);
    saveToStorage(KEYS.CATEGORIES, this.categories);
    this.addAuditLog('Category Saved', 'Categories CMS', `Saved category ${cat.name}.`);
    this.notify();
  }
  public deleteCategory(id: string) {
    this.categories = this.categories.filter((c) => c.id !== id);
    saveToStorage(KEYS.CATEGORIES, this.categories);
    this.notify();
  }
  public getBrands() { return this.brands; }
  public saveBrand(brand: BrandCMS) {
    const idx = this.brands.findIndex((b) => b.id === brand.id);
    if (idx >= 0) this.brands[idx] = brand;
    else this.brands.push(brand);
    saveToStorage(KEYS.BRANDS, this.brands);
    this.addAuditLog('Brand Saved', 'Brand CMS', `Saved brand ${brand.name}.`);
    this.notify();
  }
  public deleteBrand(id: string) {
    this.brands = this.brands.filter((b) => b.id !== id);
    saveToStorage(KEYS.BRANDS, this.brands);
    this.notify();
  }

  // Orders CRUD
  public getOrders() { return this.orders; }
  public updateOrderStatus(orderId: string, status: Order['status']) {
    const o = this.orders.find((ord) => ord.orderId === orderId);
    if (o) {
      o.status = status;
      o.trackingEvents.push({
        title: `Status Updated to ${status}`,
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
        location: 'ElSory Admin Control Center',
        completed: true,
        current: true,
      });
      saveToStorage(KEYS.ORDERS, this.orders);
      this.addAuditLog('Order Status Updated', 'Order Management', `Updated order ${orderId} status to ${status}.`);
      this.notify();
    }
  }

  // Customers CRM
  public getCustomers() { return this.customers; }
  public toggleBlockCustomer(id: string) {
    const c = this.customers.find((cust) => cust.id === id);
    if (c) {
      c.isBlocked = !c.isBlocked;
      saveToStorage(KEYS.CUSTOMERS, this.customers);
      this.addAuditLog('Customer Block Toggle', 'Customer CRM', `${c.isBlocked ? 'Blocked' : 'Unblocked'} customer ${c.fullName}.`);
      this.notify();
    }
  }

  // Repair Management
  public getRepairs() { return this.repairs; }
  public saveRepair(repair: RepairBooking) {
    const idx = this.repairs.findIndex((r) => r.id === repair.id);
    if (idx >= 0) this.repairs[idx] = repair;
    else this.repairs.unshift(repair);
    saveToStorage(KEYS.REPAIRS, this.repairs);
    this.addAuditLog('Repair Updated', 'Repair Center', `Updated repair ticket ${repair.id} (${repair.status}).`);
    this.notify();
  }

  // Blog CMS
  public getBlogPosts() { return this.blogPosts; }
  public saveBlogPost(post: BlogPost) {
    const idx = this.blogPosts.findIndex((p) => p.id === post.id);
    if (idx >= 0) this.blogPosts[idx] = post;
    else this.blogPosts.unshift(post);
    saveToStorage(KEYS.BLOG, this.blogPosts);
    this.addAuditLog('Blog Post Saved', 'Blog CMS', `Saved blog article ${post.title}.`);
    this.notify();
  }
  public deleteBlogPost(id: string) {
    this.blogPosts = this.blogPosts.filter((p) => p.id !== id);
    saveToStorage(KEYS.BLOG, this.blogPosts);
    this.notify();
  }

  // Marketing Coupons & Flash Sales
  public getCoupons() { return this.coupons; }
  public saveCoupon(coupon: Coupon) {
    const idx = this.coupons.findIndex((c) => c.id === coupon.id);
    if (idx >= 0) this.coupons[idx] = coupon;
    else this.coupons.unshift(coupon);
    saveToStorage(KEYS.COUPONS, this.coupons);
    this.addAuditLog('Coupon Saved', 'Marketing', `Saved coupon code ${coupon.code}.`);
    this.notify();
  }
  public deleteCoupon(id: string) {
    this.coupons = this.coupons.filter((c) => c.id !== id);
    saveToStorage(KEYS.COUPONS, this.coupons);
    this.notify();
  }
  public getFlashSales() { return this.flashSales; }
  public saveFlashSale(sale: FlashSale) {
    const idx = this.flashSales.findIndex((f) => f.id === sale.id);
    if (idx >= 0) this.flashSales[idx] = sale;
    else this.flashSales.unshift(sale);
    saveToStorage(KEYS.FLASH_SALES, this.flashSales);
    this.notify();
  }

  // AI Knowledge Base
  public getAIDocs() { return this.aiDocs; }
  public saveAIDoc(doc: AIDocument) {
    const idx = this.aiDocs.findIndex((d) => d.id === doc.id);
    if (idx >= 0) this.aiDocs[idx] = doc;
    else this.aiDocs.unshift(doc);
    saveToStorage(KEYS.AI_DOCS, this.aiDocs);
    this.addAuditLog('AI Knowledge Doc Added', 'AI Management', `Indexed document ${doc.title}.`);
    this.notify();
  }
  public deleteAIDoc(id: string) {
    this.aiDocs = this.aiDocs.filter((d) => d.id !== id);
    saveToStorage(KEYS.AI_DOCS, this.aiDocs);
    this.notify();
  }

  // Pending AI Approvals Workflow Queue
  public getPendingAIApprovals() { return this.pendingAIApprovals; }
  public addPendingAIApproval(approval: any) {
    this.pendingAIApprovals = [approval, ...this.pendingAIApprovals];
    saveToStorage(KEYS.PENDING_AI_APPROVALS, this.pendingAIApprovals);
    this.addAuditLog('AI Proposal Generated', 'AI Management', `Created AI pending approval for ${approval.title}`);
    this.notify();
  }
  public approveAIProposal(id: string) {
    const item = this.pendingAIApprovals.find((a) => a.id === id);
    if (!item) return;

    if (item.type === 'product_draft' && item.payload) {
      this.saveProduct(item.payload);
    }

    this.pendingAIApprovals = this.pendingAIApprovals.filter((a) => a.id !== id);
    saveToStorage(KEYS.PENDING_AI_APPROVALS, this.pendingAIApprovals);
    this.addAuditLog('AI Proposal Approved', 'AI Management', `Admin approved and executed AI proposal: ${item.title}`);
    this.notify();
  }
  public rejectAIProposal(id: string) {
    const item = this.pendingAIApprovals.find((a) => a.id === id);
    this.pendingAIApprovals = this.pendingAIApprovals.filter((a) => a.id !== id);
    saveToStorage(KEYS.PENDING_AI_APPROVALS, this.pendingAIApprovals);
    if (item) {
      this.addAuditLog('AI Proposal Rejected', 'AI Management', `Admin rejected AI proposal: ${item.title}`);
    }
    this.notify();
  }

  // Homepage CMS
  public getCMSSections() { return this.cmsSections; }
  public updateCMSSections(sections: HomepageSectionCMS[]) {
    this.cmsSections = sections;
    saveToStorage(KEYS.CMS_SECTIONS, sections);
    this.addAuditLog('Homepage Layout Saved', 'Homepage CMS', 'Reordered and customized homepage section visibility and content.');
    this.notify();
  }

  // Website Settings
  public getSettings() { return this.settings; }
  public updateSettings(settings: WebsiteSettings) {
    this.settings = settings;
    saveToStorage(KEYS.SETTINGS, settings);
    this.addAuditLog('Website Settings Saved', 'Settings', 'Updated global store information, contact numbers, and currency configurations.');
    this.notify();
  }

  // Audit Logs
  public getAuditLogs() { return this.auditLogs; }

  // Backup & Restore
  public exportFullBackupJSON(): string {
    const backup = {
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      products: this.products,
      categories: this.categories,
      brands: this.brands,
      orders: this.orders,
      customers: this.customers,
      repairs: this.repairs,
      blogPosts: this.blogPosts,
      coupons: this.coupons,
      flashSales: this.flashSales,
      aiDocs: this.aiDocs,
      cmsSections: this.cmsSections,
      settings: this.settings,
      adminUsers: this.adminUsers,
      rolePermissions: this.rolePermissions,
      auditLogs: this.auditLogs,
    };
    this.addAuditLog('Database Backup Exported', 'Backups & Security', 'Exported full JSON system backup.');
    return JSON.stringify(backup, null, 2);
  }

  public importFullBackupJSON(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.products) { this.products = data.products; saveToStorage(KEYS.PRODUCTS, this.products); }
      if (data.categories) { this.categories = data.categories; saveToStorage(KEYS.CATEGORIES, this.categories); }
      if (data.brands) { this.brands = data.brands; saveToStorage(KEYS.BRANDS, this.brands); }
      if (data.orders) { this.orders = data.orders; saveToStorage(KEYS.ORDERS, this.orders); }
      if (data.customers) { this.customers = data.customers; saveToStorage(KEYS.CUSTOMERS, this.customers); }
      if (data.repairs) { this.repairs = data.repairs; saveToStorage(KEYS.REPAIRS, this.repairs); }
      if (data.blogPosts) { this.blogPosts = data.blogPosts; saveToStorage(KEYS.BLOG, this.blogPosts); }
      if (data.coupons) { this.coupons = data.coupons; saveToStorage(KEYS.COUPONS, this.coupons); }
      if (data.aiDocs) { this.aiDocs = data.aiDocs; saveToStorage(KEYS.AI_DOCS, this.aiDocs); }
      if (data.cmsSections) { this.cmsSections = data.cmsSections; saveToStorage(KEYS.CMS_SECTIONS, this.cmsSections); }
      if (data.settings) { this.settings = data.settings; saveToStorage(KEYS.SETTINGS, this.settings); }
      if (data.adminUsers) { this.adminUsers = data.adminUsers; saveToStorage(KEYS.ADMIN_USERS, this.adminUsers); }
      if (data.rolePermissions) { this.rolePermissions = data.rolePermissions; saveToStorage(KEYS.PERMISSIONS, this.rolePermissions); }

      this.addAuditLog('Database Backup Restored', 'Backups & Security', 'Successfully imported system state from JSON backup.');
      this.notify();
      return true;
    } catch (err) {
      console.error('Failed to import backup JSON:', err);
      return false;
    }
  }

  // Customer Leads Management
  public getLeads(): CustomerLead[] {
    return this.leads;
  }

  public addLead(lead: Omit<CustomerLead, 'id' | 'timestamp' | 'status'> & { timestamp?: string; status?: CustomerLead['status'] }) {
    const newLead: CustomerLead = {
      id: `lead-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: lead.name,
      phone: lead.phone,
      messageSummary: lead.messageSummary,
      source: lead.source,
      timestamp: lead.timestamp || new Date().toISOString(),
      status: lead.status || 'New',
    };
    this.leads = [newLead, ...this.leads];
    saveToStorage(KEYS.LEADS, this.leads);
    this.addAuditLog('New Customer Lead Saved', 'Leads', `Captured lead from ${lead.name} (${lead.phone}) via ${lead.source}`);
    this.notify();
    return newLead;
  }

  public updateLeadStatus(id: string, status: CustomerLead['status']) {
    this.leads = this.leads.map((l) => (l.id === id ? { ...l, status } : l));
    saveToStorage(KEYS.LEADS, this.leads);
    this.notify();
  }

  public deleteLead(id: string) {
    this.leads = this.leads.filter((l) => l.id !== id);
    saveToStorage(KEYS.LEADS, this.leads);
    this.notify();
  }

  // Reset to Factory Default
  public resetToDefault() {
    localStorage.clear();
    this.products = PRODUCTS;
    this.categories = INITIAL_CATEGORIES;
    this.brands = INITIAL_BRANDS;
    this.orders = INITIAL_ORDERS;
    this.customers = INITIAL_CUSTOMERS;
    this.repairs = INITIAL_REPAIR_BOOKINGS;
    this.blogPosts = INITIAL_BLOG_POSTS;
    this.coupons = INITIAL_COUPONS;
    this.flashSales = INITIAL_FLASH_SALES;
    this.aiDocs = INITIAL_AI_DOCS;
    this.cmsSections = INITIAL_CMS_SECTIONS;
    this.settings = INITIAL_SETTINGS;
    this.adminUsers = INITIAL_ADMIN_USERS;
    this.rolePermissions = DEFAULT_ROLE_PERMISSIONS;
    this.auditLogs = INITIAL_AUDIT_LOGS;
    this.currentUser = INITIAL_ADMIN_USERS[0];
    this.leads = INITIAL_LEADS;
    this.notify();
  }
}

export const adminStore = new AdminStore();
