let cachedCsrfToken: string | null = null;

/**
 * Fetches or retrieves the CSRF token from the server
 */
export async function getCsrfToken(): Promise<string> {
  if (cachedCsrfToken) return cachedCsrfToken;

  try {
    const res = await fetch('/api/csrf-token');
    const data = await res.json();
    if (data && data.csrfToken) {
      cachedCsrfToken = data.csrfToken;
      return data.csrfToken;
    }
  } catch (err) {
    console.warn('Failed to retrieve CSRF token:', err);
  }
  return '';
}

/**
 * Wrapper over native fetch that automatically injects CSRF headers
 * for state-changing HTTP methods (POST, PUT, DELETE, PATCH).
 */
export async function safeFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const method = (options.method || 'GET').toUpperCase();
  const headers = new Headers(options.headers || {});

  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    const token = await getCsrfToken();
    if (token) {
      headers.set('X-CSRF-Token', token);
    }
  }

  let response = await fetch(url, {
    ...options,
    headers,
  });

  // If request failed with 403 (e.g. CSRF token expired), attempt token refresh once
  if (response.status === 403 && !['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    cachedCsrfToken = null;
    const newToken = await getCsrfToken();
    if (newToken) {
      headers.set('X-CSRF-Token', newToken);
      response = await fetch(url, {
        ...options,
        headers,
      });
    }
  }

  return response;
}
