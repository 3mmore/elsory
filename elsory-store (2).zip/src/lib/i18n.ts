import { Language, Category } from '../types';

export const translations = {
  en: {
    // Brand & Tagline
    storeName: 'ELSORY STORE',
    storeNameArabic: '(السوري ستور)',
    tagline: 'Zagazig • Flagships & Mobile Repair Center',
    locationNotice: 'Egypt • Zagazig • Villas El Gamea District',
    topWarrantyNotice: '100% Original Products & Official 1-Year Store Warranty',
    topShippingNotice: 'Zagazig Express Delivery & Egypt Nationwide Shipping',
    
    // Actions & Nav
    repairCenter: 'Mobile Repair Center',
    tradeIn: 'Trade-In',
    trackOrder: 'Track Order',
    aiAssistant: 'AI Store Assistant',
    compare: 'Compare',
    bag: 'Bag',
    lightMode: 'Light Mode',
    darkMode: 'Dark Mode',
    searchPlaceholder: 'Search iPhone 16 Pro Max, Galaxy S25 Ultra, Screen Repair, Batteries...',
    categoriesTitle: 'Categories',
    allBrands: 'All Brands',
    brandFilter: 'Brand',

    // Categories
    catAll: 'All',
    catSmartphones: 'Smartphones',
    catTablets: 'Tablets',
    catSmartwatches: 'Smartwatches',
    catAudio: 'Audio & Sound',
    catAccessories: 'Accessories',
    catLuxury: 'Luxury Editions',
    catRepair: 'Repair Services',

    // Hero & Badges
    heroTitlePrefix: 'THE ULTIMATE',
    heroTitleSuffix: 'MOBILE EXPERIENCE',
    heroSubtitle: 'Discover flagship smartphones, custom 24K luxury editions, genuine accessories, and certified micro-repair services in Zagazig.',
    exploreCatalog: 'Explore Catalog',
    bookRepair: 'Book Repair Service',
    expressShipping: 'Express Delivery',
    tradeInReady: 'Trade-In Ready',
    certifiedTechnicians: 'Certified Technicians',
    flagship: 'Flagship',
    inStock: 'In Stock',
    outOfStock: 'Out of Stock',
    addToCart: 'Add to Cart',
    addedToCart: 'Added to Bag',
    viewDetails: 'View Details',
    quickView: 'Quick View',

    // Language Toggle
    langSwitchName: 'العربية',

    // AI Modal
    aiModalTitle: 'ElSory Store AI Concierge',
    aiModalSubtitle: 'Powered by real inventory & Zagazig repair specialist knowledge base.',
    aiAskPlaceholder: 'Ask about devices, specs comparison, repair costs, or warranty...',

    // Admin Dashboard
    adminDashboardTitle: 'AI Analytics & Executive Store Dashboard',
    adminSubtitle: 'Real-time customer demand, search trends, and inventory insights.',
    searchedProducts: 'Most Searched Products',
    requestedBrands: 'Most Demanded Brands',
    requestedRepairs: 'Most Inquired Repairs',
    unfulfilledRequests: 'Out-of-Stock Demand',
    conversionRate: 'Conversion Rate',
    totalConversations: 'AI Assistant Sessions',
    
    // Product Details
    warrantyInfo: 'Official 1-Year Store Warranty',
    selectColor: 'Select Color',
    selectStorage: 'Select Storage',
    specifications: 'Specifications',
    keyFeatures: 'Key Features',
    quickOrderWhatsApp: 'Quick Order via WhatsApp',
    orderCartWhatsApp: 'Order Bag via WhatsApp',
    
    // Checkout & Cart
    cartTitle: 'Your Shopping Bag',
    subtotal: 'Subtotal',
    checkout: 'Proceed to Checkout',
    emptyCart: 'Your bag is empty',
    orderTotal: 'Order Total',
    placeOrder: 'Confirm & Place Order',
    
    // Footer & Locations
    locationTitle: 'ElSory Store Headquarters',
    locationAddress: 'Villas El Gamea District, Al Qawmia, Zagazig, Sharqia Governorate, Egypt',
    phoneContact: '+20 10 1234 5678',
    whatsappContact: '+20 10 9876 5432',
  },
  ar: {
    // Brand & Tagline
    storeName: 'السوري ستور',
    storeNameArabic: 'ELSORY STORE',
    tagline: 'الزقازيق • الهواتف الذكية ومركز صيانة الموبايل المعتمد',
    locationNotice: 'مصر • الزقازيق • حي فلل الجامعة - القومية',
    topWarrantyNotice: 'منتجات أصلية 100% وضمان معتمد لمدة سنة من المحل',
    topShippingNotice: 'توصيل سريع بالزقازيق وشحن لكافة محافظات مصر',
    
    // Actions & Nav
    repairCenter: 'مركز صيانة الموبايل',
    tradeIn: 'استبدال جهازك',
    trackOrder: 'تتبع الطلب',
    aiAssistant: 'المساعد الذكي للمحل',
    compare: 'المقارنة',
    bag: 'حقيبة التسوق',
    lightMode: 'الوضع الفاتح',
    darkMode: 'الوضع الداكن',
    searchPlaceholder: 'ابحث عن آيفون 16 برو ماكس، سامسونج S25، تغير شاشة، بطارية أصلية...',
    categoriesTitle: 'الأقسام الرئيسية',
    allBrands: 'جميع الماركات',
    brandFilter: 'الماركة',

    // Categories
    catAll: 'الكل',
    catSmartphones: 'الهواتف الذكية',
    catTablets: 'الأجهزة اللوحية',
    catSmartwatches: 'الساعات الذكية',
    catAudio: 'الصوتيات والسماعات',
    catAccessories: 'الإكسسوارات',
    catLuxury: 'الإصدارات الفاخرة',
    catRepair: 'خدمات الصيانة الممتازة',

    // Hero & Badges
    heroTitlePrefix: 'التجربة الأرقى عالمياً في',
    heroTitleSuffix: 'عالم الهواتف الذكية',
    heroSubtitle: 'اكتشف أحدث الهواتف الفلاغشيب، الإصدارات الذهبية الفاخرة، الإكسسوارات الأصلية، وخدمات الصيانة الدقيقة بالزقازيق.',
    exploreCatalog: 'تصفح المنتجات',
    bookRepair: 'حجز صيانة سريعة',
    expressShipping: 'توصيل فورى',
    tradeInReady: 'خدمة البدل فورية',
    certifiedTechnicians: 'مهندسون معتمدون',
    flagship: 'الراية الأولى',
    inStock: 'متوفر بالمحل',
    outOfStock: 'غير متوفر حالياً',
    addToCart: 'إضافة للحقيبة',
    addedToCart: 'تمت الإضافة بنجاح',
    viewDetails: 'التفاصيل الكاملة',
    quickView: 'نظرة سريعة',

    // Language Toggle
    langSwitchName: 'English',

    // AI Modal
    aiModalTitle: 'المساعد الذكي لـ السوري ستور',
    aiModalSubtitle: 'مرتبط بالمتجر الفعلي وقاعدة بيانات الصيانة في الزقازيق.',
    aiAskPlaceholder: 'اسأل عن الأسعار، مقارنة المواصفات، تكلفة الصيانة، أو الضمان...',

    // Admin Dashboard
    adminDashboardTitle: 'لوحة التحليلات الذكية وإدارة المتجر',
    adminSubtitle: 'رؤية شاملة للطلبات الأكثر بحثاً، اتجاهات الصيانة، ونسب المبيعات.',
    searchedProducts: 'الأجهزة الأكثر بحثاً',
    requestedBrands: 'الماركات الأكثر طلباً',
    requestedRepairs: 'الصيانة الأكثر طلباً',
    unfulfilledRequests: 'طلب الأجهزة غير المتوفرة',
    conversionRate: 'نسبة تحويل المبيعات',
    totalConversations: 'جلسات المساعد الذكي',

    // Product Details
    warrantyInfo: 'ضمان رسمي لمدة سنة من السوري ستور',
    selectColor: 'اختر اللون',
    selectStorage: 'اختر السعة',
    specifications: 'المواصفات التقنية',
    keyFeatures: 'أبرز المميزات',
    quickOrderWhatsApp: 'طلب سريع عبر الواتساب',
    orderCartWhatsApp: 'إرسال السلة عبر الواتساب',

    // Checkout & Cart
    cartTitle: 'حقيبة التسوق الخاصة بك',
    subtotal: 'المجموع الفرعي',
    checkout: 'متابعة الدفع والإنهاء',
    emptyCart: 'حقيبة التسوق فارغة',
    orderTotal: 'إجمالي الطلب',
    placeOrder: 'تأكيد وإرسال الطلب',

    // Footer & Locations
    locationTitle: 'مقر السوري ستور (ELSORY STORE)',
    locationAddress: 'مصر - محافظة الشرقية - الزقازيق - حي فلل الجامعة - القومية',
    phoneContact: '+20 10 1234 5678',
    whatsappContact: '+20 10 9876 5432',
  },
};

export function getCategoryTranslation(category: Category, lang: Language): string {
  switch (category) {
    case 'All': return translations[lang].catAll;
    case 'Smartphones': return translations[lang].catSmartphones;
    case 'Tablets': return translations[lang].catTablets;
    case 'Smartwatches': return translations[lang].catSmartwatches;
    case 'Audio & Sound': return translations[lang].catAudio;
    case 'Accessories': return translations[lang].catAccessories;
    case 'Luxury Editions': return translations[lang].catLuxury;
    case 'Repair Services': return translations[lang].catRepair;
    default: return category;
  }
}
