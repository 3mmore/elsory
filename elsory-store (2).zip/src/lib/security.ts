/**
 * Enterprise Security Utility Module for ElSory Store
 * Implements OWASP guidelines: Input Sanitization, XSS Prevention, Output Encoding, Luhn Validation
 */

// XSS Sanitizer for string inputs
export function sanitizeInput(str: string): string {
  if (!str || typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

// Luhn Algorithm to validate credit card numbers (PCI DSS compliance)
export function validateLuhn(cardNumber: string): boolean {
  const digitsOnly = cardNumber.replace(/\D/g, '');
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;

  let sum = 0;
  let isEven = false;

  for (let i = digitsOnly.length - 1; i >= 0; i--) {
    let digit = parseInt(digitsOnly.charAt(i), 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

// Mask sensitive credit card numbers for display
export function maskCardNumber(cardNumber: string): string {
  const digitsOnly = cardNumber.replace(/\D/g, '');
  if (digitsOnly.length < 4) return '••••';
  const lastFour = digitsOnly.slice(-4);
  return `•••• •••• •••• ${lastFour}`;
}

// Phone number sanitizer for Egyptian (+20) & regional format
export function sanitizePhoneNumber(phone: string): string {
  if (!phone) return '';
  return phone.replace(/[^\d+]/g, '');
}

// Generate client-side secure transaction token (Anti-Replay / Nonce)
export function generateTransactionNonce(): string {
  const array = new Uint8Array(16);
  if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
    window.crypto.getRandomValues(array);
  } else {
    for (let i = 0; i < 16; i++) {
      array[i] = Math.floor(Math.random() * 256);
    }
  }
  return Array.from(array, (b) => b.toString(16).padStart(2, '0')).join('');
}
