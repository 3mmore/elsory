import express from "express";
import path from "path";
import dotenv from "dotenv";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";
import csurf from "csurf";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();

// 1. Helmet HTTP Security Headers (OWASP Best Practice)
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
        imgSrc: ["'self'", "https:", "data:", "blob:"],
        connectSrc: ["'self'", "https:", "http:", "ws:", "wss:"],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);

// Body Parsing & Cookie Parsing
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());

// 2. Express Rate Limiter for API Protection (OWASP Best Practice)
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes window
  max: 100, // Limit each IP to 100 requests per 15 minutes
  standardHeaders: true, // Return rate limit info in `RateLimit-*` headers
  legacyHeaders: false, // Disable `X-RateLimit-*` headers
  message: {
    error: "Too many requests from this IP address, please try again after 15 minutes.",
  },
});

app.use("/api/", apiLimiter);

// 3. CSURF Protection setup
const csrfProtection = csurf({
  cookie: {
    key: "_csrf",
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
  },
});

// Endpoint to fetch CSRF Token
app.get("/api/csrf-token", csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

// Apply CSRF Protection to state-changing API endpoints
app.use("/api", (req, res, next) => {
  // Allow safe HTTP methods without CSRF token check
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    return next();
  }
  return csrfProtection(req, res, next);
});

// Custom Error Handler for CSRF validation failures
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err && err.code === "EBADCSRFTOKEN") {
    return res.status(403).json({
      error: "Invalid or missing CSRF token. Request blocked for security.",
    });
  }
  next(err);
});

const PORT = 3000;

// Initialize GoogleGenAI SDK safely
const getGenAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is missing from environment variables.");
  }
  return new GoogleGenAI({
    apiKey: apiKey || "dummy-key",
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// Health Check API
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    store: "ElSory Store (السوري ستور) API",
    location: "Zagazig, Sharqia, Egypt",
    time: new Date().toISOString(),
  });
});

// ElSory Store AI Concierge / Assistant Endpoint (Sales & Customer Advisor)
app.post("/api/ai-assistant", async (req, res) => {
  try {
    const { prompt, preferences, conversationHistory, mode = "general", userLocation } = req.body;

    if (!prompt && (!preferences || Object.keys(preferences).length === 0)) {
      return res.status(400).json({ error: "Please provide a query or preferences." });
    }

    const ai = getGenAI();

    const systemInstruction = `
You are ElSory Store AI (السوري ستور) — the premier Sales Consultant, Customer Advisor, and Senior Mobile Hardware & Repair Specialist at ELSORY STORE located in Zagazig, Sharqia Governorate, Egypt (Villas El Gamea District, Al Qawmia).

CRITICAL DIRECTIVES & OWASP/ETHICAL STANDARDS:
1. HONESTY & CUSTOMER TRUST:
   - Always prioritize honesty, customer trust, and long-term relationships over aggressive or pushy selling.
   - NEVER invent or hallucinate product specifications, stock availability, false discounts, or fake delivery guarantees.
   - Base ALL recommendations strictly on verified ElSory Store data, real inventory catalog, transparent prices, official store policies, and certified repair services.

2. SALES CONSULTANT ROLE & BEHAVIOR:
   - Behave like the best, most knowledgeable sales representative in a flagship Apple Store — polite, attentive, empathetic, highly technical, and completely trustworthy.
   - Understand customer needs through conversation. Ask thoughtful follow-up questions when requirements are vague (e.g., asking about primary usage like camera vs gaming vs battery life, or budget flexibility) BEFORE rushing to recommend a product.
   - Compare multiple devices objectively, highlighting genuine pros and cons for the user's specific use case.
   - Recommend the best value for the customer's budget — never push the most expensive model if a better-suited or more affordable model fits their needs better.
   - Suggest genuine accessories that complement their chosen device (e.g. 100W GaN fast chargers, MagSafe Leather Cases, AirPods Max/Pro 2, hydrogel screen guards).
   - Suggest protection plans or repair center services when appropriate (e.g. 1-Year Official ElSory Store Warranty, TrueTone OLED protection, battery health care).
   - Cross-sell and upsell naturally without being pushy or aggressive.
   - Maintain multi-turn context throughout the conversation.
   - Assist with storage size choices (explaining why 256GB vs 512GB vs 1TB matters for 4K video recording or heavy apps), color variants, payment options, and official Egyptian installment plans (Valu, Souhoola, Sympl, CIB 0% interest, InstaPay, Cash on Delivery).
   - Handle customer objections professionally and empathetically (e.g., addressing price concerns, warranty questions, Android vs iOS switching, or repair vs buying new).

3. INVENTORY & AVAILABILITY MANDATE:
   - Store catalog items:
     * iPhone 16 Pro Max ($1199 / 58,150 EGP) - IN STOCK
     * Samsung Galaxy S25 Ultra ($1299 / 63,000 EGP) - IN STOCK
     * Nothing Phone (2a) Plus ($449 / 21,750 EGP) - IN STOCK
     * Google Pixel 9 Pro XL ($1099 / 53,300 EGP) - IN STOCK
     * 24K Gold Syrian Falcon Edition iPhone 16 Pro Max ($4800 / 232,800 EGP) - IN STOCK (Luxury)
     * iPad Pro M4 13-inch ($1299 / 63,000 EGP) - IN STOCK
     * Apple Watch Ultra 2 ($799 / 38,750 EGP) - IN STOCK
     * AirPods Pro 2 ($249 / 12,000 EGP) - IN STOCK
     * Anker MagGo Power Bank ($89 / 4,300 EGP) - IN STOCK
     * Original OLED Screen Replacements (from $85 / 4,100 EGP) - IN STOCK
     * Genuine Battery Replacements (from $35 / 1,700 EGP) - IN STOCK
     * Precision Laser Back Glass Repair ($45 / 2,200 EGP) - IN STOCK
     * Motherboard Micro-Soldering ($75 / 3,650 EGP) - IN STOCK
   - IF A REQUESTED PRODUCT IS UNAVAILABLE OR NOT IN CATALOG (e.g., Sony Xperia, Asus ROG, custom unstocked models):
     * NEVER claim it is available in stock.
     * Explain politely that it is currently not stocked in the immediate inventory.
     * Suggest suitable, in-stock alternatives from our catalog with clear comparisons.
     * Politely recommend contacting our Zagazig store directly on WhatsApp for a custom VIP import inquiry.

4. TONE & FORMATTING:
   - Format responses using clean, structured Markdown headers, bullet points, and comparison lists.
   - Speak in fluent English or Arabic depending on the user's input language. Mention 1-Year Store Warranty, Zagazig Express same-day courier, and doorstep pickup.
`;

    const userMessage = prompt || `User preferences: Budget: ${preferences?.budget || 'Flex'}, Primary Use: ${preferences?.useCase || 'General'}, Preferred Brand: ${preferences?.brand || 'Any'}.`;

    // Construct multi-turn contents array if conversation history is provided
    const contents: any[] = [];
    if (Array.isArray(conversationHistory) && conversationHistory.length > 0) {
      for (const msg of conversationHistory) {
        if (msg.text) {
          contents.push({
            role: msg.sender === 'user' ? 'user' : 'model',
            parts: [{ text: msg.text }],
          });
        }
      }
    }
    // Append current prompt
    contents.push({
      role: 'user',
      parts: [{ text: userMessage }],
    });

    // Select model and configuration according to requested capability mode
    let modelName = "gemini-3.5-flash";
    let config: any = {
      systemInstruction,
    };
    let toolConfig: any = undefined;

    if (mode === "fast") {
      // Feature 1: Low-latency fast responses
      modelName = "gemini-3.1-flash-lite";
      config.temperature = 0.5;
    } else if (mode === "thinking") {
      // Feature 2: High thinking mode for complex queries (gemini-3.1-pro-preview + ThinkingLevel.HIGH)
      modelName = "gemini-3.1-pro-preview";
      config.thinkingConfig = {
        thinkingLevel: ThinkingLevel.HIGH,
      };
      // Note: maxOutputTokens must NOT be set when using thinkingLevel
    } else if (mode === "maps") {
      // Feature 5: Google Maps Grounding
      modelName = "gemini-3.5-flash";
      config.tools = [{ googleMaps: {} }];
      if (userLocation && typeof userLocation.latitude === 'number' && typeof userLocation.longitude === 'number') {
        toolConfig = {
          retrievalConfig: {
            latLng: {
              latitude: userLocation.latitude,
              longitude: userLocation.longitude,
            },
          },
        };
      }
      // Note: responseMimeType / responseSchema must NOT be set when using googleMaps
    } else {
      // Feature 3 & 4: General intelligence and multi-turn chatbot
      modelName = "gemini-3.5-flash";
      config.temperature = 0.7;
    }

    const requestPayload: any = {
      model: modelName,
      contents,
      config,
    };

    if (toolConfig) {
      requestPayload.toolConfig = toolConfig;
    }

    const response = await ai.models.generateContent(requestPayload);

    const replyText = response.text || "I recommend consulting our flagship models like iPhone 16 Pro Max or Galaxy S25 Ultra, or visiting our Zagazig repair center.";

    // Extract Grounding Chunks (for Google Maps or Search grounding if used)
    const rawGroundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const mapsSources = rawGroundingChunks.map((chunk: any) => {
      if (chunk.maps) {
        return {
          title: chunk.maps.title || "ElSory Store Location",
          uri: chunk.maps.uri || "https://maps.google.com",
          placeAnswerSources: chunk.maps.placeAnswerSources || null,
        };
      }
      if (chunk.web) {
        return {
          title: chunk.web.title || "Web Reference",
          uri: chunk.web.uri || "https://google.com",
        };
      }
      return null;
    }).filter(Boolean);

    return res.json({
      reply: replyText,
      modeUsed: mode,
      modelUsed: modelName,
      groundingChunks: rawGroundingChunks,
      mapsSources,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("AI Assistant Error:", error);
    return res.status(500).json({
      error: "Unable to consult AI Assistant right now.",
      message: error.message,
    });
  }
});

// Trade-In Estimator Backend API
app.post("/api/trade-in", (req, res) => {
  try {
    const { brand, model, storage, condition, screenIntact } = req.body;

    // Base value matrix in USD
    let baseValue = 300;

    if (model.toLowerCase().includes("iphone 15 pro max")) baseValue = 750;
    else if (model.toLowerCase().includes("iphone 15 pro")) baseValue = 650;
    else if (model.toLowerCase().includes("iphone 14 pro max")) baseValue = 550;
    else if (model.toLowerCase().includes("iphone 13 pro")) baseValue = 400;
    else if (model.toLowerCase().includes("galaxy s24 ultra")) baseValue = 700;
    else if (model.toLowerCase().includes("galaxy s23 ultra")) baseValue = 500;
    else if (model.toLowerCase().includes("pixel 8 pro")) baseValue = 420;

    // Storage modifier
    if (storage?.includes("512GB")) baseValue += 60;
    if (storage?.includes("1TB")) baseValue += 120;

    // Condition multiplier
    let conditionMult = 1.0;
    if (condition === "Like New") conditionMult = 1.0;
    else if (condition === "Good") conditionMult = 0.85;
    else if (condition === "Fair") conditionMult = 0.65;

    if (!screenIntact) conditionMult *= 0.6;

    const estimatedValueUSD = Math.round(baseValue * conditionMult);
    const bonusCreditUSD = 50; // ElSory Store Upgrade Bonus
    const totalTradeInUSD = estimatedValueUSD + bonusCreditUSD;

    const voucherCode = `ELSORY-TRADE-${Math.floor(100000 + Math.random() * 900000)}`;

    return res.json({
      brand,
      model,
      estimatedValueUSD,
      bonusCreditUSD,
      totalTradeInUSD,
      currencyValues: {
        EGP: `${(totalTradeInUSD * 48.5).toLocaleString('en-US')} ج.م`,
        USD: `$${totalTradeInUSD}`,
        EUR: `€${Math.round(totalTradeInUSD * 0.92)}`,
        SAR: `${Math.round(totalTradeInUSD * 3.75)} ر.س`,
        AED: `${Math.round(totalTradeInUSD * 3.67)} د.إ`,
        SYP: `${(totalTradeInUSD * 14800).toLocaleString('en-US')} ل.س`,
      },
      voucherCode,
    });
  } catch (error: any) {
    return res.status(500).json({ error: "Failed to generate trade-in valuation." });
  }
});

// Admin AI Marketing Advisor & Strategic Growth Intelligence Endpoint
app.post("/api/ai-marketing-analyst", async (req, res) => {
  try {
    const { focusArea = "overview", customPrompt } = req.body;
    const ai = getGenAI();

    const marketingSystemInstruction = `
You are the Chief AI Marketing Strategist & Senior Business Analyst at ELSORY STORE (السوري ستور) — the flagship luxury mobile phone retailer, hardware specialist, and micro-repair center in Zagazig, Sharqia, Egypt.

YOUR MISSION:
Analyze real store inventory, sales performance, search query trends, customer conversation insights, conversion rates, abandoned carts, repair logs, and seasonal demand to generate highly actionable, data-driven, and ethical marketing and sales growth strategies.

CORE STRATEGIC RESPONSIBILITIES & OUTPUT STRUCTURE:
1. MARKET DEMAND & SALES ANALYSIS:
   - Identify top-trending devices (iPhone 16 Pro Max, Galaxy S25 Ultra, Pixel 9 Pro XL).
   - Detect zero-inventory / unstocked search demand (e.g., Sony Xperia, Asus ROG, custom folding phones) and recommend custom import or pre-order campaigns.
   - Evaluate cart abandonment drivers and conversion velocity.

2. ACTIONABLE MARKETING & CAMPAIGN RECOMMENDATIONS:
   - PROMOTIONS & DISCOUNT STRATEGY: Specify which products need promotional spotlight vs which require targeted clearance discounts.
   - BUNDLES & FLASH DEALS: Suggest high-margin bundle deals (e.g. Flagship Device + Anker 100W GaN Charger + Hydrogel Protection + 1-Year Store Warranty).
   - CROSS-SELL & UPSELL STRATEGIES: Recommend natural cross-sells (AirPods Pro 2, Apple Watch Ultra 2, MagSafe leather cases).
   - CAMPAIGN TYPES: Create tailored plans for Seasonal Campaigns, Egyptian Holiday Promotions (Ramadan, Eid, Back-to-School, Black Friday / White Friday), VIP Loyalty, and Referral programs.

3. MULTI-CHANNEL DIGITAL MARKETING CREATIVES & AD SCRIPTS:
   - WHATSAPP MARKETING: Provide high-converting broadcast message copy with clear CTAs for local Egyptian customers.
   - EMAIL MARKETING: Write compelling subject lines and email body copy.
   - SOCIAL MEDIA CONTENT (Instagram / TikTok): Viral Reel concepts, video hooks, and script outlines.
   - PAID AD CAMPAIGNS (Meta Facebook/Instagram Ads & Google Ads): Ad copy, target demographics, and search keywords.
   - TIKTOK CAMPAIGNS: Hook ideas, video pacing, and trendy sound suggestions.
   - CAMPAIGN METRICS: Suggest optimal posting schedules, recommended ad budgets (EGP / USD), and target conversion metrics / expected ROI.

4. SLOW-MOVING INVENTORY CLEARANCE:
   - Identify slower-moving inventory items and propose strategic clearance bundles, trade-in booster credits, or local Zagazig door-to-door promotion ideas.

Always structure your report clearly using Markdown headings, bold key metrics, bullet points, and code blocks for broadcast templates & ad copy.
`;

    let promptText = `Generate a strategic Marketing & Sales Intelligence report for ElSory Store. Focus area: ${focusArea}.`;
    if (customPrompt) {
      promptText += ` Specific Request from Admin: "${customPrompt}"`;
    }

    // Use gemini-3.1-pro-preview with ThinkingLevel.HIGH for deep strategic analysis
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: promptText,
      config: {
        systemInstruction: marketingSystemInstruction,
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.HIGH,
        },
      },
    });

    const reportText = response.text || "Generated strategic marketing intelligence report for ElSory Store.";

    return res.json({
      focusArea,
      report: reportText,
      generatedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("AI Marketing Analyst Error:", error);
    return res.status(500).json({
      error: "Unable to generate AI marketing strategy analysis.",
      message: error.message,
    });
  }
});

// Vite server / Static files middleware
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true, host: "0.0.0.0", port: PORT },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ElSory Store Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
