import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Filter, 
  Sparkles, 
  Scale, 
  Truck, 
  ShieldCheck, 
  ShoppingBag, 
  CheckCircle, 
  PhoneCall,
  Search,
  ArrowUpDown
} from 'lucide-react';

import { Product, Category, Brand, Currency, Language, CartItem, Order } from './types';
import { PRODUCTS } from './data/products';
import { formatPrice } from './data/currencies';
import { translations, getCategoryTranslation } from './lib/i18n';

import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ExplodedViewShowcase } from './components/ExplodedViewShowcase';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { DeviceComparer } from './components/DeviceComparer';
import { AIAssistantModal } from './components/AIAssistantModal';
import { AdminAIDashboardModal } from './components/AdminAIDashboardModal';
import { TradeInCalculator } from './components/TradeInCalculator';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { StoreLocationsModal } from './components/StoreLocationsModal';
import { RepairCenterModal } from './components/RepairCenterModal';
import { ScrollProgress } from './components/ScrollProgress';
import { MobileBottomNav } from './components/MobileBottomNav';
import { ReviewsSection } from './components/ReviewsSection';
import { Footer } from './components/Footer';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 25 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: [0.25, 0.1, 0.25, 1.0] as const,
    },
  },
};

export default function App() {
  const [currentCurrency, setCurrentCurrency] = useState<Currency>('USD');
  const [lang, setLang] = useState<Language>('en');
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('elsory_theme');
    return (saved as 'dark' | 'light') || 'dark';
  });
  const [activeCategory, setActiveCategory] = useState<Category>('All');
  const [activeBrand, setActiveBrand] = useState<Brand>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');

  // Sync theme with DOM document element
  React.useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('elsory_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Application State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [comparedProducts, setComparedProducts] = useState<Product[]>([]);

  // Modals / Drawers State
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [aiModalOpen, setAiModalOpen] = useState(false);
  const [adminDashboardOpen, setAdminDashboardOpen] = useState(false);
  const [compareModalOpen, setCompareModalOpen] = useState(false);
  const [tradeInModalOpen, setTradeInModalOpen] = useState(false);
  const [locationsModalOpen, setLocationsModalOpen] = useState(false);
  const [repairModalOpen, setRepairModalOpen] = useState(false);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [trackingModalOpen, setTrackingModalOpen] = useState(false);

  const [discountUSD, setDiscountUSD] = useState(0);
  const [recentOrder, setRecentOrder] = useState<Order | null>(null);

  const t = translations[lang];

  const heroShowcaseProduct = PRODUCTS[0];

  const allBrandsList: Brand[] = [
    'All', 'Apple', 'Samsung', 'Google', 'Nothing', 'Xiaomi', 'Honor', 'Huawei', 'Oppo', 'Vivo', 'OnePlus', 'Motorola', 'Realme'
  ];

  // Filtered and Sorted Products Catalog
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((p) => {
      const matchCategory = activeCategory === 'All' || p.category === activeCategory;
      const matchBrand = activeBrand === 'All' || p.brand === activeBrand;
      const matchSearch = !searchQuery.trim() || 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase());

      return matchCategory && matchBrand && matchSearch;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.priceUSD - b.priceUSD;
      if (sortBy === 'price-desc') return b.priceUSD - a.priceUSD;
      if (sortBy === 'rating') return b.rating - a.rating;
      return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
    });
  }, [activeCategory, activeBrand, searchQuery, sortBy]);

  // Cart Operations
  const handleAddToCart = (product: Product, colorName?: string, storageSize?: string, quantity: number = 1) => {
    const selectedColor = product.colors.find((c) => c.name === colorName) || product.colors[0];
    const storageOpt = product.storageOptions?.find((s) => s.size === storageSize) || product.storageOptions?.[0];
    const priceUSD = storageOpt?.priceUSD || product.priceUSD;

    const instanceId = `${product.id}-${selectedColor.name}-${storageOpt?.size || 'default'}`;

    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === instanceId);
      if (existing) {
        return prev.map((item) =>
          item.id === instanceId ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [
        ...prev,
        {
          id: instanceId,
          product,
          selectedColor,
          selectedStorage: storageOpt?.size,
          priceUSD,
          quantity,
        },
      ];
    });
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Compare Operations
  const handleToggleCompare = (product: Product) => {
    setComparedProducts((prev) => {
      const exists = prev.find((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      }
      if (prev.length >= 3) {
        alert('You can compare up to 3 devices at a time.');
        return prev;
      }
      return [...prev, product];
    });
  };

  // Wishlist Operations
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.find((p) => p.id === product.id);
      if (exists) return prev.filter((p) => p.id !== product.id);
      return [...prev, product];
    });
  };

  // Order Completion
  const handleOrderCompleted = (order: Order) => {
    setRecentOrder(order);
    setCartItems([]);
    setDiscountUSD(0);
    setCheckoutModalOpen(false);
    setTrackingModalOpen(true);
  };

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className={`min-h-screen font-sans antialiased selection:bg-zinc-900 selection:text-white dark:selection:bg-white dark:selection:text-black pb-16 md:pb-0 transition-colors duration-300 ${theme === 'dark' ? 'bg-black text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      <ScrollProgress />
      
      {/* Navbar Header */}
      <Navbar
        currentCurrency={currentCurrency}
        onCurrencyChange={setCurrentCurrency}
        lang={lang}
        onLangToggle={() => setLang((prev) => (prev === 'en' ? 'ar' : 'en'))}
        theme={theme}
        onThemeToggle={toggleTheme}
        cartCount={cartItems.reduce((a, b) => a + b.quantity, 0)}
        wishlistCount={wishlist.length}
        compareCount={comparedProducts.length}
        onOpenCart={() => setCartDrawerOpen(true)}
        onOpenAI={() => setAiModalOpen(true)}
        onOpenAdminDashboard={() => setAdminDashboardOpen(true)}
        onOpenCompare={() => setCompareModalOpen(true)}
        onOpenTradeIn={() => setTradeInModalOpen(true)}
        onOpenLocations={() => setLocationsModalOpen(true)}
        onOpenTracking={() => setTrackingModalOpen(true)}
        onOpenRepair={() => setRepairModalOpen(true)}
        onSearchChange={setSearchQuery}
        activeCategory={activeCategory}
        onSelectCategory={(cat) => {
          if (cat === 'Repair Services') {
            setRepairModalOpen(true);
          } else {
            setActiveCategory(cat);
          }
        }}
      />

      {/* Hero Section */}
      <Hero
        currentCurrency={currentCurrency}
        onExploreClick={() => {
          const el = document.getElementById('catalog-grid');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenAI={() => setAiModalOpen(true)}
        onSelectFeaturedProduct={(id) => {
          const prod = PRODUCTS.find((p) => p.id === id);
          if (prod) setSelectedProduct(prod);
        }}
      />

      {/* 3D Exploded Hardware View Showcase */}
      {heroShowcaseProduct && (
        <ExplodedViewShowcase
          product={heroShowcaseProduct}
          currentCurrency={currentCurrency}
          lang={lang}
          onSelectProduct={(p) => setSelectedProduct(p)}
        />
      )}

      {/* Main Catalog Showcase */}
      <motion.main 
        id="catalog-grid" 
        className="max-w-7xl mx-auto px-4 sm:px-6 py-16 space-y-8"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-50px' }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        
        {/* Controls Header (Brands + Sort) */}
        <motion.div 
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-zinc-200 dark:border-zinc-800 transition-colors"
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          
          {/* Brand Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 mr-2 shrink-0">{t.brandFilter}:</span>
            {allBrandsList.map((brand) => (
              <button
                key={brand}
                onClick={() => setActiveBrand(brand as Brand)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
                  activeBrand === brand
                    ? 'bg-zinc-900 dark:bg-white text-white dark:text-black shadow-xs'
                    : 'bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white border border-zinc-200 dark:border-zinc-800'
                }`}
              >
                {brand}
              </button>
            ))}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 self-end md:self-auto text-xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-zinc-500 font-semibold">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-zinc-400 dark:focus:border-zinc-500 font-medium transition-colors"
            >
              <option value="featured">Featured / Bestseller</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Customer Rated</option>
            </select>
          </div>

        </motion.div>

        {/* Search & Active Filter Indicators */}
        {(searchQuery || activeCategory !== 'All' || activeBrand !== 'All') && (
          <motion.div 
            className="flex items-center gap-2 text-xs text-zinc-400"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <span>Showing results for:</span>
            {activeCategory !== 'All' && (
              <span className="bg-zinc-800 text-white px-2.5 py-1 rounded-md font-bold">{activeCategory}</span>
            )}
            {activeBrand !== 'All' && (
              <span className="bg-zinc-800 text-white px-2.5 py-1 rounded-md font-bold">{activeBrand}</span>
            )}
            {searchQuery && (
              <span className="bg-zinc-800 text-white px-2.5 py-1 rounded-md font-bold">"{searchQuery}"</span>
            )}
            <button
              onClick={() => {
                setActiveCategory('All');
                setActiveBrand('All');
                setSearchQuery('');
              }}
              className="text-zinc-500 hover:text-white underline ml-2 cursor-pointer"
            >
              Reset Filters
            </button>
          </motion.div>
        )}

        {/* Product Grid with Framer Motion Stagger */}
        {filteredProducts.length > 0 ? (
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-50px' }}
          >
            {filteredProducts.map((product) => (
              <motion.div key={product.id} variants={cardVariants} layout>
                <ProductCard
                  product={product}
                  currentCurrency={currentCurrency}
                  onSelectProduct={setSelectedProduct}
                  onAddToCart={handleAddToCart}
                  onToggleCompare={handleToggleCompare}
                  isCompared={comparedProducts.some((p) => p.id === product.id)}
                  onToggleWishlist={handleToggleWishlist}
                  isWishlisted={wishlist.some((p) => p.id === product.id)}
                />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div 
            className="text-center py-20 space-y-3 bg-zinc-900/50 border border-zinc-800 rounded-3xl"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
          >
            <Search className="w-10 h-10 mx-auto text-zinc-600" />
            <h3 className="text-lg font-bold text-white">No products found</h3>
            <p className="text-xs text-zinc-400 max-w-sm mx-auto">
              We couldn't find any devices matching your filters. Try selecting another category or searching for iPhone, Samsung, or Nothing.
            </p>
            <button
              onClick={() => {
                setActiveCategory('All');
                setActiveBrand('All');
                setSearchQuery('');
              }}
              className="mt-2 px-5 py-2.5 bg-white text-black font-bold rounded-xl text-xs hover:bg-zinc-200 transition-colors"
            >
              View Full Syrian Store Catalog
            </button>
          </motion.div>
        )}

      </motion.main>

      {/* Customer Reviews Section */}
      <ReviewsSection />

      {/* Footer */}
      <Footer
        currentCurrency={currentCurrency}
        onCurrencyChange={setCurrentCurrency}
        onOpenAI={() => setAiModalOpen(true)}
        onOpenTradeIn={() => setTradeInModalOpen(true)}
        onOpenLocations={() => setLocationsModalOpen(true)}
        onOpenTracking={() => setTrackingModalOpen(true)}
        onOpenRepair={() => setRepairModalOpen(true)}
        onSelectCategory={(cat) => {
          if (cat === 'Repair Services') {
            setRepairModalOpen(true);
          } else {
            setActiveCategory(cat as Category);
          }
        }}
      />

      {/* Modals & Drawers */}

      {/* Repair Center Modal */}
      <AnimatePresence>
        {repairModalOpen && (
          <RepairCenterModal
            currentCurrency={currentCurrency}
            onClose={() => setRepairModalOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Product Detail Modal */}
      <AnimatePresence>
        {selectedProduct && (
          <ProductDetailModal
            product={selectedProduct}
            currentCurrency={currentCurrency}
            onClose={() => setSelectedProduct(null)}
            onAddToCart={handleAddToCart}
            onToggleCompare={handleToggleCompare}
            isCompared={comparedProducts.some((p) => p.id === selectedProduct.id)}
          />
        )}
      </AnimatePresence>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        currentCurrency={currentCurrency}
        discountUSD={discountUSD}
        onApplyDiscount={(code, amt) => setDiscountUSD(amt)}
        onProceedToCheckout={() => {
          setCartDrawerOpen(false);
          setCheckoutModalOpen(true);
        }}
      />

      {/* AI Assistant Modal */}
      <AnimatePresence>
        {aiModalOpen && (
          <AIAssistantModal
            currentCurrency={currentCurrency}
            onClose={() => setAiModalOpen(false)}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
          />
        )}
      </AnimatePresence>

      {/* Admin AI Dashboard Modal */}
      <AnimatePresence>
        {adminDashboardOpen && (
          <AdminAIDashboardModal
            currentCurrency={currentCurrency}
            lang={lang}
            onClose={() => setAdminDashboardOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Device Comparer Modal */}
      <AnimatePresence>
        {compareModalOpen && (
          <DeviceComparer
            comparedProducts={comparedProducts}
            currentCurrency={currentCurrency}
            onClose={() => setCompareModalOpen(false)}
            onRemoveFromCompare={(id) => setComparedProducts((prev) => prev.filter((p) => p.id !== id))}
            onAddProductToCompare={(p) => handleToggleCompare(p)}
            onAddToCart={handleAddToCart}
          />
        )}
      </AnimatePresence>

      {/* Trade-In Calculator Modal */}
      <AnimatePresence>
        {tradeInModalOpen && (
          <TradeInCalculator
            currentCurrency={currentCurrency}
            onClose={() => setTradeInModalOpen(false)}
            onApplyVoucherToCart={(code, amt) => {
              setDiscountUSD(amt);
              setTradeInModalOpen(false);
              setCartDrawerOpen(true);
            }}
          />
        )}
      </AnimatePresence>

      {/* Store Locations Modal */}
      <AnimatePresence>
        {locationsModalOpen && (
          <StoreLocationsModal onClose={() => setLocationsModalOpen(false)} />
        )}
      </AnimatePresence>

      {/* Checkout Modal */}
      <AnimatePresence>
        {checkoutModalOpen && (
          <CheckoutModal
            cartItems={cartItems}
            currentCurrency={currentCurrency}
            discountUSD={discountUSD}
            onClose={() => setCheckoutModalOpen(false)}
            onOrderCompleted={handleOrderCompleted}
          />
        )}
      </AnimatePresence>

      {/* Order Tracker Modal */}
      <AnimatePresence>
        {trackingModalOpen && (
          <OrderTrackerModal
            recentOrder={recentOrder}
            currentCurrency={currentCurrency}
            onClose={() => setTrackingModalOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Mobile Glassmorphic Bottom Navigation */}
      <MobileBottomNav
        cartCount={cartItems.reduce((a, b) => a + b.quantity, 0)}
        onOpenCart={() => setCartDrawerOpen(true)}
        onOpenRepair={() => setRepairModalOpen(true)}
        onOpenAI={() => setAiModalOpen(true)}
        onFocusSearch={() => {
          const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement | null;
          if (searchInput) {
            searchInput.focus();
            searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }}
        onGoHome={() => {
          setActiveCategory('All');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

    </div>
  );
}

