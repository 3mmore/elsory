import React, { useState, useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';
import { Layers, Cpu, Camera, Battery, Smartphone, Sparkles, ShieldCheck, Eye } from 'lucide-react';
import { Product, Currency, Language } from '../types';
import { formatPrice } from '../data/currencies';
import { translations } from '../lib/i18n';

interface ExplodedViewShowcaseProps {
  product: Product;
  currentCurrency: Currency;
  lang: Language;
  onSelectProduct: (p: Product) => void;
}

export const ExplodedViewShowcase: React.FC<ExplodedViewShowcaseProps> = ({
  product,
  currentCurrency,
  lang,
  onSelectProduct,
}) => {
  const [isExploded, setIsExploded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'center center'],
  });

  const smoothProgress = useSpring(scrollYProgress, { stiffness: 90, damping: 20 });

  // Scroll driven explosion distance
  const scrollExplodeZ = useTransform(smoothProgress, [0, 1], [0, 70]);

  const layers = [
    {
      id: 'display',
      title: 'Super Retina XDR OLED',
      detail: '2000 nits Peak • Ceramic Shield • 120Hz ProMotion',
      icon: Smartphone,
      color: 'from-blue-500/20 to-cyan-500/10',
      offsetZ: isExploded ? 120 : 0,
      translateY: isExploded ? -60 : 0,
      badge: 'Front Glass',
    },
    {
      id: 'chipset',
      title: 'A18 Pro / Snapdragon 8 Elite',
      detail: '3nm Architecture • 6-Core GPU • Neural Engine',
      icon: Cpu,
      color: 'from-purple-500/20 to-indigo-500/10',
      offsetZ: isExploded ? 60 : 0,
      translateY: isExploded ? -25 : 0,
      badge: 'Main Logic Board',
    },
    {
      id: 'cameras',
      title: '48MP Pro Triple Camera',
      detail: '5x Optical Zoom • OIS Sensor Shift • 4K120 fps',
      icon: Camera,
      color: 'from-emerald-500/20 to-teal-500/10',
      offsetZ: isExploded ? 10 : 0,
      translateY: isExploded ? 10 : 0,
      badge: 'Optics System',
    },
    {
      id: 'chassis',
      title: 'Grade 5 Titanium Chassis',
      detail: 'Zero-Heat Internal Thermal Dispersion Frame',
      icon: ShieldCheck,
      color: 'from-amber-500/20 to-orange-500/10',
      offsetZ: isExploded ? -40 : 0,
      translateY: isExploded ? 45 : 0,
      badge: 'Aerospace Frame',
    },
    {
      id: 'battery',
      title: 'Dense Silicon-Carbon Battery',
      detail: '45W Fast Charging • MagSafe Qi2 Wireless',
      icon: Battery,
      color: 'from-rose-500/20 to-pink-500/10',
      offsetZ: isExploded ? -90 : 0,
      translateY: isExploded ? 80 : 0,
      badge: 'Power Cell',
    },
  ];

  const t = translations[lang];

  return (
    <section ref={containerRef} className="py-20 bg-black text-white relative overflow-hidden border-b border-zinc-800">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-zinc-800/20 via-zinc-900/40 to-black rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-700 text-xs text-zinc-300 mb-3">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-semibold uppercase tracking-wider">Precision Engineering & Diagnostics</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              3D Interactive Exploded Hardware View
            </h2>
            <p className="text-zinc-400 text-sm sm:text-base mt-2 max-w-2xl">
              Inspect internal component hierarchy of {product.name}. Inspected & serviced at ElSory Store HQ.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsExploded(!isExploded)}
              className="flex items-center gap-2 bg-white text-black hover:bg-zinc-200 transition-all font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-xl cursor-pointer"
            >
              <Layers className="w-4 h-4 text-black" />
              <span>{isExploded ? 'Reassemble Component Layers' : 'Separate Hardware Layers (3D Explode)'}</span>
            </button>
            
            <button
              onClick={() => onSelectProduct(product)}
              className="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-semibold px-4 py-2.5 rounded-xl text-xs sm:text-sm cursor-pointer"
            >
              <Eye className="w-4 h-4 text-zinc-300" />
              <span>{t.viewDetails}</span>
            </button>
          </div>
        </div>

        {/* Exploded View Stage */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-zinc-950/80 border border-zinc-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative">
          
          {/* Left Column: 3D Interactive Layer Stack Visualizer */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center min-h-[420px] relative py-8">
            
            <div className="relative w-full max-w-sm h-80 flex items-center justify-center [perspective:1000px]">
              
              {/* Product Center Base Image */}
              <motion.img
                src={product.image}
                alt={product.name}
                animate={{
                  rotateX: isExploded ? 25 : 0,
                  rotateY: isExploded ? -15 : 0,
                  scale: isExploded ? 0.95 : 1,
                }}
                transition={{ type: 'spring', stiffness: 80, damping: 18 }}
                className="w-56 h-auto object-contain z-10 drop-shadow-[0_20px_50px_rgba(255,255,255,0.15)] rounded-2xl"
              />

              {/* Exploded Floating Virtual Holographic Glass Cards */}
              {layers.map((layer, idx) => {
                const IconComponent = layer.icon;
                return (
                  <motion.div
                    key={layer.id}
                    animate={{
                      y: layer.translateY,
                      opacity: isExploded ? 0.95 : 0,
                      scale: isExploded ? 1 : 0.8,
                    }}
                    transition={{ type: 'spring', stiffness: 90, damping: 16, delay: idx * 0.05 }}
                    className={`absolute w-72 p-3 rounded-2xl border border-zinc-700/80 bg-gradient-to-r ${layer.color} backdrop-blur-xl shadow-2xl flex items-center gap-3 cursor-pointer hover:border-white transition-colors pointer-events-auto z-20`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center shrink-0">
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white truncate">{layer.title}</span>
                        <span className="text-[9px] bg-white/10 text-zinc-300 font-mono px-1.5 py-0.5 rounded uppercase">
                          {layer.badge}
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-300 truncate mt-0.5">{layer.detail}</p>
                    </div>
                  </motion.div>
                );
              })}

            </div>

            <p className="text-center text-xs text-zinc-500 mt-6 flex items-center justify-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Click the button above to toggle full exploded component breakdown</span>
            </p>
          </div>

          {/* Right Column: Key Device Specs & Direct Actions */}
          <div className="lg:col-span-5 space-y-6 border-t lg:border-t-0 lg:border-l border-zinc-800 pt-6 lg:pt-0 lg:pl-8">
            <div>
              <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-400">
                {product.brand} &bull; {product.category}
              </span>
              <h3 className="text-2xl font-black text-white mt-1">{product.name}</h3>
              <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Quick Specs List */}
            <div className="space-y-2.5 bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 text-xs">
              <div className="flex justify-between py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Processor</span>
                <span className="font-semibold text-white">{product.specsDetail.chipset}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Display</span>
                <span className="font-semibold text-white">{product.specsDetail.display.split(',')[0]}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Main Optics</span>
                <span className="font-semibold text-white">{product.specsDetail.mainCamera.split('+')[0]}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-zinc-400">Battery & Charging</span>
                <span className="font-semibold text-white">{product.specsDetail.battery} ({product.specsDetail.charging.split(',')[0]})</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div>
                <span className="text-xs text-zinc-400 block">{t.inStock} &bull; ElSory Price</span>
                <span className="text-2xl font-black text-white">
                  {formatPrice(product.priceUSD, currentCurrency)}
                </span>
              </div>

              <button
                onClick={() => onSelectProduct(product)}
                className="bg-white text-black hover:bg-zinc-200 transition-colors font-bold px-5 py-3 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-lg"
              >
                <span>{t.addToCart}</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
