import React, { useState } from 'react';
import { motion } from 'motion/react';

interface ProgressiveImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'onAnimationStart' | 'onDragStart' | 'onDragEnd' | 'onDrag'> {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
}

export const ProgressiveImage: React.FC<ProgressiveImageProps> = ({
  src,
  alt,
  className = '',
  containerClassName = '',
  ...props
}) => {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className={`relative overflow-hidden ${containerClassName}`}>
      {/* Skeleton Blur Background Pulse */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 animate-pulse rounded-lg" />
      )}

      <motion.img
        src={src}
        alt={alt}
        onLoad={() => setIsLoaded(true)}
        initial={{ opacity: 0, filter: 'blur(12px)', scale: 1.04 }}
        animate={{
          opacity: isLoaded ? 1 : 0,
          filter: isLoaded ? 'blur(0px)' : 'blur(12px)',
          scale: isLoaded ? 1 : 1.04,
        }}
        transition={{ duration: 0.45, ease: 'easeOut' }}
        className={className}
        referrerPolicy="no-referrer"
        {...props}
      />
    </div>
  );
};
