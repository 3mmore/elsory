import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Wrench, ShieldCheck, Clock, CheckCircle2, Phone, Calendar, Smartphone, Cpu, Battery, Sparkles } from 'lucide-react';
import { Currency } from '../types';
import { formatPrice } from '../data/currencies';

interface RepairCenterModalProps {
  currentCurrency: Currency;
  onClose: () => void;
}

export const RepairCenterModal: React.FC<RepairCenterModalProps> = ({ currentCurrency, onClose }) => {
  const [deviceBrand, setDeviceBrand] = useState('Apple iPhone');
  const [deviceModel, setDeviceModel] = useState('iPhone 15 Pro Max');
  const [selectedService, setSelectedService] = useState('Original OLED Screen Replacement');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('Zagazig - Al Qawmia / Villas El Gamea');
  const [bookingSubmitted, setBookingSubmitted] = useState(false);

  const repairServices = [
    {
      name: 'Original OLED Screen Replacement',
      usd: 85,
      egp: 4100,
      time: '30 Minutes',
      warranty: '12 Months Warranty',
      description: 'Factory original OLED panel, TrueTone transfer, waterproof gasket re-sealing.',
      icon: Smartphone,
    },
    {
      name: 'Genuine Battery Replacement',
      usd: 35,
      egp: 1700,
      time: '20 Minutes',
      warranty: '12 Months Warranty',
      description: 'Zero-cycle authentic battery cell. Restores 100% Battery Health % in Settings.',
      icon: Battery,
    },
    {
      name: 'Laser Back Glass Removal & Repair',
      usd: 45,
      egp: 2200,
      time: '60 Minutes',
      warranty: '12 Months Warranty',
      description: 'Precision automated laser technology removes shattered glass without dismantling body.',
      icon: Wrench,
    },
    {
      name: 'Motherboard Micro-Soldering & IC Repair',
      usd: 75,
      egp: 3650,
      time: 'Same Day',
      warranty: '6 Months Warranty',
      description: 'Advanced chip-level diagnostics for dead power IC, no charging, WiFi, or baseband issues.',
      icon: Cpu,
    },
    {
      name: 'Water Damage Ultrasonic Restoration',
      usd: 40,
      egp: 1950,
      time: '2 - 4 Hours',
      warranty: 'Service Warranty',
      description: 'Chemical ultrasonic cleaning, corrosion neutralization, and data recovery.',
      icon: Sparkles,
    },
  ];

  const currentServiceObj = repairServices.find((s) => s.name === selectedService) || repairServices[0];

  const handleBookRepair = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone) return;
    setBookingSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.3 }}
        className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-3xl w-full text-white shadow-2xl relative p-6 sm:p-8 my-auto max-h-[92vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-2xl">
              <Wrench className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-white font-sans">
                  ElSory Store Professional Repair Center
                </h2>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                  Zagazig Branch
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Certified smartphone repair center in Zagazig (Villas El Gamea) • Original Parts & Warranty
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!bookingSubmitted ? (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 my-6">
            
            {/* Left: Device & Service Selection */}
            <div className="md:col-span-7 space-y-5">
              <div className="space-y-3">
                <label className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider block">
                  1. Select Brand & Device Model
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <select
                    value={deviceBrand}
                    onChange={(e) => setDeviceBrand(e.target.value)}
                    className="bg-zinc-900 border border-zinc-700 text-white text-xs rounded-xl p-3 focus:outline-none focus:border-white font-medium"
                  >
                    <option value="Apple iPhone">Apple iPhone</option>
                    <option value="Samsung Galaxy">Samsung Galaxy</option>
                    <option value="Xiaomi / Poco">Xiaomi / Poco</option>
                    <option value="Nothing Phone">Nothing Phone</option>
                    <option value="Google Pixel">Google Pixel</option>
                  </select>

                  <input
                    type="text"
                    value={deviceModel}
                    onChange={(e) => setDeviceModel(e.target.value)}
                    placeholder="e.g. iPhone 16 Pro Max"
                    className="bg-zinc-900 border border-zinc-700 text-white text-xs rounded-xl p-3 focus:outline-none focus:border-white"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider block">
                  2. Select Repair Service Required
                </label>
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1 scrollbar-thin">
                  {repairServices.map((srv) => {
                    const IconComp = srv.icon;
                    const isSelected = selectedService === srv.name;
                    return (
                      <button
                        key={srv.name}
                        type="button"
                        onClick={() => setSelectedService(srv.name)}
                        className={`w-full p-3.5 rounded-2xl border text-left transition-all flex items-start justify-between cursor-pointer ${
                          isSelected
                            ? 'bg-zinc-900 border-white text-white shadow-lg'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-xl mt-0.5 ${isSelected ? 'bg-white text-black' : 'bg-zinc-900 text-zinc-400'}`}>
                            <IconComp className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white">{srv.name}</div>
                            <div className="text-[11px] text-zinc-400 line-clamp-1 mt-0.5">{srv.description}</div>
                            <div className="flex items-center gap-3 mt-1 text-[10px] text-emerald-400 font-medium">
                              <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {srv.time}</span>
                              <span>&bull;</span>
                              <span className="flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> {srv.warranty}</span>
                            </div>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-sm font-extrabold text-white">
                            {formatPrice(srv.usd, currentCurrency)}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

            </div>

            {/* Right: Instant Estimate & Booking Form */}
            <div className="md:col-span-5 bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-5 flex flex-col justify-between">
              
              <div className="space-y-4">
                <div className="border-b border-zinc-800 pb-3">
                  <div className="text-xs text-zinc-400 uppercase font-bold tracking-wider">Estimated Repair Cost</div>
                  <div className="text-2xl font-black text-white mt-1">
                    {formatPrice(currentServiceObj.usd, currentCurrency)}
                  </div>
                  <div className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Includes Parts & Professional Labor
                  </div>
                </div>

                <form onSubmit={handleBookRepair} className="space-y-3 pt-1">
                  <div>
                    <label className="text-[11px] font-medium text-zinc-400 block mb-1">Your Full Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ahmed El-Sayed"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 text-white text-xs rounded-xl p-2.5 focus:outline-none focus:border-white"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-zinc-400 block mb-1">Phone Number / WhatsApp</label>
                    <input
                      type="tel"
                      required
                      placeholder="+20 10 1234 5678"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 text-white text-xs rounded-xl p-2.5 focus:outline-none focus:border-white"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-zinc-400 block mb-1">Service Method</label>
                    <select
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 text-white text-xs rounded-xl p-2.5 focus:outline-none focus:border-white"
                    >
                      <option value="Zagazig - Al Qawmia / Villas El Gamea">Visit Store in Zagazig (Villas El Gamea)</option>
                      <option value="Zagazig Doorstep Pickup">Express Pickup Courier in Zagazig</option>
                      <option value="Cairo / Regional Courier">Send via Express Courier (Egypt)</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-3 bg-white text-black hover:bg-zinc-200 transition-all rounded-xl font-bold text-xs tracking-wide cursor-pointer shadow-lg flex items-center justify-center gap-2"
                  >
                    <Calendar className="w-4 h-4" /> Book Repair Appointment
                  </button>
                </form>
              </div>

              <div className="pt-3 border-t border-zinc-800 text-[11px] text-zinc-400 space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-white">
                  <Phone className="w-3.5 h-3.5 text-emerald-400" /> Zagazig Hotline: +20 10 1234 5678
                </div>
                <div>Address: Villas El Gamea District, Al Qawmia, Zagazig</div>
              </div>

            </div>

          </div>
        ) : (
          /* Booking Confirmation State */
          <div className="py-12 text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-2 max-w-md mx-auto">
              <h3 className="text-2xl font-black text-white">
                Repair Appointment Requested!
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Thank you, <strong className="text-white">{customerName}</strong>. Your repair request for <strong className="text-white">{deviceModel} ({selectedService})</strong> has been received by <strong className="text-white">ElSory Store Zagazig Center</strong>.
              </p>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 max-w-md mx-auto text-xs text-left space-y-2">
              <div className="flex justify-between text-zinc-400">
                <span>Location:</span>
                <span className="font-bold text-white">Zagazig - Villas El Gamea</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Contact Phone:</span>
                <span className="font-bold text-white">{phone}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Estimated Cost:</span>
                <span className="font-bold text-emerald-400">{formatPrice(currentServiceObj.usd, currentCurrency)}</span>
              </div>
            </div>

            <div className="pt-4 flex justify-center gap-3">
              <a
                href={`https://wa.me/201012345678?text=Hello ElSory Store, I booked repair appointment for ${deviceModel} - ${selectedService}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition-all inline-flex items-center gap-2"
              >
                <Phone className="w-4 h-4" /> Confirm via WhatsApp Direct
              </a>

              <button
                onClick={onClose}
                className="px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs rounded-xl transition-all"
              >
                Close Window
              </button>
            </div>
          </div>
        )}

      </motion.div>
    </div>
  );
};
