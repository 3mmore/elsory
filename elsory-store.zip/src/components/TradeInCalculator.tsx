import React, { useState } from 'react';
import { X, RefreshCw, CheckCircle, Smartphone, Award, Shield, ArrowRight, Copy, Check } from 'lucide-react';
import { Currency, TradeInEstimateResult } from '../types';
import { formatPrice } from '../data/currencies';
import { safeFetch } from '../lib/apiClient';

interface TradeInCalculatorProps {
  currentCurrency: Currency;
  onClose: () => void;
  onApplyVoucherToCart: (code: string, discountUSD: number) => void;
}

export const TradeInCalculator: React.FC<TradeInCalculatorProps> = ({
  currentCurrency,
  onClose,
  onApplyVoucherToCart,
}) => {
  const [brand, setBrand] = useState('Apple');
  const [model, setModel] = useState('iPhone 15 Pro Max');
  const [storage, setStorage] = useState('256GB');
  const [condition, setCondition] = useState<'Like New' | 'Good' | 'Fair'>('Like New');
  const [screenIntact, setScreenIntact] = useState(true);

  const [loading, setLoading] = useState(false);
  const [estimate, setEstimate] = useState<TradeInEstimateResult | null>(null);
  const [copiedVoucher, setCopiedVoucher] = useState(false);

  const handleCalculate = async () => {
    setLoading(true);
    try {
      const res = await safeFetch('/api/trade-in', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ brand, model, storage, condition, screenIntact }),
      });
      const data = await res.json();
      setEstimate(data);
    } catch (err) {
      // Fallback estimate calculation
      let baseVal = 500;
      if (condition === 'Good') baseVal *= 0.85;
      if (condition === 'Fair') baseVal *= 0.65;
      if (!screenIntact) baseVal *= 0.6;

      const totalVal = Math.round(baseVal) + 50;
      const code = `SYR-TRADE-${Math.floor(100000 + Math.random() * 900000)}`;

      setEstimate({
        estimatedValueUSD: Math.round(baseVal),
        bonusCreditUSD: 50,
        totalTradeInUSD: totalVal,
        currencyValues: {
          USD: `$${totalVal}`,
          EGP: `${(totalVal * 49.5).toLocaleString()} ج.م`,
          EUR: `€${Math.round(totalVal * 0.92)}`,
          SYP: `${(totalVal * 14800).toLocaleString()} ل.س`,
          AED: `${Math.round(totalVal * 3.67)} د.إ`,
          SAR: `${Math.round(totalVal * 3.75)} ر.س`,
        },
        voucherCode: code,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCopyAndApply = () => {
    if (!estimate) return;
    navigator.clipboard.writeText(estimate.voucherCode);
    setCopiedVoucher(true);
    onApplyVoucherToCart(estimate.voucherCode, estimate.totalTradeInUSD);
    setTimeout(() => setCopiedVoucher(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-2xl w-full text-white shadow-2xl relative p-6 sm:p-8 my-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 rounded-full text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 pb-6 border-b border-zinc-800">
          <div className="p-3 bg-white text-black rounded-xl">
            <RefreshCw className="w-6 h-6 text-black" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              Trade-In & Upgrade Program
            </h2>
            <p className="text-xs text-zinc-400">
              Turn your current smartphone into instant store credit + $50 bonus voucher.
            </p>
          </div>
        </div>

        {/* Input Form */}
        <div className="space-y-5 my-6">
          {/* Brand & Model */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Brand</label>
              <select
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-zinc-500"
              >
                <option value="Apple">Apple</option>
                <option value="Samsung">Samsung</option>
                <option value="Google">Google</option>
                <option value="Xiaomi">Xiaomi</option>
                <option value="Nothing">Nothing</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Model</label>
              <input
                type="text"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="e.g. iPhone 15 Pro Max, Galaxy S23 Ultra"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-zinc-500"
              />
            </div>
          </div>

          {/* Storage & Condition */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Storage Size</label>
              <select
                value={storage}
                onChange={(e) => setStorage(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-zinc-500"
              >
                <option value="128GB">128GB</option>
                <option value="256GB">256GB</option>
                <option value="512GB">512GB</option>
                <option value="1TB">1TB</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Overall Condition</label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as any)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-zinc-500"
              >
                <option value="Like New">Like New (Mint Condition, No Scratches)</option>
                <option value="Good">Good (Normal Wear & Minor Marks)</option>
                <option value="Fair">Fair (Noticeable Scratches / Scuffs)</option>
              </select>
            </div>
          </div>

          {/* Screen Checkbox */}
          <div className="flex items-center gap-3 p-3 bg-zinc-900/60 border border-zinc-800 rounded-xl">
            <input
              type="checkbox"
              id="screenIntact"
              checked={screenIntact}
              onChange={(e) => setScreenIntact(e.target.checked)}
              className="w-4 h-4 rounded border-zinc-700 bg-zinc-950 text-white focus:ring-0 cursor-pointer"
            />
            <label htmlFor="screenIntact" className="text-xs text-zinc-300 font-medium cursor-pointer">
              Screen and back glass are intact (no cracks or display bleed)
            </label>
          </div>

          <button
            onClick={handleCalculate}
            disabled={loading}
            className="w-full py-3.5 bg-white text-black hover:bg-zinc-200 font-extrabold rounded-xl text-sm transition-all cursor-pointer shadow-lg flex items-center justify-center gap-2"
          >
            {loading ? 'Evaluating Market Valuation...' : 'Calculate Trade-In Credit'}
          </button>
        </div>

        {/* Valuation Result */}
        {estimate && (
          <div className="p-6 bg-zinc-900 border border-zinc-700 rounded-2xl space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div>
                <span className="text-xs text-zinc-400 uppercase font-semibold">Total Trade-In Value</span>
                <div className="text-3xl font-extrabold text-white">
                  {formatPrice(estimate.totalTradeInUSD, currentCurrency)}
                </div>
              </div>
              <div className="text-right">
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase">
                  +$50 Bonus Included
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between bg-zinc-950 p-3 rounded-xl border border-zinc-800 text-xs">
              <div>
                <span className="text-zinc-500 font-medium block">Voucher Code</span>
                <span className="font-mono font-bold text-white text-sm">{estimate.voucherCode}</span>
              </div>

              <button
                onClick={handleCopyAndApply}
                className="px-3.5 py-2 bg-white text-black hover:bg-zinc-200 font-bold rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                {copiedVoucher ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> Voucher Applied
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> Apply To Cart
                  </>
                )}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
