import React, { useState } from 'react';
import { 
  ShieldCheck, 
  KeyRound, 
  Lock, 
  Mail, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  RefreshCw,
  Smartphone
} from 'lucide-react';
import { adminStore } from '../../lib/adminStore';
import { AdminUser } from '../../types';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: AdminUser) => void;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [view, setView] = useState<'login' | '2fa' | 'forgot' | 'change_password'>('login');
  const [email, setEmail] = useState('admin@elsory.com');
  const [password, setPassword] = useState('admin123');
  const [rememberMe, setRememberMe] = useState(true);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [pendingUser, setPendingUser] = useState<AdminUser | null>(null);
  
  // Forgot / Change password state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      const users = adminStore.getAdminUsers();
      const user = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());

      if (!user) {
        setErrorMsg('Invalid admin credentials. Please verify email and password.');
        return;
      }

      if (!user.active) {
        setErrorMsg('This admin user account has been deactivated. Contact Super Admin.');
        return;
      }

      if (user.twoFactorEnabled) {
        setPendingUser(user);
        setView('2fa');
      } else {
        adminStore.setCurrentUser(user);
        onLoginSuccess(user);
      }
    }, 500);
  };

  const handle2FASubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (twoFactorCode.trim().length !== 6 && twoFactorCode !== '123456') {
      setErrorMsg('Invalid 2FA security token. Use test token 123456 or Google Authenticator.');
      return;
    }

    if (pendingUser) {
      adminStore.setCurrentUser(pendingUser);
      onLoginSuccess(pendingUser);
    }
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('Security password reset link dispatched to admin email.');
    setTimeout(() => {
      setSuccessMsg('');
      setView('login');
    }, 2500);
  };

  const handleChangePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (newPassword.length < 6) {
      setErrorMsg('New password must be at least 6 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMsg('New passwords do not match.');
      return;
    }

    setSuccessMsg('Admin password successfully updated.');
    setTimeout(() => {
      setSuccessMsg('');
      setView('login');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl relative overflow-hidden">
        
        {/* Header Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800 hover:border-zinc-600 rounded-full cursor-pointer transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Branding Header */}
        <div className="flex flex-col items-center text-center space-y-2 mb-6 pt-2">
          <div className="w-12 h-12 bg-white text-black font-black text-2xl rounded-2xl flex items-center justify-center shadow-lg">
            S
          </div>
          <div>
            <h2 className="text-xl font-black text-white tracking-wide">
              ElSory Admin Control Center
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Enterprise Store & CMS Management Gateway
            </p>
          </div>
        </div>

        {/* Notification Messages */}
        {errorMsg && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400 text-xs flex items-center gap-2 mb-4">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* VIEW 1: LOGIN FORM */}
        {view === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-zinc-400 font-bold mb-1.5">Admin Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@elsory.com"
                  className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl py-2.5 pl-9 pr-3 text-white outline-none"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-zinc-400 font-bold">Password</label>
                <button
                  type="button"
                  onClick={() => setView('forgot')}
                  className="text-zinc-400 hover:text-white font-semibold text-[11px] cursor-pointer"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl py-2.5 pl-9 pr-3 text-white outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 text-zinc-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-zinc-700 bg-zinc-900 text-white focus:ring-0"
                />
                <span>Remember session on this browser</span>
              </label>

              <button
                type="button"
                onClick={() => setView('change_password')}
                className="text-zinc-400 hover:text-white font-semibold text-[11px] cursor-pointer"
              >
                Change Password
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-white text-black hover:bg-zinc-200 font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg mt-4 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-black" />
                  <span>Authenticating...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4 text-black" />
                  <span>Access Admin Control Center</span>
                </>
              )}
            </button>

            {/* Quick Demo Credentials Bar */}
            <div className="pt-4 border-t border-zinc-800/80 text-[11px] text-zinc-500 flex flex-col gap-1">
              <span className="font-bold text-zinc-400 uppercase tracking-wider text-[10px]">Demo Admin Login:</span>
              <div className="flex items-center justify-between font-mono bg-zinc-900 p-2 rounded-lg text-zinc-300">
                <span>admin@elsory.com</span>
                <span className="text-emerald-400">Super Admin</span>
              </div>
            </div>
          </form>
        )}

        {/* VIEW 2: TWO FACTOR AUTHENTICATION */}
        {view === '2fa' && (
          <form onSubmit={handle2FASubmit} className="space-y-4 text-xs">
            <div className="p-3 bg-indigo-500/10 border border-indigo-500/30 rounded-2xl text-center space-y-1">
              <Smartphone className="w-6 h-6 text-indigo-400 mx-auto" />
              <h3 className="font-extrabold text-white text-sm">Two-Factor Security Verification</h3>
              <p className="text-zinc-400 text-[11px]">
                Enter the 6-digit 2FA code from Google Authenticator or SMS. (Test Code: <strong className="text-white">123456</strong>)
              </p>
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1.5">6-Digit 2FA Token</label>
              <input
                type="text"
                required
                maxLength={6}
                value={twoFactorCode}
                onChange={(e) => setTwoFactorCode(e.target.value)}
                placeholder="123456"
                className="w-full text-center tracking-[0.5em] text-lg font-mono bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl py-3 text-white outline-none"
                autoFocus
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-white text-black hover:bg-zinc-200 font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <span>Verify & Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setView('login')}
              className="w-full text-center text-zinc-500 hover:text-white font-semibold text-xs py-1"
            >
              Back to Login
            </button>
          </form>
        )}

        {/* VIEW 3: FORGOT PASSWORD */}
        {view === 'forgot' && (
          <form onSubmit={handleForgotSubmit} className="space-y-4 text-xs">
            <div className="space-y-1">
              <h3 className="font-extrabold text-white text-sm">Reset Admin Password</h3>
              <p className="text-zinc-400 text-[11px]">
                Enter your administrative email to receive a password reset link.
              </p>
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1.5">Admin Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl py-2.5 px-3 text-white outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-white text-black hover:bg-zinc-200 font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <span>Send Recovery Link</span>
            </button>

            <button
              type="button"
              onClick={() => setView('login')}
              className="w-full text-center text-zinc-500 hover:text-white font-semibold text-xs py-1"
            >
              Back to Login
            </button>
          </form>
        )}

        {/* VIEW 4: CHANGE PASSWORD */}
        {view === 'change_password' && (
          <form onSubmit={handleChangePasswordSubmit} className="space-y-3 text-xs">
            <h3 className="font-extrabold text-white text-sm mb-2">Update Admin Password</h3>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">Current Password</label>
              <input
                type="password"
                required
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl py-2 px-3 text-white outline-none"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">New Password</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl py-2 px-3 text-white outline-none"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">Confirm New Password</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-white rounded-xl py-2 px-3 text-white outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-white text-black hover:bg-zinc-200 font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg mt-3"
            >
              <span>Update Password</span>
            </button>

            <button
              type="button"
              onClick={() => setView('login')}
              className="w-full text-center text-zinc-500 hover:text-white font-semibold text-xs py-1"
            >
              Cancel & Back
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
