import React, { useState } from 'react';
import { Brain, FileText, Plus, Trash2, CheckCircle, Sparkles, MessageSquare } from 'lucide-react';
import { adminStore } from '../../../lib/adminStore';
import { AIDocument } from '../../../types';

export const AIManagementTab: React.FC = () => {
  const [aiDocs, setAiDocs] = useState<AIDocument[]>(adminStore.getAIDocs());
  const [docTitle, setDocTitle] = useState('');
  const [docCategory, setDocCategory] = useState('Warranty');
  const [docContent, setDocContent] = useState('');
  const [showModal, setShowModal] = useState(false);

  const refreshDocs = () => {
    setAiDocs([...adminStore.getAIDocs()]);
  };

  const handleSaveDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim() || !docContent.trim()) return;

    const newDoc: AIDocument = {
      id: `doc-${Date.now()}`,
      title: docTitle,
      category: docCategory,
      content: docContent,
      uploadedAt: new Date().toISOString(),
      size: `${Math.round(docContent.length / 100)} KB`,
      status: 'Indexed',
    };

    adminStore.saveAIDoc(newDoc);
    refreshDocs();
    setShowModal(false);
    setDocTitle('');
    setDocContent('');
  };

  const handleDeleteDoc = (id: string) => {
    adminStore.deleteAIDoc(id);
    refreshDocs();
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Header */}
      <div className="p-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" />
            <span>AI Concierge Knowledge Base & Vector RAG</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Train the Gemini AI Assistant with custom store policies, warranties, and Zagazig courier protocols.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ Upload Knowledge Document</span>
        </button>
      </div>

      {/* Docs List */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {aiDocs.map((doc) => (
          <div key={doc.id} className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-2xl space-y-3 flex flex-col justify-between">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-purple-400 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">
                  {doc.category}
                </span>
                <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-semibold">
                  <CheckCircle className="w-3 h-3" /> Indexed
                </span>
              </div>
              <h3 className="font-extrabold text-white text-sm line-clamp-1">{doc.title}</h3>
              <p className="text-xs text-zinc-400 line-clamp-3 leading-relaxed">{doc.content}</p>
            </div>

            <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-[10px] text-zinc-500 font-mono">
              <span>{doc.size} &bull; {new Date(doc.uploadedAt).toLocaleDateString()}</span>
              <button
                onClick={() => handleDeleteDoc(doc.id)}
                className="p-1.5 bg-rose-950/50 hover:bg-rose-900 text-rose-300 rounded-lg cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-lg w-full p-6 text-white space-y-4">
            <h3 className="font-extrabold text-base">Add AI Knowledge Document</h3>

            <form onSubmit={handleSaveDoc} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 font-bold mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  placeholder="e.g. Return & Exchange Policy 2026"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Category</label>
                <select
                  value={docCategory}
                  onChange={(e) => setDocCategory(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                >
                  <option value="Warranty">Warranty & Hardware Policy</option>
                  <option value="Shipping">Shipping & Courier Protocols</option>
                  <option value="Repair">Micro-Repair Technical Specs</option>
                  <option value="Payments">Payments & Instalments (Valu / InstaPay)</option>
                </select>
              </div>

              <div>
                <label className="block text-zinc-400 font-bold mb-1">Document Text / Knowledge Content</label>
                <textarea
                  required
                  rows={5}
                  value={docContent}
                  onChange={(e) => setDocContent(e.target.value)}
                  placeholder="Type or paste policy details that the AI assistant should use when answering customer questions..."
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 bg-zinc-800 text-white rounded-xl">
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl">
                  Index Document
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
