import { Product } from '../types';

export const PRODUCTS: Product[] = [
  {
    id: 'syr-iphone16promax',
    name: 'iPhone 16 Pro Max',
    brand: 'Apple',
    category: 'Smartphones',
    priceUSD: 1199,
    originalPriceUSD: 1299,
    rating: 4.9,
    reviewsCount: 328,
    badge: 'Bestseller',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Forged in Grade 5 titanium with an all-new desert titanium colorway. Features the ultra-powerful A18 Pro chip, 48MP Fusion camera with 4K 120 fps Dolby Vision recording, and the largest iPhone display ever.',
    features: [
      'Grade 5 Titanium enclosure with Ceramic Shield',
      'A18 Pro chip with 6-core GPU',
      '48MP Fusion Camera + 5x Telephoto Zoom',
      'Camera Control button for intuitive photography',
      'Up to 33 hours video playback'
    ],
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Natural Titanium', hex: '#beaba1' },
      { name: 'Desert Titanium', hex: '#cfa98b' },
      { name: 'White Titanium', hex: '#f0f0f0' },
      { name: 'Black Titanium', hex: '#2b2b2e' }
    ],
    storageOptions: [
      { size: '256GB', priceUSD: 1199 },
      { size: '512GB', priceUSD: 1399 },
      { size: '1TB', priceUSD: 1599 }
    ],
    specsDetail: {
      display: '6.9-inch Super Retina XDR OLED, 120Hz ProMotion, 2000 nits',
      chipset: 'Apple A18 Pro (3nm)',
      mainCamera: '48MP Fusion + 48MP Ultra Wide + 12MP 5x Telephoto',
      selfieCamera: '12MP TrueDepth with Autofocus',
      battery: '4,685 mAh',
      charging: '45W Wired, 25W MagSafe Wireless',
      weight: '227 grams',
      network: '5G NR (Sub-6GHz and mmWave), Wi-Fi 7',
      os: 'iOS 18 with Apple Intelligence',
      waterResistance: 'IP68 (6m up to 30 mins)'
    }
  },
  {
    id: 'syr-s25ultra',
    name: 'Samsung Galaxy S25 Ultra',
    brand: 'Samsung',
    category: 'Smartphones',
    priceUSD: 1299,
    originalPriceUSD: 1399,
    rating: 4.9,
    reviewsCount: 215,
    badge: 'New',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'The ultimate Android flagship with Galaxy AI built into every interaction. Sculpted titanium frame, built-in S Pen, Snapdragon 8 Elite chip, and a breathtaking 200MP Quad Tele System camera.',
    features: [
      'Snapdragon 8 Elite for Galaxy (3nm)',
      'Built-in precision S Pen',
      '200MP Camera with 100x Space Zoom',
      'Corning Gorilla Armor anti-reflective glass',
      'Galaxy AI Live Translate & Circle to Search'
    ],
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1580910051074-3eb694886505?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Titanium Black', hex: '#1c1d21' },
      { name: 'Titanium Silver', hex: '#d4d8dd' },
      { name: 'Titanium Blue', hex: '#3b5368' },
      { name: 'Titanium Gray', hex: '#8e939a' }
    ],
    storageOptions: [
      { size: '256GB', priceUSD: 1299 },
      { size: '512GB', priceUSD: 1499 },
      { size: '1TB', priceUSD: 1749 }
    ],
    specsDetail: {
      display: '6.8-inch Dynamic AMOLED 2X, 120Hz, 2600 nits Anti-Glare',
      chipset: 'Qualcomm Snapdragon 8 Elite (3nm)',
      mainCamera: '200MP Main + 50MP Periscope 5x + 50MP Ultra Wide + 10MP 3x',
      selfieCamera: '12MP Dual Pixel PDAF',
      battery: '5,000 mAh',
      charging: '45W Super Fast Wired, 15W Wireless 2.0',
      weight: '219 grams',
      network: '5G, Wi-Fi 7, Ultra Wideband (UWB)',
      os: 'Android 15 with One UI 7.1',
      waterResistance: 'IP68'
    }
  },
  {
    id: 'syr-xiaomi15ultra',
    name: 'Xiaomi 15 Ultra Leica Edition',
    brand: 'Xiaomi',
    category: 'Smartphones',
    priceUSD: 1149,
    originalPriceUSD: 1249,
    rating: 4.9,
    reviewsCount: 189,
    badge: 'Hot',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Co-engineered with Leica. Quad 50MP camera array featuring 1-inch Sony LYT-900 sensor, 200MP periscope telephoto, Snapdragon 8 Elite, and 90W HyperCharge.',
    features: [
      'Leica Vario-Summilux Quad Camera Optics',
      '1-inch Sony LYT-900 Primary Sensor',
      '200MP Periscope Telephoto Lens',
      'Snapdragon 8 Elite Processor',
      '90W HyperCharge + 80W Wireless Charging'
    ],
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Ceramic Black', hex: '#0a0a0b' },
      { name: 'Titanium Grey', hex: '#636569' },
      { name: 'Silver White', hex: '#f0f0f2' }
    ],
    storageOptions: [
      { size: '512GB / 16GB RAM', priceUSD: 1149 },
      { size: '1TB / 16GB RAM', priceUSD: 1299 }
    ],
    specsDetail: {
      display: '6.73-inch LTPO AMOLED, 120Hz, 3200 nits WQHD+',
      chipset: 'Qualcomm Snapdragon 8 Elite (3nm)',
      mainCamera: '50MP 1-inch LYT-900 OIS + 200MP 4.3x Periscope + 50MP 3.2x + 50MP UW',
      selfieCamera: '32MP 4K60 Video',
      battery: '5,300 mAh Silicon-Carbon',
      charging: '90W Wired, 80W Wireless',
      weight: '220 grams',
      network: '5G Dual SIM, Wi-Fi 7',
      os: 'Xiaomi HyperOS 2 (Android 15)',
      waterResistance: 'IP68 Dust & Water Resistant'
    }
  },
  {
    id: 'syr-oneplus13',
    name: 'OnePlus 13 Hasselblad Flagship',
    brand: 'OnePlus',
    category: 'Smartphones',
    priceUSD: 899,
    originalPriceUSD: 999,
    rating: 4.8,
    reviewsCount: 162,
    badge: 'New',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Extreme speed meets Hasselblad color science. Features 2K 120Hz quad-curved display, Snapdragon 8 Elite, 6000mAh Glacier Battery, and 100W SUPERVOOC charging.',
    features: [
      'Hasselblad 5th-Gen Mobile Camera System',
      '6000 mAh Silicon-Anode Glacier Battery',
      '100W Wired + 50W AIRVOOC Wireless Charging',
      'IP69 Extreme Water Pressure Resistance',
      'Snapdragon 8 Elite with Cryo-Velocity Cooling'
    ],
    image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Midnight Black', hex: '#151516' },
      { name: 'Emerald Green', hex: '#1d3e33' },
      { name: 'Arctic White', hex: '#f2f3f5' }
    ],
    storageOptions: [
      { size: '256GB / 12GB RAM', priceUSD: 899 },
      { size: '512GB / 16GB RAM', priceUSD: 999 }
    ],
    specsDetail: {
      display: '6.82-inch 2K Oriental AMOLED, 120Hz LTPO 4.0, 4500 nits',
      chipset: 'Qualcomm Snapdragon 8 Elite (3nm)',
      mainCamera: '50MP Sony LYT-808 OIS + 50MP 3x Periscope + 50MP UW',
      selfieCamera: '32MP Sony IMX615',
      battery: '6,000 mAh Glacier Battery',
      charging: '100W SUPERVOOC, 50W AIRVOOC Wireless',
      weight: '213 grams',
      network: '5G Dual SIM, Wi-Fi 7',
      os: 'OxygenOS 15 (Android 15)',
      waterResistance: 'IP68 & IP69 Dual Certification'
    }
  },
  {
    id: 'syr-honormagic7pro',
    name: 'Honor Magic7 Pro AI Falcon Camera',
    brand: 'Honor',
    category: 'Smartphones',
    priceUSD: 1049,
    originalPriceUSD: 1149,
    rating: 4.8,
    reviewsCount: 112,
    badge: 'Hot',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'AI-driven photography powerhouse with 200MP Telephoto Falcon Camera, 3D Depth Face ID, Snapdragon 8 Elite, and eye-protection Oasis display.',
    features: [
      '200MP AI Telephoto Falcon Camera System',
      'Hardware 3D Depth Face Unlock + 3D Ultrasonic Fingerprint',
      'Honor Oasis Eye-Care Display with 4320Hz PWM',
      'Honor AI Agent for autonomous task execution',
      '5800 mAh Qinghai Lake Battery'
    ],
    image: 'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Lunar Grey', hex: '#4f535a' },
      { name: 'Velvet Black', hex: '#101011' },
      { name: 'Breeze Blue', hex: '#7a9ec2' }
    ],
    storageOptions: [
      { size: '512GB / 12GB RAM', priceUSD: 1049 }
    ],
    specsDetail: {
      display: '6.8-inch Quad-Curved OLED, 120Hz LTPO, 5000 nits peak',
      chipset: 'Qualcomm Snapdragon 8 Elite (3nm)',
      mainCamera: '50MP Variable Aperture + 200MP 3x Telephoto + 50MP UW',
      selfieCamera: '50MP + 3D Depth Camera',
      battery: '5,850 mAh Silicon-Carbon',
      charging: '100W SuperCharge, 80W Wireless',
      weight: '223 grams',
      network: '5G Dual SIM, Wi-Fi 7',
      os: 'MagicOS 9.0 (Android 15)',
      waterResistance: 'IP68 & IP69'
    }
  },
  {
    id: 'syr-huaweimate70pro',
    name: 'Huawei Mate 70 Pro HarmonyOS NEXT',
    brand: 'Huawei',
    category: 'Smartphones',
    priceUSD: 1199,
    originalPriceUSD: 1299,
    rating: 4.9,
    reviewsCount: 140,
    badge: 'Luxury Edition',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Powered by native Kirin 9100 silicon and HarmonyOS NEXT. Kunlun Glass 2.0 durability, XMAGE Red Maple camera technology, and Satellite calling capability.',
    features: [
      'Pure Native HarmonyOS NEXT OS Engine',
      'Huawei XMAGE Red Maple Imaging Engine',
      'Beidou & Tiantong Satellite Calling System',
      '2nd Gen Kunlun Basalt Glass Enclosure',
      '100W Wired + 80W Wireless SuperCharge'
    ],
    image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Spruce Green', hex: '#2c3e35' },
      { name: 'Obsidian Black', hex: '#121213' },
      { name: 'Snow White', hex: '#f0f2f5' }
    ],
    storageOptions: [
      { size: '512GB', priceUSD: 1199 },
      { size: '1TB', priceUSD: 1349 }
    ],
    specsDetail: {
      display: '6.9-inch LTPO OLED, 1-120Hz, 2500 nits, Kunlun Glass 2',
      chipset: 'Kirin 9100 Ultra-Efficiency 5G Engine',
      mainCamera: '50MP XMAGE Variable Aperture + 48MP Periscope + 40MP UW',
      selfieCamera: '13MP Ultra Wide + 3D Depth Sensing',
      battery: '5,500 mAh High Capacity',
      charging: '100W Wired, 80W Wireless',
      weight: '226 grams',
      network: '5G, Satellite Calling',
      os: 'HarmonyOS NEXT (Native Kernel)',
      waterResistance: 'IP68 (up to 6m)'
    }
  },
  {
    id: 'syr-nothing2a',
    name: 'Nothing Phone (2a) Plus',
    brand: 'Nothing',
    category: 'Smartphones',
    priceUSD: 449,
    originalPriceUSD: 499,
    rating: 4.8,
    reviewsCount: 142,
    badge: 'Hot',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Iconic transparent design with Glyph Interface illumination. Powered by the MediaTek Dimensity 7350 Pro 5G processor and dual 50MP studio-grade camera sensors.',
    features: [
      'Signature Glyph Interface lighting',
      'MediaTek Dimensity 7350 Pro 5G',
      'Dual 50MP Rear Cameras + 50MP Selfie',
      'Nothing OS 3.0 minimalist interface',
      '120Hz Flexible AMOLED Display'
    ],
    image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Metallic Grey', hex: '#4e5359' },
      { name: 'Pure Black', hex: '#121212' },
      { name: 'Milky White', hex: '#e8e8e8' }
    ],
    storageOptions: [
      { size: '256GB / 12GB RAM', priceUSD: 449 }
    ],
    specsDetail: {
      display: '6.7-inch Flexible AMOLED, 120Hz Adaptive, 1300 nits',
      chipset: 'MediaTek Dimensity 7350 Pro (4nm)',
      mainCamera: '50MP OIS Main + 50MP Ultra Wide',
      selfieCamera: '50MP 4K Video Selfie',
      battery: '5,000 mAh',
      charging: '50W Fast Charging',
      weight: '190 grams',
      network: '5G Dual SIM',
      os: 'Nothing OS 3.0 (Android 15)',
      waterResistance: 'IP54 Splash Resistant'
    }
  },
  {
    id: 'syr-gold-iphone16',
    name: '24K Gold Syrian Falcon Edition iPhone 16 Pro Max',
    brand: 'Apple',
    category: 'Luxury Editions',
    priceUSD: 4800,
    originalPriceUSD: 5200,
    rating: 5.0,
    reviewsCount: 19,
    badge: 'Luxury Edition',
    isFeatured: true,
    inStock: true,
    warrantyYears: 2,
    description: 'Exclusive hand-crafted luxury edition plated in 24-Karat Solid Gold with custom laser-engraved Syrian Falcon emblem on the back. Limited to 50 numbered pieces worldwide.',
    features: [
      '24K Solid Gold Electroplated Enclosure',
      'Custom Engraved Syrian Falcon Heritage Emblem',
      'Includes Wooden Collector Box with Authenticity Certificate',
      'VIP Priority 24/7 Concierge & Express World Warranty',
      '1TB Storage Top Configuration'
    ],
    image: 'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: '24K Yellow Gold', hex: '#d4af37' },
      { name: 'Rose Gold & Black Diamond', hex: '#b76e79' }
    ],
    storageOptions: [
      { size: '1TB Luxury Box', priceUSD: 4800 }
    ],
    specsDetail: {
      display: '6.9-inch Super Retina XDR OLED, 120Hz ProMotion',
      chipset: 'Apple A18 Pro Custom Tuned',
      mainCamera: '48MP Triple Lens Studio System',
      selfieCamera: '12MP TrueDepth',
      battery: '4,685 mAh',
      charging: '45W Fast Charging',
      weight: '255 grams (Gold Plated)',
      network: '5G Unlocked Global',
      os: 'iOS 18 Pro',
      waterResistance: 'IP68'
    }
  },
  {
    id: 'syr-pixel9pro',
    name: 'Google Pixel 9 Pro XL',
    brand: 'Google',
    category: 'Smartphones',
    priceUSD: 1099,
    originalPriceUSD: 1199,
    rating: 4.8,
    reviewsCount: 178,
    badge: 'New',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Google Tensor G4 chip engineered for Gemini AI intelligence. Sleek polished metal frame with silky matte back glass and studio-grade pro triple camera array.',
    features: [
      'Google Tensor G4 with Titan M2 security',
      'Gemini Nano with Multimodality built-in',
      'Super Res Zoom up to 30x + Video Boost',
      '7 years of Android OS updates',
      '24+ hour battery with Extreme Battery Saver'
    ],
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Obsidian', hex: '#1b1b1b' },
      { name: 'Porcelain', hex: '#f3f3f1' },
      { name: 'Hazel', hex: '#525a52' },
      { name: 'Rose Quartz', hex: '#f0c7d4' }
    ],
    storageOptions: [
      { size: '128GB', priceUSD: 1099 },
      { size: '256GB', priceUSD: 1199 },
      { size: '512GB', priceUSD: 1349 }
    ],
    specsDetail: {
      display: '6.8-inch Super Actua OLED, 1-120Hz LTPO, 3000 nits peak',
      chipset: 'Google Tensor G4 (4nm)',
      mainCamera: '50MP Main OIS + 48MP Ultra Wide + 48MP 5x Telephoto',
      selfieCamera: '42MP Ultra Wide with Autofocus',
      battery: '5,060 mAh',
      charging: '37W Fast Charging, Wireless Qi',
      weight: '221 grams',
      network: '5G, Wi-Fi 7',
      os: 'Android 15 Native Google',
      waterResistance: 'IP68'
    }
  },
  {
    id: 'syr-ipadprom4',
    name: 'iPad Pro M4 13-inch',
    brand: 'Apple',
    category: 'Tablets',
    priceUSD: 1299,
    originalPriceUSD: 1399,
    rating: 4.9,
    reviewsCount: 94,
    badge: 'Bestseller',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Impossibly thin design powered by the groundbreaking Apple M4 chip. Breakthrough Tandem OLED Ultra Retina XDR display with incredible brightness and contrast.',
    features: [
      'Apple M4 chip with 10-core GPU',
      'Ultra Retina XDR Tandem OLED Display',
      'Supports Apple Pencil Pro and Magic Keyboard',
      'Ultra-thin 5.1mm precision enclosure',
      'Thunderbolt / USB 4 port'
    ],
    image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Space Black', hex: '#232428' },
      { name: 'Silver', hex: '#e2e4e8' }
    ],
    storageOptions: [
      { size: '256GB Wi-Fi', priceUSD: 1299 },
      { size: '512GB Wi-Fi + Cellular', priceUSD: 1699 }
    ],
    specsDetail: {
      display: '13-inch Tandem OLED Ultra Retina XDR, 120Hz ProMotion, 1600 nits peak HDR',
      chipset: 'Apple M4 chip (9-core / 10-core CPU)',
      mainCamera: '12MP Wide Camera + LiDAR Scanner',
      selfieCamera: 'Landscape 12MP Center Stage',
      battery: '38.99 watt-hour rechargeable',
      charging: '30W USB-C',
      weight: '579 grams',
      network: '5G Cellular optional, Wi-Fi 6E',
      os: 'iPadOS 18',
      waterResistance: 'Standard indoor build'
    }
  },
  {
    id: 'syr-airpodspro2',
    name: 'AirPods Pro 2 (USB-C)',
    brand: 'Apple',
    category: 'Audio & Sound',
    priceUSD: 249,
    originalPriceUSD: 279,
    rating: 4.9,
    reviewsCount: 512,
    badge: 'Bestseller',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Pro-level Active Noise Cancellation twice as effective as previous generation. Transparency mode, Personalized Spatial Audio with dynamic head tracking, and USB-C MagSafe case.',
    features: [
      'H2 Apple Silicon Chip',
      'Adaptive Audio & Conversation Awareness',
      'Up to 6 hours listening time on single charge',
      'IP54 dust, sweat, and water resistance',
      'Precision Finding with U1 chip in case'
    ],
    image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Gloss White', hex: '#ffffff' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Apple H2 Headphone Chip + U1 Case Chip',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'Up to 30 hours total with charging case',
      charging: 'USB-C, MagSafe, Apple Watch Charger',
      weight: '5.3 grams per earbud',
      network: 'Bluetooth 5.3',
      os: 'Apple Audio OS',
      waterResistance: 'IP54'
    }
  },
  {
    id: 'syr-watchultra2',
    name: 'Apple Watch Ultra 2 Titanium',
    brand: 'Apple',
    category: 'Smartwatches',
    priceUSD: 799,
    originalPriceUSD: 849,
    rating: 4.9,
    reviewsCount: 164,
    badge: 'Hot',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'The most capable and rugged Apple watch. Corrosion-resistant titanium case with 3000-nit display, double tap gesture control, dual-frequency GPS, and up to 72 hours battery life in low power mode.',
    features: [
      '49mm Grade 5 Titanium Case',
      '3000-nit display - brightest Apple display',
      'S9 SiP chip with Double Tap gesture',
      'Precision dual-frequency GPS (L1 and L5)',
      '100m water resistance + EN13319 dive certified'
    ],
    image: 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Natural Titanium', hex: '#c0c2c6' },
      { name: 'Black Titanium', hex: '#262628' }
    ],
    specsDetail: {
      display: '49mm Sapphire Crystal Always-On Retina, 3000 nits',
      chipset: 'Apple S9 SiP 64-bit dual-core',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: 'Up to 36 hours normal, 72 hours low power',
      charging: 'Magnetic Fast Charger to USB-C',
      weight: '61.4 grams',
      network: 'GPS + Cellular',
      os: 'watchOS 11',
      waterResistance: '100m Water Resistant'
    }
  },
  {
    id: 'syr-magsafebank',
    name: 'Anker MagGo 10,000mAh Ultra-Fast Power Bank',
    brand: 'Anker',
    category: 'Accessories',
    priceUSD: 89,
    originalPriceUSD: 99,
    rating: 4.8,
    reviewsCount: 230,
    badge: 'Special Offer',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Qi2-certified 15W wireless magnetic power bank with smart digital screen showing real-time battery percentage and remaining charging time. Premium metallic finish.',
    features: [
      'Qi2 Certified 15W Ultra Magnetic Fast Wireless',
      '10,000mAh capacity charges iPhone 16 Pro 2.2 times',
      'Smart Color Display with live wattage output',
      '27W USB-C bi-directional wired fast charging',
      'Built-in foldable kickstand'
    ],
    image: 'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Matte Black', hex: '#111111' },
      { name: 'Glacier White', hex: '#f0f0f0' }
    ],
    specsDetail: {
      display: 'LCD Power Display',
      chipset: 'Anker ActiveShield 2.0 Temperature Protection',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: '10,000 mAh High-Density Li-Po',
      charging: '15W Wireless Qi2 + 27W USB-C PD',
      weight: '250 grams',
      network: 'N/A',
      os: 'PowerIQ 4.0',
      waterResistance: 'Indoor'
    }
  },
  {
    id: 'syr-repair-iphone-screen',
    name: 'iPhone Original OLED Screen Replacement (Express 30-Min)',
    brand: 'Apple',
    category: 'Repair Services',
    priceUSD: 85,
    originalPriceUSD: 110,
    rating: 5.0,
    reviewsCount: 420,
    badge: 'Special Offer',
    isFeatured: true,
    inStock: true,
    warrantyYears: 1,
    description: 'Professional original OLED display replacement at ElSory Store Zagazig Center. Includes TrueTone transfer, dust-and-water seal restoration, and 12-month official store warranty.',
    features: [
      'Original OLED / Super Retina Display Panel',
      'TrueTone & Auto-Brightness IC programming transfer',
      'Water & Dust Resistance Gasket Seal Restoration',
      'Express 30-Minute Turnaround at Zagazig Branch',
      '12 Months Full Replacement Warranty'
    ],
    image: 'https://images.unsplash.com/photo-1597740985671-2a8a3b80502e?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1597740985671-2a8a3b80502e?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Original Factory Display', hex: '#000000' }
    ],
    specsDetail: {
      display: 'OEM / Original OLED Panel with TrueTone Support',
      chipset: 'Original Touch Controller IC Transferred',
      mainCamera: 'Preserved',
      selfieCamera: 'Preserved & Calibrated',
      battery: 'No battery impact',
      charging: 'N/A',
      weight: 'Same as original',
      network: 'N/A',
      os: 'All iOS versions supported',
      waterResistance: 'IP68 Gasket Re-sealed'
    }
  },
  {
    id: 'syr-repair-battery',
    name: 'Genuine High-Capacity Battery Replacement & Health Calibration',
    brand: 'Apple',
    category: 'Repair Services',
    priceUSD: 35,
    originalPriceUSD: 45,
    rating: 4.9,
    reviewsCount: 310,
    badge: 'Bestseller',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Restore 100% Battery Health with authentic high-density battery cells. Performed by certified technicians at ElSory Store Zagazig & Cairo service centers.',
    features: [
      'Authentic Zero-Cycle Battery Cells',
      '100% Battery Health % restoring in iOS / Android Settings',
      'Thermal Protection & Overcharge Prevention IC',
      'Express 20-minute installation while you wait',
      '12 Months Store Warranty'
    ],
    image: 'https://images.unsplash.com/photo-1619948326514-668d3a41819f?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1619948326514-668d3a41819f?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'OEM Certified Cell', hex: '#1e293b' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'Power Management IC Verified',
      mainCamera: 'N/A',
      selfieCamera: 'N/A',
      battery: '100% Maximum Capacity Restored',
      charging: 'Supports MagSafe & Fast Charging',
      weight: 'Factory Spec',
      network: 'N/A',
      os: 'Supports iOS 18 & Android 15',
      waterResistance: 'Water Seal Re-applied'
    }
  },
  {
    id: 'syr-repair-backglass',
    name: 'Precision Laser Back Glass Removal & Glass Replacement',
    brand: 'Apple',
    category: 'Repair Services',
    priceUSD: 45,
    originalPriceUSD: 60,
    rating: 4.9,
    reviewsCount: 185,
    badge: 'Hot',
    isFeatured: false,
    inStock: true,
    warrantyYears: 1,
    description: 'Advanced automated laser separation technique removes shattered rear glass without opening or risking internal phone components. Available for iPhone 8 through 16 Pro Max and Samsung Ultra series.',
    features: [
      'Zero-Heat Laser Demounting Machine Tech',
      'OEM Color-Matched Corning Gorilla Glass Panel',
      'Wireless Charging Coil Undamaged Guaranteed',
      '1-Hour Same-Day Service in Zagazig',
      'Includes Lens Protector Ring'
    ],
    image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=1200&auto=format&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=1200&auto=format&fit=crop'
    ],
    colors: [
      { name: 'Color Matched OEM Glass', hex: '#0f172a' }
    ],
    specsDetail: {
      display: 'N/A',
      chipset: 'N/A',
      mainCamera: 'Lens Ring Protected',
      selfieCamera: 'N/A',
      battery: 'Wireless Charging Protected',
      charging: 'MagSafe Compatible',
      weight: 'Factory Spec',
      network: 'N/A',
      os: 'N/A',
      waterResistance: 'Waterproof Seal Applied'
    }
  }
];
