export type Category = 
  | 'All'
  | 'Smartphones'
  | 'Tablets'
  | 'Smartwatches'
  | 'Audio & Sound'
  | 'Accessories'
  | 'Luxury Editions'
  | 'Repair Services';

export type Brand = 
  | 'All' 
  | 'Apple' 
  | 'Samsung' 
  | 'Google' 
  | 'Nothing' 
  | 'Xiaomi' 
  | 'Honor' 
  | 'Huawei' 
  | 'Oppo' 
  | 'Vivo' 
  | 'OnePlus' 
  | 'Motorola' 
  | 'Realme' 
  | 'Sony' 
  | 'Anker';

export type Language = 'en' | 'ar';

export type Currency = 'EGP' | 'USD' | 'EUR' | 'SAR' | 'AED' | 'SYP';

export interface CurrencyConfig {
  code: Currency;
  symbol: string;
  rateToUSD: number; // multiplier from USD
  decimals: number;
}

export interface ProductColor {
  name: string;
  hex: string;
  image?: string;
}

export interface ProductSpecsDetail {
  display: string;
  chipset: string;
  mainCamera: string;
  selfieCamera: string;
  battery: string;
  charging: string;
  weight: string;
  network: string;
  os: string;
  waterResistance: string;
}

export interface Product {
  id: string;
  name: string;
  nameArabic?: string;
  brand: Brand;
  category: Category;
  model?: string;
  sku?: string;
  barcode?: string;
  priceUSD: number;
  originalPriceUSD?: number;
  hidePrice?: boolean; // If true, display "Contact us for today's price"
  stockQuantity?: number;
  rating: number;
  reviewsCount: number;
  badge?: 'New' | 'Bestseller' | 'Hot' | 'Luxury Edition' | 'Special Offer';
  description: string;
  features: string[];
  image: string;
  gallery: string[];
  videoUrl?: string;
  colors: ProductColor[];
  storageOptions?: { size: string; priceUSD: number }[];
  specsDetail: ProductSpecsDetail;
  inStock: boolean;
  isFeatured?: boolean;
  isNewArrival?: boolean;
  isBestseller?: boolean;
  published?: boolean;
  warrantyYears: number;
  seoTitle?: string;
  seoDescription?: string;
}

export type AdminRole = 
  | 'Super Admin'
  | 'Admin'
  | 'Sales'
  | 'Marketing'
  | 'Inventory Manager'
  | 'Technician'
  | 'Customer Support';

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: AdminRole;
  avatar?: string;
  active: boolean;
  twoFactorEnabled: boolean;
  twoFactorSecret?: string;
  lastLogin?: string;
  createdAt: string;
}

export type PermissionKey = 
  | 'dashboard_read'
  | 'products_read'
  | 'products_write'
  | 'products_delete'
  | 'categories_manage'
  | 'brands_manage'
  | 'orders_read'
  | 'orders_manage'
  | 'customers_read'
  | 'customers_manage'
  | 'repairs_read'
  | 'repairs_manage'
  | 'cms_manage'
  | 'blog_manage'
  | 'marketing_manage'
  | 'ai_manage'
  | 'users_manage'
  | 'settings_manage'
  | 'backups_manage';

export type RolePermissionMatrix = Record<AdminRole, Record<PermissionKey, boolean>>;

export interface CategoryCMS {
  id: string;
  name: string;
  nameArabic?: string;
  description?: string;
  iconName?: string;
  imageUrl?: string;
  order: number;
  active: boolean;
}

export interface BrandCMS {
  id: string;
  name: string;
  logoUrl?: string;
  description?: string;
  featured: boolean;
  active: boolean;
}

export interface Customer {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  city: string;
  address: string;
  totalSpendUSD: number;
  ordersCount: number;
  repairCount: number;
  isBlocked: boolean;
  savedAddresses: string[];
  wishlistProductIds: string[];
  createdAt: string;
  lastOrderDate?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  titleArabic?: string;
  slug: string;
  author: string;
  category: string;
  tags: string[];
  excerpt: string;
  content: string;
  imageUrl: string;
  publishedAt: string;
  published: boolean;
  seoTitle?: string;
  seoDescription?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderUSD?: number;
  expiryDate: string;
  usageCount: number;
  maxUsage?: number;
  active: boolean;
}

export interface FlashSale {
  id: string;
  title: string;
  titleArabic?: string;
  discountPercent: number;
  endDate: string;
  productIds: string[];
  active: boolean;
}

export interface AIDocument {
  id: string;
  title: string;
  category: 'Policy' | 'Manual' | 'FAQ' | 'Inventory' | 'Warranty';
  content: string;
  uploadedAt: string;
  size: string;
  status: 'Indexed' | 'Pending';
}

export interface HomepageSectionCMS {
  id: string;
  sectionKey: 'hero' | 'featured_products' | 'categories' | 'brands' | 'offers' | 'repairs' | 'exploded' | 'stats' | 'faq' | 'reviews' | 'newsletter' | 'footer';
  title: string;
  titleArabic?: string;
  subtitle?: string;
  enabled: boolean;
  order: number;
  config: Record<string, any>;
}

export interface WebsiteSettings {
  storeName: string;
  storeNameArabic: string;
  tagline: string;
  taglineArabic?: string;
  logoUrl: string;
  faviconUrl: string;
  phone: string;
  whatsappPhone: string;
  email: string;
  address: string;
  addressArabic?: string;
  googleMapEmbedUrl: string;
  latitude: number;
  longitude: number;
  businessHours: string;
  facebookUrl: string;
  instagramUrl: string;
  tiktokUrl: string;
  youtubeUrl: string;
  currency: Currency;
  languages: Language[];
  shippingFeeUSD: number;
  freeShippingThresholdUSD: number;
  taxRatePercent: number;
  enableVodafoneCash: boolean;
  enableInstaPay: boolean;
  enableValu: boolean;
  enableCIB: boolean;
  enableCOD: boolean;
  maintenanceMode: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userEmail: string;
  userName: string;
  userRole: string;
  action: string;
  module: string;
  details: string;
  ipAddress: string;
}

export interface CartItem {
  id: string; // unique item instance id
  product: Product;
  selectedColor: ProductColor;
  selectedStorage?: string;
  priceUSD: number;
  quantity: number;
}

export interface OrderCustomerInfo {
  fullName: string;
  email: string;
  phone: string;
  city: string;
  address: string;
  notes?: string;
}

export interface TrackingEvent {
  title: string;
  timestamp: string;
  location: string;
  completed: boolean;
  current?: boolean;
}

export interface Order {
  orderId: string;
  date: string;
  items: CartItem[];
  subtotalUSD: number;
  discountUSD: number;
  shippingUSD: number;
  totalUSD: number;
  currency: Currency;
  totalConvertedFormatted: string;
  status: 'Processing' | 'Confirmed' | 'In Transit' | 'Out for Delivery' | 'Delivered';
  customerInfo: OrderCustomerInfo;
  shippingMethod: 'Zagazig Express' | 'Egypt Nationwide Courier' | 'Store Pickup (Villas El Gamea)';
  paymentMethod: 'Cash on Delivery' | 'InstaPay / Vodafone Cash' | 'Credit Card / Online' | 'Crypto (USDT)';
  trackingEvents: TrackingEvent[];
}

export interface RepairBooking {
  id: string;
  customerName: string;
  phone: string;
  deviceBrand: string;
  deviceModel: string;
  issueType: 'Screen & OLED' | 'Original Battery' | 'Back Glass Laser' | 'Motherboard & Soldering' | 'Water Damage' | 'Camera & Lens' | 'Charging Port';
  preferredDate: string;
  estimatedCostEGP: number;
  status: 'Received' | 'Diagnosing' | 'Repairing' | 'Quality Check' | 'Ready for Pickup';
}

export interface TradeInEstimateRequest {
  brand: string;
  model: string;
  storage: string;
  condition: 'Like New' | 'Good' | 'Fair';
  screenIntact: boolean;
  batteryHealth?: string;
}

export interface TradeInEstimateResult {
  estimatedValueUSD: number;
  bonusCreditUSD: number;
  totalTradeInUSD: number;
  currencyValues: Record<Currency, string>;
  voucherCode: string;
}

export interface Review {
  id: string;
  productId: string;
  authorName: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verifiedPurchase: boolean;
  recommended: boolean;
}
